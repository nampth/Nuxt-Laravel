/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./resources/js/helpers.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
var getCookie = exports.getCookie = function getCookie(name) {
    var value = "; " + document.cookie;
    var parts = value.split("; " + name + "=");
    if (parts.length == 2) return parts.pop().split(";").shift();
};
var setCookie = exports.setCookie = function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
};

/***/ }),

/***/ "./resources/js/pages/userinfo.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _helpers = __webpack_require__("./resources/js/helpers.js");

var baseUrl = $('#site_meta').attr('data-url');
var apiPath = $('#api_meta').attr('data-url');

var app = new Vue({
    el: '#app',
    data: {
        form: {
            amount: '',
            duration: '',
            fullname: '',
            phone: '',
            identity_id: '',
            current_address: '',
            form_level: 11,
            theme: 'vncredit_99',
            code: '',
            p: '',
            k: '',
            ref: '',
            traffic_id: '',
            traffic_source: '',
            pub_id: '',
            domain: 'team1.vncredit.com.vn'
        },
        userinfo: null,
        allowArray: ['phone', 'fullname', 'identity_id', 'current_address', 'amount', 'duration'],
        invalidAmount: false,
        invalidDuration: false,
        invalidPhone: false,
        invalidFullname: false,
        invalidCurrentAddress: false,
        invalidIdentity: false,
        loadContent: false,
        isLoading: false,
        toastType: '',
        loadDone: true,
        showOtp: false,
        toastMsg: ''
    },
    mounted: function mounted() {
        var vm = this;
        var token = (0, _helpers.getCookie)('auth._token.local');
        setTimeout(function () {
            vm.initUserInfo(token);
        }, 100);
    },

    methods: {
        initUserInfo: function initUserInfo(token) {
            var vm = this;
            $.ajax({
                url: apiPath + 'infoec',
                beforeSend: function beforeSend(xhr) {
                    xhr.setRequestHeader("Authorization", token);
                },
                type: 'GET',
                success: function success(data) {
                    if (data && data.success) {
                        vm.userinfo = data.data;
                    } else {
                        // window.location.href = baseUrl + '404';
                    }
                },
                error: function error(err) {
                    // window.location.href = baseUrl + '404';
                }
            });
        }
    }
});

/***/ }),

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("./resources/js/pages/userinfo.js");


/***/ })

/******/ });