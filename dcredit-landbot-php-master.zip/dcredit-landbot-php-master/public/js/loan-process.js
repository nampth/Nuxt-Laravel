/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./resources/js/helpers.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
var getCookie = exports.getCookie = function getCookie(name) {
    var value = "; " + document.cookie;
    var parts = value.split("; " + name + "=");
    if (parts.length == 2) return parts.pop().split(";").shift();
};
var setCookie = exports.setCookie = function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
};

/***/ }),

/***/ "./resources/js/pages/loan-process.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _helpers = __webpack_require__("./resources/js/helpers.js");

var baseUrl = $('#site_meta').attr('data-url');
var apiPath = $('#api_meta').attr('data-url');

var app = new Vue({
    el: '#app',
    data: {
        form: {
            phone: '',
            state: false,
            current_detail: '',
            sex: '',
            identity_location: '',
            full_date_of_birth: '',
            full_identity_date: '',
            identity_date: '',
            identity_month: '',
            identity_year: '',
            date_of_birth: '',
            month_of_birth: '',
            year_of_birth: '',
            form_level: 42
        },
        phone: '',
        amount: 30,
        duration: 12,
        isLoading: false,
        isSubmiting: false,
        submitRefer: false,
        toastStatus: '',
        toastMsg: '',
        toastHeader: '',
        showLoan: false
    },
    mounted: function mounted() {
        var vm = this;
        var token = (0, _helpers.getCookie)('auth._token.local');
        vm.initUserInfo(token);
        vm.initLoanProcess(token);
    },

    methods: {
        initUserInfo: function initUserInfo(token) {
            var vm = this;
            $(document).ready(function () {
                $.ajax({
                    url: apiPath + 'infoec',
                    beforeSend: function beforeSend(xhr) {
                        xhr.setRequestHeader("Authorization", token);
                    },
                    type: 'GET',
                    success: function success(data) {
                        if (data && data.success) {
                            var metricData = data.data.metric_data;
                            metricData.forEach(function (item) {
                                if (item.info.key == 'amount') {
                                    vm.amount = item.value;
                                }
                                if (item.info.key == 'duration') {
                                    vm.duration = item.value;
                                }
                                if (item.info.key == 'phone') {
                                    vm.form.phone = item.value;
                                }
                            });
                        } else {
                            // window.location.href = baseUrl + '404';
                        }
                    },
                    error: function error(err) {
                        // window.location.href = baseUrl + '404';
                    }
                });
            });
        },
        initLoanProcess: function initLoanProcess(token) {
            var vm = this;
            $(document).ready(function () {
                $.ajax({
                    url: 'https://vncredit.com.vn/api/loanstt',
                    beforeSend: function beforeSend(xhr) {
                        xhr.setRequestHeader("Authorization", token);
                    },
                    type: 'GET',
                    success: function success(data) {
                        console.log(data);
                        if (data && data.success) {} else {
                            // window.location.href = baseUrl + '404';
                        }
                    },
                    error: function error(err) {
                        // window.location.href = baseUrl + '404';
                    }
                });
            });
        }
    }
});

/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("./resources/js/pages/loan-process.js");


/***/ })

/******/ });