$(document).ready(function ($) {
    "use strict";
    var loader = function () {
        setTimeout(function () {
            if ($('#pb_loader').length > 0) {
                $('#pb_loader').removeClass('show');
            }
        }, 700);
    };
    loader();


    var slickSliders = function () {
        $('.single-item').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: true,
            infinite: true,
            autoplay: false,
            autoplaySpeed: 2000,
            nextArrow: '<span class="next"><i class="ion-ios-arrow-right"></i></span>',
            prevArrow: '<span class="prev"><i class="ion-ios-arrow-left"></i></span>',
            arrows: true,
            draggable: false,
            adaptiveHeight: true
        });
        $('.single-item-no-arrow').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: true,
            infinite: true,
            autoplay: true,
            autoplaySpeed: 2000,
            nextArrow: '<span class="next"><i class="ion-ios-arrow-right"></i></span>',
            prevArrow: '<span class="prev"><i class="ion-ios-arrow-left"></i></span>',
            arrows: false,
            draggable: false
        });
        $('.multiple-items').slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            dots: true,
            infinite: true,
            autoplay: true,
            autoplaySpeed: 2000,
            arrows: true,
            nextArrow: '<span class="next"><i class="ion-ios-arrow-right"></i></span>',
            prevArrow: '<span class="prev"><i class="ion-ios-arrow-left"></i></span>',
            draggable: false,
            responsive: [{
                breakpoint: 1125,
                settings: {slidesToShow: 2, slidesToScroll: 1, infinite: true, dots: true}
            }, {breakpoint: 900, settings: {slidesToShow: 2, slidesToScroll: 2}}, {
                breakpoint: 580,
                settings: {slidesToShow: 1, slidesToScroll: 1}
            }]
        });
        $('.js-pb_slider_content').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            fade: true,
            asNavFor: '.js-pb_slider_nav',
            adaptiveHeight: false
        });
        $('.js-pb_slider_nav').slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            asNavFor: '.js-pb_slider_content',
            dots: false,
            centerMode: true,
            centerPadding: "0px",
            focusOnSelect: true,
            arrows: false
        });
        $('.js-pb_slider_content2').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            fade: true,
            asNavFor: '.js-pb_slider_nav2',
            adaptiveHeight: false
        });
        $('.js-pb_slider_nav2').slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            asNavFor: '.js-pb_slider_content2',
            dots: false,
            centerMode: true,
            centerPadding: "0px",
            focusOnSelect: true,
            arrows: false
        });
    };
    slickSliders();



});
