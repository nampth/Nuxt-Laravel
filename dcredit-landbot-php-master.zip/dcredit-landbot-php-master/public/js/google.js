window.dataLayer = window.dataLayer || [];

function gtag() {
    dataLayer.push(arguments);
}

gtag('js', new Date());

gtag('config', 'AW-729060130', {'groups': 'adwords'});

gtag_report_conversion = function(url) {
    var callback = function () {
        if (typeof(url) != 'undefined') {
            window.location = url;
        }
    };
    gtag('event', 'conversion', {
        'send_to': 'AW-729060130/wBRkCMmTtqYBEKKm0tsC',
        'event_callback': callback
    });
    return false;
}


window.dataLayer = window.dataLayer || [];

gtag('js', new Date());

gtag('config', 'UA-148874171-1', {
    'groups': 'default',
    'custom_map': {
        'dimension1': 'theme',
        'dimension2': 'page',
        'metric1': 'conversion',
        'metric2': 'session',
        'metric3': 'session15',
        'metric4': 'session30'
    }
})

if (window.location.hostname === 'vncredit.online') {
    gtag('config', 'UA-148874171-3', {
        'groups': 'vncredit.online'
    })
}

if (window.location.hostname === 'vncredit.com.vn') {
    gtag('config', 'UA-148874171-4', {
        'groups': 'vncredit.com.vn'
    })
}