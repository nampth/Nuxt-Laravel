/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./resources/js/pages/homepage.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var baseUrl = $('#site_meta').attr('data-url');
var apiPath = $('#api_meta').attr('data-url');

var app = new Vue({
    el: '#app',
    data: {
        form: {
            amount: 30,
            duration: 12,
            fullname: '',
            phone: '',
            identity_id: '',
            current_address: '',
            form_level: 11,
            theme: 'vncredit_99',
            code: '',
            sid: '',
            p: '',
            k: '',
            ref: '',
            traffic_id: '',
            traffic_source: '',
            utm_source: '',
            aff_sid: '',
            pub_id: '',
            subscriber_id: '',
            domain: 'vncredit.com.vn'
        },
        loginForm: {
            phone: '',
            code: '',
            sid: ''
        },
        invalidAmount: false,
        invalidDuration: false,
        invalidPhone: false,
        invalidFullname: false,
        invalidCurrentAddress: false,
        invalidIdentity: false,
        loadContent: false,
        isLoading: false,
        loadDone: true,
        showOtp: false,
        toastStatus: '',
        toastMsg: '',
        toastHeader: ''
    },
    mounted: function mounted() {
        var vm = this;
        vm.handleUserAction();
        vm.initUrlParam();
    },

    methods: {
        showLoginForm: function showLoginForm() {
            var vm = this;
            vm.isLoading = false;
            vm.showOtp = false;
            $('#login-modal').modal('show');
        },
        submitLoginForm: function submitLoginForm() {
            var vm = this;
            var phonePattern = new RegExp(/^(03|05|07|09|08)([0-9]{8})$/);
            var phoneRes = phonePattern.test(vm.loginForm.phone);
            if (!vm.loginForm.phone || !phoneRes) {
                vm.showToast('error', 'Lỗi', 'Số điện thoại không phù hợp');
                return;
            }

            var codePattern = new RegExp(/^([0-9]{4})$/);
            var codeRes = codePattern.test(vm.loginForm.code);
            if (vm.showOtp && (!vm.loginForm.code || !codeRes)) {
                vm.showToast('error', 'Lỗi', 'Mã xác thực không phù hợp');
                return;
            }
            vm.isLoading = true;
            if (!vm.showOtp) {
                $.ajax({
                    url: apiPath + 'auth/voice-otp',
                    type: "POST",
                    data: vm.loginForm,
                    success: function success(response) {
                        vm.isLoading = false;
                        if (parseInt(response.code) == 0) {
                            vm.showToast('success', 'Thành công', "Chúng tôi đã gửi 1 cuộc gọi tới số &nbsp;<b>" + vm.loginForm.phone + ". Vui lòng chú ý lắng nghe</b>");
                            vm.showOtp = true;
                        } else {
                            if (response.message == 'otp sent') {
                                vm.showOtp = true;
                                vm.showToast('success', 'Thành công', 'Hãy nhập mã OTP bạn đã nhận được. Hoặc đợi thêm 5 phút để có thể nhận mã OTP mới.');
                            } else {
                                vm.showOtp = false;
                                vm.showToast('error', 'Lỗi', 'Có lỗi xảy ra. Vui lòng thử lại sau 5 phút.');
                                vm.loginForm.phone = '';
                                vm.isLoading = false;
                                $('#login-modal').modal('hide');
                            }
                        }
                    },
                    error: function error(err) {
                        vm.showToast('error', 'Lỗi', 'Có lỗi xảy ra. Vui lòng thử lại sau 5 phút.');
                        vm.isLoading = false;
                        $('#login-modal').modal('hide');
                    }
                });
            } else {
                $.ajax({
                    url: apiPath + 'auth/verify-voice-otp',
                    type: "POST",
                    data: vm.loginForm,
                    success: function success(response) {
                        vm.isLoading = false;
                        if (response && response.success) {
                            vm.setCookie('auth._token.local', 'Bearer ' + response.token, 700);
                            vm.setCookie('auth.strategy', 'local', 700);
                            window.location.href = baseUrl + '/userinfo';
                        } else {
                            if (parseInt(response.code) == 2) {
                                vm.showToast('error', 'Lỗi', 'Số điện thoại không tồn tại.');
                            } else {
                                if (response.msg == "otp wrong") {
                                    vm.showToast('error', 'Lỗi', 'Mã OTP không chính xác. Vui lòng thử lại sau.');
                                } else {
                                    vm.showToast('error', 'Lỗi', 'Đăng nhập không thành công. Vui lòng thử lại sau.');
                                }
                            }
                        }
                    },
                    error: function error(err) {
                        vm.showToast('error', 'Lỗi', 'Có lỗi xảy ra. Vui lòng thử lại sau 5 phút.');
                        vm.isLoading = false;
                        $('#login-modal').modal('hide');
                    }
                });
            }
        },
        encode_utf8: function encode_utf8(s) {
            return unescape(encodeURIComponent(s));
        },
        sha1: function sha1(str) {
            var vm = this;
            //  discuss at: http://phpjs.org/functions/sha1/
            // original by: Webtoolkit.info (http://www.webtoolkit.info/)
            // improved by: Michael White (http://getsprink.com)
            // improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
            //    input by: Brett Zamir (http://brett-zamir.me)
            //  depends on: utf8_encode
            //   example 1: sha1('Kevin van Zonneveld');
            //   returns 1: '54916d2e62f65b3afa6e192e6a601cdbe5cb5897'

            var rotate_left = function rotate_left(n, s) {
                var t4 = n << s | n >>> 32 - s;
                return t4;
            };

            /*var lsb_hex = function (val) { // Not in use; needed?
              var str="";
              var i;
              var vh;
              var vl;
                for ( i=0; i<=6; i+=2 ) {
                vh = (val>>>(i*4+4))&0x0f;
                vl = (val>>>(i*4))&0x0f;
                str += vh.toString(16) + vl.toString(16);
              }
              return str;
            };*/

            var cvt_hex = function cvt_hex(val) {
                var str = '';
                var i;
                var v;

                for (i = 7; i >= 0; i--) {
                    v = val >>> i * 4 & 0x0f;
                    str += v.toString(16);
                }
                return str;
            };

            var blockstart;
            var i, j;
            var W = new Array(80);
            var H0 = 0x67452301;
            var H1 = 0xEFCDAB89;
            var H2 = 0x98BADCFE;
            var H3 = 0x10325476;
            var H4 = 0xC3D2E1F0;
            var A, B, C, D, E;
            var temp;

            str = vm.encode_utf8(str);
            var str_len = str.length;

            var word_array = [];
            for (i = 0; i < str_len - 3; i += 4) {
                j = str.charCodeAt(i) << 24 | str.charCodeAt(i + 1) << 16 | str.charCodeAt(i + 2) << 8 | str.charCodeAt(i + 3);
                word_array.push(j);
            }

            switch (str_len % 4) {
                case 0:
                    i = 0x080000000;
                    break;
                case 1:
                    i = str.charCodeAt(str_len - 1) << 24 | 0x0800000;
                    break;
                case 2:
                    i = str.charCodeAt(str_len - 2) << 24 | str.charCodeAt(str_len - 1) << 16 | 0x08000;
                    break;
                case 3:
                    i = str.charCodeAt(str_len - 3) << 24 | str.charCodeAt(str_len - 2) << 16 | str.charCodeAt(str_len - 1) << 8 | 0x80;
                    break;
            }

            word_array.push(i);

            while (word_array.length % 16 != 14) {
                word_array.push(0);
            }

            word_array.push(str_len >>> 29);
            word_array.push(str_len << 3 & 0x0ffffffff);

            for (blockstart = 0; blockstart < word_array.length; blockstart += 16) {
                for (i = 0; i < 16; i++) {
                    W[i] = word_array[blockstart + i];
                }
                for (i = 16; i <= 79; i++) {
                    W[i] = rotate_left(W[i - 3] ^ W[i - 8] ^ W[i - 14] ^ W[i - 16], 1);
                }

                A = H0;
                B = H1;
                C = H2;
                D = H3;
                E = H4;

                for (i = 0; i <= 19; i++) {
                    temp = rotate_left(A, 5) + (B & C | ~B & D) + E + W[i] + 0x5A827999 & 0x0ffffffff;
                    E = D;
                    D = C;
                    C = rotate_left(B, 30);
                    B = A;
                    A = temp;
                }

                for (i = 20; i <= 39; i++) {
                    temp = rotate_left(A, 5) + (B ^ C ^ D) + E + W[i] + 0x6ED9EBA1 & 0x0ffffffff;
                    E = D;
                    D = C;
                    C = rotate_left(B, 30);
                    B = A;
                    A = temp;
                }

                for (i = 40; i <= 59; i++) {
                    temp = rotate_left(A, 5) + (B & C | B & D | C & D) + E + W[i] + 0x8F1BBCDC & 0x0ffffffff;
                    E = D;
                    D = C;
                    C = rotate_left(B, 30);
                    B = A;
                    A = temp;
                }

                for (i = 60; i <= 79; i++) {
                    temp = rotate_left(A, 5) + (B ^ C ^ D) + E + W[i] + 0xCA62C1D6 & 0x0ffffffff;
                    E = D;
                    D = C;
                    C = rotate_left(B, 30);
                    B = A;
                    A = temp;
                }

                H0 = H0 + A & 0x0ffffffff;
                H1 = H1 + B & 0x0ffffffff;
                H2 = H2 + C & 0x0ffffffff;
                H3 = H3 + D & 0x0ffffffff;
                H4 = H4 + E & 0x0ffffffff;
            }

            temp = cvt_hex(H0) + cvt_hex(H1) + cvt_hex(H2) + cvt_hex(H3) + cvt_hex(H4);
            return temp.toLowerCase();
        },
        initUrlParam: function initUrlParam() {
            var vm = this;
            var url_string = window.location.href;
            var url = new URL(url_string);
            var p = url.searchParams.get("p");
            var k = url.searchParams.get("k");
            var trafficSource = url.searchParams.get("traffic_source");
            var trafficId = url.searchParams.get("traffic_id");
            var ref = url.searchParams.get("ref");
            var affSid = url.searchParams.get("aff_sid");
            var utmSource = url.searchParams.get("utm_source");
            var pubId = url.searchParams.get("pub_id");
            if (k) {
                vm.form.k = k;
            }

            if (p) {
                vm.form.province = p;
                vm.form.current_address = p;
            }

            if (trafficSource) {
                // vm.form.traffic_source = trafficSource;
                vm.setCookie('source', 'masoffer', 1);
                vm.setCookie('traffic_source', trafficSource, 1);
                vm.setCookie('traffic_id', trafficId, 1);
                vm.setCookie('pub_id', pubId, 1);
            }

            if (trafficId) {
                vm.form.traffic_id = trafficId;
            }

            if (ref) {
                // vm.form.ref = ref;
                vm.setCookie('source', 'kalapa', 1);
                vm.setCookie('ref', ref, 1);
            }

            if (utmSource) {
                // vm.form.utm_source = utmSource;
                vm.setCookie('source', 'accesstrade', 1);
                vm.setCookie('traffic_source', utmSource, 1);
                vm.setCookie('traffic_id', affSid, 1);
            }

            if (affSid) {
                vm.form.aff_sid = affSid;
            }
        },
        submitForm: function submitForm(formType) {
            var vm = this;
            vm.isLoading = true;
            if (!vm.manualValidateRegisterForm()) {
                vm.showToast('error', 'Lỗi', 'Bạn vui lòng nhập đầy đủ thông tin để có thể đăng ký khoản vay.');
                return;
            } else {
                if (vm.getCookie('source') && vm.getCookie('source') === 'kalapa') {
                    vm.form.ref = vm.getCookie('ref');
                }
                if (vm.getCookie('source') && vm.getCookie('source') === 'masoffer') {
                    vm.form.traffic_source = vm.getCookie('traffic_source');
                    vm.form.traffic_id = vm.getCookie('traffic_id');
                    vm.form.pub_id = vm.getCookie('pub_id');
                }
                if (vm.getCookie('source') && vm.getCookie('source') === 'accesstrade') {
                    vm.form.traffic_source = vm.getCookie('traffic_source');
                    vm.form.traffic_id = vm.getCookie('traffic_id');
                }

                if (!vm.showOtp) {
                    vm.isLoading = false;
                    console.log('post: ' + localStorage.getItem('subscriber_id'));
                    vm.form.subscriber_id = localStorage.getItem('subscriber_id');
                    var queryString = Object.keys(vm.form).map(function (key) {
                        return key + '=' + vm.form[key];
                    }).join('&');
                    $('#pixel-wrapper').html('<img class="hidden"  src="https://webapi.vncredit.com.vn/1.png?' + queryString + '">');
                    vm.isLoading = true;
                    $.ajax({
                        url: apiPath + 'auth/exist',
                        type: "POST",
                        data: vm.form,
                        success: function success(data) {
                            if (data && data.code === 0) {
                                vm.isLoading = true;
                                $.ajax({
                                    url: apiPath + 'auth/registerec',
                                    type: "POST",
                                    data: vm.form,
                                    success: function success(dataRegister) {
                                        vm.showToast('success', 'Thành công', 'Đăng ký thành công, bạn vui lòng nhập mã OTP để xác thực đăng ký vay');
                                        // request voice-otp
                                        vm.showOtp = true;
                                        $.ajax({
                                            url: apiPath + 'auth/voice-otp',
                                            type: "POST",
                                            data: vm.form,
                                            success: function success(dataVoice) {
                                                vm.isLoading = false;
                                                $('#otp-modal').modal('show');
                                            },
                                            error: function error(err) {
                                                vm.isLoading = false;
                                            }

                                        });
                                    },
                                    error: function error(err) {}

                                });
                                if (vm.form.ref.indexOf('FB_') >= 0) {
                                    fbq('track', 'CompleteRegistration');
                                }
                                gtag_report_conversion();
                                gtag('event', 'click', {
                                    event_category: 'register-form',
                                    event_label: 'register-success',
                                    theme: 'vncredit_99',
                                    conversion: 1
                                });
                                if (formType == 'score') {
                                    gtag('event', 'register', {
                                        'event_category': 'Form score success',
                                        'event_label': 'Form score success'
                                    });
                                } else {
                                    gtag('event', 'register', {
                                        'event_category': 'Form register success',
                                        'event_label': 'Form'
                                    });
                                }
                            } else {
                                gtag('event', 'user registered', {
                                    'event_category': 'User registered',
                                    'event_label': 'Form'
                                });
                                vm.showToast('error', 'Lỗi', 'Số điện thoại đã tồn tại hoặc không phù hợp đăng ký vay.');
                                vm.isLoading = false;
                            }
                        },
                        error: function error(_error) {
                            vm.isLoading = false;
                            vm.showToast('error', 'Lỗi', 'Có lỗi xảy ra, vui lòng thử lại sau 5 phút');
                            gtag('event', 'user register error', {
                                'event_category': 'User register error',
                                'event_label': 'Form'
                            });
                        }
                    });
                } else {
                    vm.isLoading = true;
                    $.ajax({
                        url: apiPath + 'auth/verify-voice-otp',
                        type: "POST",
                        data: vm.form,
                        success: function success(data) {
                            vm.isLoading = false;
                            if (data && data.code === 0) {
                                vm.setCookie('auth._token.local', 'Bearer ' + data.token, 700);
                                vm.setCookie('auth.strategy', 'local', 700);
                                vm.showToast('success', 'Thành công', 'Đăng ký thành công. Trang web sẽ chuyển hướng sau 3 giây...');
                                setTimeout(function () {
                                    window.location.href = baseUrl + '/refer';
                                }, 2000);
                            } else {
                                vm.showToast('error', 'Lỗi', 'Có lỗi xảy ra, vui lòng thử lại sau 5 phút');
                            }
                        },
                        error: function error(err) {
                            vm.isLoading = false;
                            vm.showToast('error', 'Lỗi', 'Có lỗi xảy ra, vui lòng thử lại sau 5 phút');
                        }

                    });
                }
            }
        },
        manualUpdateValidate: function manualUpdateValidate() {
            var vm = this;
            if (vm.form.phone) {
                vm.invalidPhone = false;
            }
            if (vm.form.amount) {
                vm.invalidAmount = false;
            }
            if (vm.form.duration) {
                vm.invalidDuration = false;
            }
            if (vm.form.identity_id) {
                vm.invalidIdentity = false;
            }
            if (vm.form.current_address) {
                vm.invalidCurrentAddress = false;
            }
            if (vm.form.fullname) {
                vm.invalidFullname = false;
            }
        },
        manualValidateRegisterForm: function manualValidateRegisterForm() {
            var vm = this;
            var phonePattern = new RegExp(/^(03|05|07|09|08)([0-9]{8})$/);
            var phoneRes = phonePattern.test(vm.form.phone);
            if (!vm.form.phone || !phoneRes) {
                vm.invalidPhone = true;
            }
            if (!vm.form.amount) {
                vm.invalidAmount = true;
            }
            if (!vm.form.duration) {
                vm.invalidDuration = true;
            }

            var identityPattern = new RegExp(/^([0-9]{9}|[0-9]{12})$/);
            var identityRes = identityPattern.test(vm.form.identity_id);
            if (!vm.form.identity_id || !identityRes) {
                vm.invalidIdentity = true;
            }
            if (!vm.form.current_address) {
                vm.invalidCurrentAddress = true;
            }
            if (!vm.form.fullname) {
                vm.invalidFullname = true;
            }
            if (vm.invalidPhone || vm.invalidAmount || vm.invalidDuration || vm.invalidIdentity || vm.invalidCurrentAddress || vm.invalidFullname) {
                vm.isLoading = false;
                return false;
            }
            vm.invalidPhone = vm.invalidIdentity = vm.invalidCurrentAddress = vm.invalidFullname = false;
            return true;
        },
        handleUserAction: function handleUserAction() {
            var vm = this;
            $(document).ready(function () {
                $(document).on('click', 'body', function (event) {
                    vm.loadContent = true;
                    setTimeout(function () {
                        vm.includeThirdPartyJs();
                    }, 100);
                });

                $(window).scroll(function () {
                    vm.loadContent = true;
                    setTimeout(function () {
                        vm.includeThirdPartyJs();
                    }, 100);
                });
                $(document).on('mousemove', function () {
                    vm.loadContent = true;
                    setTimeout(function () {
                        vm.includeThirdPartyJs();
                    }, 100);
                });

                $(document).on('touchstart', 'body', function () {
                    vm.loadContent = true;
                    setTimeout(function () {
                        vm.includeThirdPartyJs();
                    }, 100);
                });

                $(document).on('touchmove', function () {
                    vm.loadContent = true;
                    setTimeout(function () {
                        vm.includeThirdPartyJs();
                    }, 100);
                });

                vm.initNotification();
            });
        },
        initNotification: function initNotification() {},
        includeThirdPartyJs: function includeThirdPartyJs() {
            var vm = this;
            if (vm.loadContent && vm.loadDone) {
                vm.loadDone = false;
                var gtagScript = document.createElement('script');
                gtagScript.setAttribute('src', "https://www.googletagmanager.com/gtag/js?id=AW-729060130");
                document.head.appendChild(gtagScript);

                var gtag2 = document.createElement('script');
                gtag2.setAttribute('src', "https://www.googletagmanager.com/gtag/js?id=UA-148874171-1");
                document.head.appendChild(gtag2);

                var fb = document.createElement('script');
                fb.setAttribute('src', "js/fb.js");
                document.head.appendChild(fb);

                var gg = document.createElement('script');
                gg.setAttribute('src', "js/google.js");
                document.head.appendChild(gg);

                setTimeout(function () {
                    // create ga_sid
                    if (!vm.getCookie('ga_sid')) {
                        var randomnumber = Math.floor(Math.random() * (1e6 - 1));
                        var time = Date.now();
                        var sid = vm.sha1(time + '-' + randomnumber).toString();
                        vm.form.sid = sid;
                        vm.setCookie('ga_sid', sid, 1);
                        vm.setCookie('abTest', 'vncredit_99', 1);
                        console.log(vm.getCookie('abTest'));
                        gtag('event', 'start_session', {
                            event_category: 'session',
                            event_label: '1D',
                            theme: vm.getCookie('abTest'),
                            session: 1
                        });
                    }

                    // create ga15_sid
                    if (!vm.getCookie('ga15_sid')) {
                        var _randomnumber = Math.floor(Math.random() * (1e6 - 1));
                        var _time = Date.now();
                        var ga15_sid = vm.sha1(_time + '-' + _randomnumber);
                        vm.setCookie('ga15_sid', ga15_sid, 15);

                        setTimeout(function () {
                            gtag('event', 'start_session', {
                                event_category: 'session',
                                event_label: '15D',
                                theme: vm.getCookie('abTest'),
                                session15: 1
                            });
                        }, 500);
                    }

                    // create ga30_sid
                    if (!vm.getCookie('ga30_sid')) {
                        var _randomnumber2 = Math.floor(Math.random() * (1e6 - 1));
                        var _time2 = Date.now();
                        var ga30_sid = vm.sha1(_time2 + '-' + _randomnumber2);
                        vm.setCookie('ga30_sid', ga30_sid, 30);

                        setTimeout(function () {
                            gtag('event', 'start_session', {
                                event_category: 'session',
                                event_label: '30D',
                                theme: vm.getCookie('abTest'),
                                session30: 1
                            });
                        }, 500);
                    }
                }, 500);
            }
        },
        enableNotify: function enableNotify() {
            Notification.requestPermission(function (status) {
                alert("notification status: " + status);

                if (Notification.permission === 'granted') {
                    alert('Granted ...');
                    navigator.serviceWorker.register('sw.js');
                    navigator.serviceWorker.ready.then(function (registration) {
                        registration[0].showNotification('Hello', {
                            body: 'Buzz! Buzz!',
                            vibrate: [200, 100, 200, 100, 200, 100, 200],
                            tag: 'vibration-sample'
                        });
                    });
                } else {
                    alert('No permission');
                }
            });
        },
        initialiseState: function initialiseState() {
            // Are Notifications supported in the service worker?
            if (!('showNotification' in ServiceWorkerRegistration.prototype)) {
                console.warn('Notifications aren\'t supported.');
                return;
            }

            // Check the current Notification permission.
            // If its denied, it's a permanent block until the
            // user changes the permission
            if (Notification.permission === 'denied') {
                console.warn('The user has blocked notifications.');
                return;
            }

            // Check if push messaging is supported
            if (!('PushManager' in window)) {
                console.warn('Push messaging isn\'t supported.');
                return;
            }

            // We need the service worker registration to check for a subscription
            navigator.serviceWorker.ready.then(function (serviceWorkerRegistration) {
                // Do we already have a push message subscription?
                serviceWorkerRegistration.pushManager.getSubscription().then(function (subscription) {
                    // Enable any UI which subscribes / unsubscribes from
                    // push messages.
                    var pushButton = document.querySelector('.js-push-button');
                    pushButton.disabled = false;

                    if (!subscription) {
                        // We aren't subscribed to push, so set UI
                        // to allow the user to enable push
                        return;
                    }

                    // Keep your server in sync with the latest subscriptionId
                    sendSubscriptionToServer(subscription);

                    // Set your UI to show they have subscribed for
                    // push messages
                    pushButton.textContent = 'Disable Push Messages';
                    isPushEnabled = true;
                }).catch(function (err) {
                    console.warn('Error during getSubscription()', err);
                });
            });
        },
        getCookie: function getCookie(name) {
            var value = "; " + document.cookie;
            var parts = value.split("; " + name + "=");
            if (parts.length == 2) return parts.pop().split(";").shift();
        },
        setCookie: function setCookie(cname, cvalue, exdays) {
            var d = new Date();
            d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
            var expires = "expires=" + d.toUTCString();
            document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
        },
        addDate: function addDate(days) {
            Date.prototype.addDays = function (days) {
                var date = new Date(this.valueOf());
                date.setDate(date.getDate() + days);
                console.log(date);
                return date;
            };
        },
        showToast: function showToast(status, header, content) {
            var vm = this;
            vm.toastStatus = status;
            vm.toastHeader = header;
            vm.toastMsg = content;
            $('.toast').toast('show');
        }
    }
});

/***/ }),

/***/ "./resources/sass/app.scss":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__("./resources/js/pages/homepage.js");
module.exports = __webpack_require__("./resources/sass/app.scss");


/***/ })

/******/ });