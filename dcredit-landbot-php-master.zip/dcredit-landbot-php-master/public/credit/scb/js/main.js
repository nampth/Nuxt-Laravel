$.validator.addMethod(
    "regex",
    function (value, element, regexp) {
        var re = new RegExp(regexp);
        return this.optional(element) || re.test(value);
    },
    ""
);

var startTime = new Date().valueOf();
const urlParams = new URLSearchParams(window.location.search);
const myParam = urlParams.get('ref');

const baseUrl = $('#site_env').attr('data-env') == 'local' ? $('#site_meta').attr('data-url') : window.location.origin;

var MainFile = function () {
    var SUCCESS_CODE = 0;
    var totalTime = 0;
    var arrTime = [];

    var startSlide = 0;
    var endSlide = 0;

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="token"]').attr('content')
        }
    });
    var initSelect2 = function () {
        $('select[name="paper"]').select2({
            'multiple': true,
            'width': '100%'
        })
    }

    var handleClickBtn = function () {
        $(".jump").click(function () {
            $('html,body').animate({
                    scrollTop: $("#container").offset().top
                },
                'slow');
        });
        $(".jump1").click(function () {

            $('html,body').animate({
                    scrollTop: $(".module-4:visible").offset().top
                },
                'slow');
        });
        $(".active-popup").click(function () {
            $('#modal-register').modal('show');
        });
        $(".close-popup").click(function () {
            $(".popup").removeClass("active");
        });

    }

    var submitData = function (type) {
        var checkedVals = $('input[name="paper[]"]:checked').map(function () {
            return this.value;
        }).get();

        $.ajax({
            type: "POST",
            url: baseUrl + '/credit/sacombank/register',
            data: {
                'name': $('input[name="fullName"]').val(),
                'phone': $('input[name="phone"]').val(),
                'email': $('input[name="email"]').val(),
                'address': $('#address').val(),
                'income': $('#income').val(),
                'card': $('#card').val(),
                'paper': checkedVals.join(','),
                'type': type
            }, // serializes the form's elements.
            success: function (data) {

            },
            error: function (error) {

            }
        });
    }

    var handleChangeInput = function () {
        $('input').on('blur', function () {
            submitData('log');
        });
        $('#btn-submit').on('click',function () {
            gtag_report_conversion();
        })
    }


    var initValidateFront = function () {
        $('#form-credit').validate({
            ignore: 'input[type=hidden]',
            rules: {
                check: {
                    required: true,
                },
                fullName: {
                    required: true,
                },
                phone: {
                    required: true,
                    regex: /^[0-9]{10,11}$/
                },
                email: {
                    required: true
                },
                address: {
                    required: true
                },
                income: {
                    required: true
                },
                card: {
                    required: true
                },
                agree: {
                    required: true
                },
            },
            messages: {
                check: {
                    required: "Vui lòng trả lời câu hỏi",
                },
                fullName: {
                    required: "Vui lòng điền họ tên của bạn",
                    regex: 'Họ và tên không phù hợp'
                },
                phone: {
                    required: "Vui lòng nhập số điện thoại đăng ký tư vấn",
                    regex: 'Số điện thoại không đúng định dạng'
                },
                email: {
                    required: "Vui lòng nhập Email"
                },
                address: {
                    required: "Vui lòng chọn nơi sinh sống"
                },
                income: {
                    required: "Vui lòng chọn mức thu nhập"
                },
                card: {
                    required: "Vui lòng chọn loại thẻ muốn mở"
                },
                agree: {
                    required: "Bạn cần xác nhận điều khoản"
                },
            },
            errorClass: "help-inline text-danger",
            errorElement: "span",
            highlight: function (element, errorClass, validClass) {
                $(element).parents('.form-group').addClass('has-error');
                return false;
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).parents('.form-group').removeClass('has-error');
                $(element).parents('.form-group').addClass('has-success');
            },
            submitHandler: function (form, e) {

                submitData('data');
                e.preventDefault();
                // $('.close-popup').trigger('click');
                $('#modal-register').modal('hide');
                AccountKit.init(
                    {
                        appId: "404291800431097",
                        state: "true",
                        version: "v1.0",
                        fbAppEventsEnabled: true,
                        redirect: "http://vay.kalapa.vn",
                        debug: false,
                        display: 'modal',
                    }
                );
                AccountKit.login(
                    'PHONE',
                    {
                        countryCode: '+84',
                        phoneNumber: $('input[name="phone"]').val()
                    }, // will use default values if not specified
                    function (response) {

                        if (response.status === "PARTIALLY_AUTHENTICATED") {
                            var dialog = bootbox.dialog({
                                message: '<p class="text-center mb-0"><i class="fa fa-spin fa-spinner"></i> Đang đăng ký...</p>',
                                closeButton: false
                            });
                            var checkedVals = $('input[name="paper[]"]:checked').map(function () {
                                return this.value;
                            }).get();
                            $.ajax({
                                type: "POST",
                                url: baseUrl + '/register',
                                data: {
                                    'code': response.code,
                                    'name': $('input[name="fullName"]').val(),
                                    'phone': $('input[name="phone"]').val(),
                                    'email': $('input[name="email"]').val(),
                                    'address': $('#address').val(),
                                    'income': $('#income').val(),
                                    'card': $('#card').val(),
                                    'paper': checkedVals.join(','),
                                    'type': 'data'
                                }, // serializes the form's elements.
                                success: function (data) {
                                    $('.close-popup').trigger('click');
                                    setTimeout(function () {
                                        dialog.modal('hide');
                                    }, 1000);

                                    if (data.code == SUCCESS_CODE) {
                                        $('input').val('');
                                        toastr.success('Đăng ký thành công.');
                                    } else {
                                        toastr.error("Có lỗi xảy ra, vui lòng thử lại sau.");
                                    }
                                },
                                error: function (error) {
                                    setTimeout(function () {
                                        dialog.modal('hide');
                                    }, 1000);
                                    dialog.modal('hide');
                                    if (error && error.responseJSON) {
                                        error = error.responseJSON;
                                        $.each(error.errors, function (key, value) {
                                            toastr.error(decodeURI(value));
                                        });
                                    } else {
                                        toastr.error("Có lỗi xảy ra, vui lòng thử lại sau.");
                                    }
                                }
                            });
                        } else {

                        }

                    }
                );

            }
        });
    }

    return {
        init() {
            handleChangeInput(),
                initSelect2(),
                handleClickBtn(),
                initValidateFront()
        }
    }
}


$(document).ready(function () {
    MainFile().init();
});
