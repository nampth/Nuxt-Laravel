$.validator.addMethod(
    "regex",
    function (value, element, regexp) {
        var re = new RegExp(regexp);
        return this.optional(element) || re.test(value);
    },
    ""
);

var startTime = new Date().valueOf();
var firstTime = true;
const provinces = [{"province": "H\u00e0 N\u1ed9i", "province_id": "01"}, {
    "province": "H\u00e0 Giang",
    "province_id": "02"
}, {"province": "Cao B\u1eb1ng", "province_id": "04"}, {
    "province": "B\u1eafc K\u1ea1n",
    "province_id": "06"
}, {"province": "Tuy\u00ean Quang", "province_id": "08"}, {
    "province": "L\u00e0o Cai",
    "province_id": "10"
}, {"province": "\u0110i\u1ec7n Bi\u00ean", "province_id": "11"}, {
    "province": "Lai Ch\u00e2u",
    "province_id": "12"
}, {"province": "S\u01a1n La", "province_id": "14"}, {
    "province": "Y\u00ean B\u00e1i",
    "province_id": "15"
}, {"province": "Ho\u00e0 B\u00ecnh", "province_id": "17"}, {
    "province": "Th\u00e1i Nguy\u00ean",
    "province_id": "19"
}, {"province": "L\u1ea1ng S\u01a1n", "province_id": "20"}, {
    "province": "Qu\u1ea3ng Ninh",
    "province_id": "22"
}, {"province": "B\u1eafc Giang", "province_id": "24"}, {
    "province": "Ph\u00fa Th\u1ecd",
    "province_id": "25"
}, {"province": "V\u0129nh Ph\u00fac", "province_id": "26"}, {
    "province": "B\u1eafc Ninh",
    "province_id": "27"
}, {"province": "H\u1ea3i D\u01b0\u01a1ng", "province_id": "30"}, {
    "province": "H\u1ea3i Ph\u00f2ng",
    "province_id": "31"
}, {"province": "H\u01b0ng Y\u00ean", "province_id": "33"}, {
    "province": "Th\u00e1i B\u00ecnh",
    "province_id": "34"
}, {"province": "H\u00e0 Nam", "province_id": "35"}, {
    "province": "Nam \u0110\u1ecbnh",
    "province_id": "36"
}, {"province": "Ninh B\u00ecnh", "province_id": "37"}, {
    "province": "Thanh H\u00f3a",
    "province_id": "38"
}, {"province": "Ngh\u1ec7 An", "province_id": "40"}, {
    "province": "H\u00e0 T\u0129nh",
    "province_id": "42"
}, {"province": "Qu\u1ea3ng B\u00ecnh", "province_id": "44"}, {
    "province": "Qu\u1ea3ng Tr\u1ecb",
    "province_id": "45"
}, {"province": "Th\u1eeba Thi\u00ean Hu\u1ebf", "province_id": "46"}, {
    "province": "\u0110\u00e0 N\u1eb5ng",
    "province_id": "48"
}, {"province": "Qu\u1ea3ng Nam", "province_id": "49"}, {
    "province": "Qu\u1ea3ng Ng\u00e3i",
    "province_id": "51"
}, {"province": "B\u00ecnh \u0110\u1ecbnh", "province_id": "52"}, {
    "province": "Ph\u00fa Y\u00ean",
    "province_id": "54"
}, {"province": "Kh\u00e1nh H\u00f2a", "province_id": "56"}, {
    "province": "Ninh Thu\u1eadn",
    "province_id": "58"
}, {"province": "B\u00ecnh Thu\u1eadn", "province_id": "60"}, {
    "province": "Kon Tum",
    "province_id": "62"
}, {"province": "Gia Lai", "province_id": "64"}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "province_id": "66"
}, {"province": "\u0110\u1eafk N\u00f4ng", "province_id": "67"}, {
    "province": "L\u00e2m \u0110\u1ed3ng",
    "province_id": "68"
}, {"province": "B\u00ecnh Ph\u01b0\u1edbc", "province_id": "70"}, {
    "province": "T\u00e2y Ninh",
    "province_id": "72"
}, {"province": "B\u00ecnh D\u01b0\u01a1ng", "province_id": "74"}, {
    "province": "\u0110\u1ed3ng Nai",
    "province_id": "75"
}, {"province": "B\u00e0 R\u1ecba - V\u0169ng T\u00e0u", "province_id": "77"}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "province_id": "79"
}, {"province": "Long An", "province_id": "80"}, {
    "province": "Ti\u1ec1n Giang",
    "province_id": "82"
}, {"province": "B\u1ebfn Tre", "province_id": "83"}, {
    "province": "Tr\u00e0 Vinh",
    "province_id": "84"
}, {"province": "V\u0129nh Long", "province_id": "86"}, {
    "province": "\u0110\u1ed3ng Th\u00e1p",
    "province_id": "87"
}, {"province": "An Giang", "province_id": "89"}, {
    "province": "Ki\u00ean Giang",
    "province_id": "91"
}, {"province": "C\u1ea7n Th\u01a1", "province_id": "92"}, {
    "province": "H\u1eadu Giang",
    "province_id": "93"
}, {"province": "S\u00f3c Tr\u0103ng", "province_id": "94"}, {
    "province": "B\u1ea1c Li\u00eau",
    "province_id": "95"
}, {"province": "C\u00e0 Mau", "province_id": "96"}];
const districts = [{
    "province": "H\u00e0 N\u1ed9i",
    "district": "Qu\u1eadn Ba \u0110\u00ecnh"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Qu\u1eadn Ho\u00e0n Ki\u1ebfm"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Qu\u1eadn T\u00e2y H\u1ed3"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Qu\u1eadn Long Bi\u00ean"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Qu\u1eadn C\u1ea7u Gi\u1ea5y"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Qu\u1eadn \u0110\u1ed1ng \u0110a"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Qu\u1eadn Hai B\u00e0 Tr\u01b0ng"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Qu\u1eadn Ho\u00e0ng Mai"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Qu\u1eadn Thanh Xu\u00e2n"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Huy\u1ec7n S\u00f3c S\u01a1n"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Huy\u1ec7n \u0110\u00f4ng Anh"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Huy\u1ec7n Gia L\u00e2m"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Qu\u1eadn Nam T\u1eeb Li\u00eam"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Huy\u1ec7n Thanh Tr\u00ec"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Qu\u1eadn B\u1eafc T\u1eeb Li\u00eam"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Huy\u1ec7n M\u00ea Linh"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Qu\u1eadn H\u00e0 \u0110\u00f4ng"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Th\u1ecb x\u00e3 S\u01a1n T\u00e2y"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Huy\u1ec7n Ba V\u00ec"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Huy\u1ec7n Ph\u00fac Th\u1ecd"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Huy\u1ec7n \u0110an Ph\u01b0\u1ee3ng"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Huy\u1ec7n Ho\u00e0i \u0110\u1ee9c"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Huy\u1ec7n Qu\u1ed1c Oai"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Huy\u1ec7n Th\u1ea1ch Th\u1ea5t"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Huy\u1ec7n Ch\u01b0\u01a1ng M\u1ef9"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Huy\u1ec7n Thanh Oai"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Huy\u1ec7n Th\u01b0\u1eddng T\u00edn"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Huy\u1ec7n Ph\u00fa Xuy\u00ean"}, {
    "province": "H\u00e0 N\u1ed9i",
    "district": "Huy\u1ec7n \u1ee8ng H\u00f2a"
}, {"province": "H\u00e0 N\u1ed9i", "district": "Huy\u1ec7n M\u1ef9 \u0110\u1ee9c"}, {
    "province": "H\u00e0 Giang",
    "district": "Th\u00e0nh ph\u1ed1 H\u00e0 Giang"
}, {"province": "H\u00e0 Giang", "district": "Huy\u1ec7n \u0110\u1ed3ng V\u0103n"}, {
    "province": "H\u00e0 Giang",
    "district": "Huy\u1ec7n M\u00e8o V\u1ea1c"
}, {"province": "H\u00e0 Giang", "district": "Huy\u1ec7n Y\u00ean Minh"}, {
    "province": "H\u00e0 Giang",
    "district": "Huy\u1ec7n Qu\u1ea3n B\u1ea1"
}, {"province": "H\u00e0 Giang", "district": "Huy\u1ec7n V\u1ecb Xuy\u00ean"}, {
    "province": "H\u00e0 Giang",
    "district": "Huy\u1ec7n B\u1eafc M\u00ea"
}, {"province": "H\u00e0 Giang", "district": "Huy\u1ec7n Ho\u00e0ng Su Ph\u00ec"}, {
    "province": "H\u00e0 Giang",
    "district": "Huy\u1ec7n X\u00edn M\u1ea7n"
}, {"province": "H\u00e0 Giang", "district": "Huy\u1ec7n B\u1eafc Quang"}, {
    "province": "H\u00e0 Giang",
    "district": "Huy\u1ec7n Quang B\u00ecnh"
}, {"province": "Cao B\u1eb1ng", "district": "Th\u00e0nh ph\u1ed1 Cao B\u1eb1ng"}, {
    "province": "Cao B\u1eb1ng",
    "district": "Huy\u1ec7n B\u1ea3o L\u00e2m"
}, {"province": "Cao B\u1eb1ng", "district": "Huy\u1ec7n B\u1ea3o L\u1ea1c"}, {
    "province": "Cao B\u1eb1ng",
    "district": "Huy\u1ec7n Th\u00f4ng N\u00f4ng"
}, {"province": "Cao B\u1eb1ng", "district": "Huy\u1ec7n H\u00e0 Qu\u1ea3ng"}, {
    "province": "Cao B\u1eb1ng",
    "district": "Huy\u1ec7n Tr\u00e0 L\u0129nh"
}, {"province": "Cao B\u1eb1ng", "district": "Huy\u1ec7n Tr\u00f9ng Kh\u00e1nh"}, {
    "province": "Cao B\u1eb1ng",
    "district": "Huy\u1ec7n H\u1ea1 Lang"
}, {"province": "Cao B\u1eb1ng", "district": "Huy\u1ec7n Qu\u1ea3ng Uy\u00ean"}, {
    "province": "Cao B\u1eb1ng",
    "district": "Huy\u1ec7n Ph\u1ee5c Ho\u00e0"
}, {"province": "Cao B\u1eb1ng", "district": "Huy\u1ec7n Ho\u00e0 An"}, {
    "province": "Cao B\u1eb1ng",
    "district": "Huy\u1ec7n Nguy\u00ean B\u00ecnh"
}, {"province": "Cao B\u1eb1ng", "district": "Huy\u1ec7n Th\u1ea1ch An"}, {
    "province": "B\u1eafc K\u1ea1n",
    "district": "Th\u00e0nh Ph\u1ed1 B\u1eafc K\u1ea1n"
}, {"province": "B\u1eafc K\u1ea1n", "district": "Huy\u1ec7n P\u00e1c N\u1eb7m"}, {
    "province": "B\u1eafc K\u1ea1n",
    "district": "Huy\u1ec7n Ba B\u1ec3"
}, {"province": "B\u1eafc K\u1ea1n", "district": "Huy\u1ec7n Ng\u00e2n S\u01a1n"}, {
    "province": "B\u1eafc K\u1ea1n",
    "district": "Huy\u1ec7n B\u1ea1ch Th\u00f4ng"
}, {"province": "B\u1eafc K\u1ea1n", "district": "Huy\u1ec7n Ch\u1ee3 \u0110\u1ed3n"}, {
    "province": "B\u1eafc K\u1ea1n",
    "district": "Huy\u1ec7n Ch\u1ee3 M\u1edbi"
}, {"province": "B\u1eafc K\u1ea1n", "district": "Huy\u1ec7n Na R\u00ec"}, {
    "province": "Tuy\u00ean Quang",
    "district": "Th\u00e0nh ph\u1ed1 Tuy\u00ean Quang"
}, {"province": "Tuy\u00ean Quang", "district": "Huy\u1ec7n L\u00e2m B\u00ecnh"}, {
    "province": "Tuy\u00ean Quang",
    "district": "Huy\u1ec7n Na Hang"
}, {"province": "Tuy\u00ean Quang", "district": "Huy\u1ec7n Chi\u00eam H\u00f3a"}, {
    "province": "Tuy\u00ean Quang",
    "district": "Huy\u1ec7n H\u00e0m Y\u00ean"
}, {"province": "Tuy\u00ean Quang", "district": "Huy\u1ec7n Y\u00ean S\u01a1n"}, {
    "province": "Tuy\u00ean Quang",
    "district": "Huy\u1ec7n S\u01a1n D\u01b0\u01a1ng"
}, {"province": "L\u00e0o Cai", "district": "Th\u00e0nh ph\u1ed1 L\u00e0o Cai"}, {
    "province": "L\u00e0o Cai",
    "district": "Huy\u1ec7n B\u00e1t X\u00e1t"
}, {"province": "L\u00e0o Cai", "district": "Huy\u1ec7n M\u01b0\u1eddng Kh\u01b0\u01a1ng"}, {
    "province": "L\u00e0o Cai",
    "district": "Huy\u1ec7n Si Ma Cai"
}, {"province": "L\u00e0o Cai", "district": "Huy\u1ec7n B\u1eafc H\u00e0"}, {
    "province": "L\u00e0o Cai",
    "district": "Huy\u1ec7n B\u1ea3o Th\u1eafng"
}, {"province": "L\u00e0o Cai", "district": "Huy\u1ec7n B\u1ea3o Y\u00ean"}, {
    "province": "L\u00e0o Cai",
    "district": "Huy\u1ec7n Sa Pa"
}, {"province": "L\u00e0o Cai", "district": "Huy\u1ec7n V\u0103n B\u00e0n"}, {
    "province": "\u0110i\u1ec7n Bi\u00ean",
    "district": "Th\u00e0nh ph\u1ed1 \u0110i\u1ec7n Bi\u00ean Ph\u1ee7"
}, {
    "province": "\u0110i\u1ec7n Bi\u00ean",
    "district": "Th\u1ecb X\u00e3 M\u01b0\u1eddng Lay"
}, {
    "province": "\u0110i\u1ec7n Bi\u00ean",
    "district": "Huy\u1ec7n M\u01b0\u1eddng Nh\u00e9"
}, {
    "province": "\u0110i\u1ec7n Bi\u00ean",
    "district": "Huy\u1ec7n M\u01b0\u1eddng Ch\u00e0"
}, {
    "province": "\u0110i\u1ec7n Bi\u00ean",
    "district": "Huy\u1ec7n T\u1ee7a Ch\u00f9a"
}, {
    "province": "\u0110i\u1ec7n Bi\u00ean",
    "district": "Huy\u1ec7n Tu\u1ea7n Gi\u00e1o"
}, {
    "province": "\u0110i\u1ec7n Bi\u00ean",
    "district": "Huy\u1ec7n \u0110i\u1ec7n Bi\u00ean"
}, {
    "province": "\u0110i\u1ec7n Bi\u00ean",
    "district": "Huy\u1ec7n \u0110i\u1ec7n Bi\u00ean \u0110\u00f4ng"
}, {
    "province": "\u0110i\u1ec7n Bi\u00ean",
    "district": "Huy\u1ec7n M\u01b0\u1eddng \u1ea2ng"
}, {"province": "\u0110i\u1ec7n Bi\u00ean", "district": "Huy\u1ec7n N\u1eadm P\u1ed3"}, {
    "province": "Lai Ch\u00e2u",
    "district": "Th\u00e0nh ph\u1ed1 Lai Ch\u00e2u"
}, {"province": "Lai Ch\u00e2u", "district": "Huy\u1ec7n Tam \u0110\u01b0\u1eddng"}, {
    "province": "Lai Ch\u00e2u",
    "district": "Huy\u1ec7n M\u01b0\u1eddng T\u00e8"
}, {"province": "Lai Ch\u00e2u", "district": "Huy\u1ec7n S\u00ecn H\u1ed3"}, {
    "province": "Lai Ch\u00e2u",
    "district": "Huy\u1ec7n Phong Th\u1ed5"
}, {"province": "Lai Ch\u00e2u", "district": "Huy\u1ec7n Than Uy\u00ean"}, {
    "province": "Lai Ch\u00e2u",
    "district": "Huy\u1ec7n T\u00e2n Uy\u00ean"
}, {"province": "Lai Ch\u00e2u", "district": "Huy\u1ec7n N\u1eadm Nh\u00f9n"}, {
    "province": "S\u01a1n La",
    "district": "Th\u00e0nh ph\u1ed1 S\u01a1n La"
}, {"province": "S\u01a1n La", "district": "Huy\u1ec7n Qu\u1ef3nh Nhai"}, {
    "province": "S\u01a1n La",
    "district": "Huy\u1ec7n Thu\u1eadn Ch\u00e2u"
}, {"province": "S\u01a1n La", "district": "Huy\u1ec7n M\u01b0\u1eddng La"}, {
    "province": "S\u01a1n La",
    "district": "Huy\u1ec7n B\u1eafc Y\u00ean"
}, {"province": "S\u01a1n La", "district": "Huy\u1ec7n Ph\u00f9 Y\u00ean"}, {
    "province": "S\u01a1n La",
    "district": "Huy\u1ec7n M\u1ed9c Ch\u00e2u"
}, {"province": "S\u01a1n La", "district": "Huy\u1ec7n Y\u00ean Ch\u00e2u"}, {
    "province": "S\u01a1n La",
    "district": "Huy\u1ec7n Mai S\u01a1n"
}, {"province": "S\u01a1n La", "district": "Huy\u1ec7n S\u00f4ng M\u00e3"}, {
    "province": "S\u01a1n La",
    "district": "Huy\u1ec7n S\u1ed1p C\u1ed9p"
}, {"province": "S\u01a1n La", "district": "Huy\u1ec7n V\u00e2n H\u1ed3"}, {
    "province": "Y\u00ean B\u00e1i",
    "district": "Th\u00e0nh ph\u1ed1 Y\u00ean B\u00e1i"
}, {
    "province": "Y\u00ean B\u00e1i",
    "district": "Th\u1ecb x\u00e3 Ngh\u0129a L\u1ed9"
}, {"province": "Y\u00ean B\u00e1i", "district": "Huy\u1ec7n L\u1ee5c Y\u00ean"}, {
    "province": "Y\u00ean B\u00e1i",
    "district": "Huy\u1ec7n V\u0103n Y\u00ean"
}, {
    "province": "Y\u00ean B\u00e1i",
    "district": "Huy\u1ec7n M\u00f9 C\u0103ng Ch\u1ea3i"
}, {"province": "Y\u00ean B\u00e1i", "district": "Huy\u1ec7n Tr\u1ea5n Y\u00ean"}, {
    "province": "Y\u00ean B\u00e1i",
    "district": "Huy\u1ec7n Tr\u1ea1m T\u1ea5u"
}, {"province": "Y\u00ean B\u00e1i", "district": "Huy\u1ec7n V\u0103n Ch\u1ea5n"}, {
    "province": "Y\u00ean B\u00e1i",
    "district": "Huy\u1ec7n Y\u00ean B\u00ecnh"
}, {
    "province": "Ho\u00e0 B\u00ecnh",
    "district": "Th\u00e0nh ph\u1ed1 H\u00f2a B\u00ecnh"
}, {
    "province": "Ho\u00e0 B\u00ecnh",
    "district": "Huy\u1ec7n \u0110\u00e0 B\u1eafc"
}, {"province": "Ho\u00e0 B\u00ecnh", "district": "Huy\u1ec7n K\u1ef3 S\u01a1n"}, {
    "province": "Ho\u00e0 B\u00ecnh",
    "district": "Huy\u1ec7n L\u01b0\u01a1ng S\u01a1n"
}, {"province": "Ho\u00e0 B\u00ecnh", "district": "Huy\u1ec7n Kim B\u00f4i"}, {
    "province": "Ho\u00e0 B\u00ecnh",
    "district": "Huy\u1ec7n Cao Phong"
}, {"province": "Ho\u00e0 B\u00ecnh", "district": "Huy\u1ec7n T\u00e2n L\u1ea1c"}, {
    "province": "Ho\u00e0 B\u00ecnh",
    "district": "Huy\u1ec7n Mai Ch\u00e2u"
}, {"province": "Ho\u00e0 B\u00ecnh", "district": "Huy\u1ec7n L\u1ea1c S\u01a1n"}, {
    "province": "Ho\u00e0 B\u00ecnh",
    "district": "Huy\u1ec7n Y\u00ean Th\u1ee7y"
}, {
    "province": "Ho\u00e0 B\u00ecnh",
    "district": "Huy\u1ec7n L\u1ea1c Th\u1ee7y"
}, {
    "province": "Th\u00e1i Nguy\u00ean",
    "district": "Th\u00e0nh ph\u1ed1 Th\u00e1i Nguy\u00ean"
}, {
    "province": "Th\u00e1i Nguy\u00ean",
    "district": "Th\u00e0nh ph\u1ed1 S\u00f4ng C\u00f4ng"
}, {
    "province": "Th\u00e1i Nguy\u00ean",
    "district": "Huy\u1ec7n \u0110\u1ecbnh H\u00f3a"
}, {
    "province": "Th\u00e1i Nguy\u00ean",
    "district": "Huy\u1ec7n Ph\u00fa L\u01b0\u01a1ng"
}, {
    "province": "Th\u00e1i Nguy\u00ean",
    "district": "Huy\u1ec7n \u0110\u1ed3ng H\u1ef7"
}, {"province": "Th\u00e1i Nguy\u00ean", "district": "Huy\u1ec7n V\u00f5 Nhai"}, {
    "province": "Th\u00e1i Nguy\u00ean",
    "district": "Huy\u1ec7n \u0110\u1ea1i T\u1eeb"
}, {
    "province": "Th\u00e1i Nguy\u00ean",
    "district": "Th\u1ecb x\u00e3 Ph\u1ed5 Y\u00ean"
}, {
    "province": "Th\u00e1i Nguy\u00ean",
    "district": "Huy\u1ec7n Ph\u00fa B\u00ecnh"
}, {
    "province": "L\u1ea1ng S\u01a1n",
    "district": "Th\u00e0nh ph\u1ed1 L\u1ea1ng S\u01a1n"
}, {
    "province": "L\u1ea1ng S\u01a1n",
    "district": "Huy\u1ec7n Tr\u00e0ng \u0110\u1ecbnh"
}, {"province": "L\u1ea1ng S\u01a1n", "district": "Huy\u1ec7n B\u00ecnh Gia"}, {
    "province": "L\u1ea1ng S\u01a1n",
    "district": "Huy\u1ec7n V\u0103n L\u00e3ng"
}, {"province": "L\u1ea1ng S\u01a1n", "district": "Huy\u1ec7n Cao L\u1ed9c"}, {
    "province": "L\u1ea1ng S\u01a1n",
    "district": "Huy\u1ec7n V\u0103n Quan"
}, {"province": "L\u1ea1ng S\u01a1n", "district": "Huy\u1ec7n B\u1eafc S\u01a1n"}, {
    "province": "L\u1ea1ng S\u01a1n",
    "district": "Huy\u1ec7n H\u1eefu L\u0169ng"
}, {"province": "L\u1ea1ng S\u01a1n", "district": "Huy\u1ec7n Chi L\u0103ng"}, {
    "province": "L\u1ea1ng S\u01a1n",
    "district": "Huy\u1ec7n L\u1ed9c B\u00ecnh"
}, {"province": "L\u1ea1ng S\u01a1n", "district": "Huy\u1ec7n \u0110\u00ecnh L\u1eadp"}, {
    "province": "Qu\u1ea3ng Ninh",
    "district": "Th\u00e0nh ph\u1ed1 H\u1ea1 Long"
}, {
    "province": "Qu\u1ea3ng Ninh",
    "district": "Th\u00e0nh ph\u1ed1 M\u00f3ng C\u00e1i"
}, {"province": "Qu\u1ea3ng Ninh", "district": "Th\u00e0nh ph\u1ed1 C\u1ea9m Ph\u1ea3"}, {
    "province": "Qu\u1ea3ng Ninh",
    "district": "Th\u00e0nh ph\u1ed1 U\u00f4ng B\u00ed"
}, {"province": "Qu\u1ea3ng Ninh", "district": "Huy\u1ec7n B\u00ecnh Li\u00eau"}, {
    "province": "Qu\u1ea3ng Ninh",
    "district": "Huy\u1ec7n Ti\u00ean Y\u00ean"
}, {"province": "Qu\u1ea3ng Ninh", "district": "Huy\u1ec7n \u0110\u1ea7m H\u00e0"}, {
    "province": "Qu\u1ea3ng Ninh",
    "district": "Huy\u1ec7n H\u1ea3i H\u00e0"
}, {"province": "Qu\u1ea3ng Ninh", "district": "Huy\u1ec7n Ba Ch\u1ebd"}, {
    "province": "Qu\u1ea3ng Ninh",
    "district": "Huy\u1ec7n V\u00e2n \u0110\u1ed3n"
}, {"province": "Qu\u1ea3ng Ninh", "district": "Huy\u1ec7n Ho\u00e0nh B\u1ed3"}, {
    "province": "Qu\u1ea3ng Ninh",
    "district": "Th\u1ecb x\u00e3 \u0110\u00f4ng Tri\u1ec1u"
}, {"province": "Qu\u1ea3ng Ninh", "district": "Th\u1ecb x\u00e3 Qu\u1ea3ng Y\u00ean"}, {
    "province": "Qu\u1ea3ng Ninh",
    "district": "Huy\u1ec7n C\u00f4 T\u00f4"
}, {"province": "B\u1eafc Giang", "district": "Th\u00e0nh ph\u1ed1 B\u1eafc Giang"}, {
    "province": "B\u1eafc Giang",
    "district": "Huy\u1ec7n Y\u00ean Th\u1ebf"
}, {"province": "B\u1eafc Giang", "district": "Huy\u1ec7n T\u00e2n Y\u00ean"}, {
    "province": "B\u1eafc Giang",
    "district": "Huy\u1ec7n L\u1ea1ng Giang"
}, {"province": "B\u1eafc Giang", "district": "Huy\u1ec7n L\u1ee5c Nam"}, {
    "province": "B\u1eafc Giang",
    "district": "Huy\u1ec7n L\u1ee5c Ng\u1ea1n"
}, {"province": "B\u1eafc Giang", "district": "Huy\u1ec7n S\u01a1n \u0110\u1ed9ng"}, {
    "province": "B\u1eafc Giang",
    "district": "Huy\u1ec7n Y\u00ean D\u0169ng"
}, {"province": "B\u1eafc Giang", "district": "Huy\u1ec7n Vi\u1ec7t Y\u00ean"}, {
    "province": "B\u1eafc Giang",
    "district": "Huy\u1ec7n Hi\u1ec7p H\u00f2a"
}, {
    "province": "Ph\u00fa Th\u1ecd",
    "district": "Th\u00e0nh ph\u1ed1 Vi\u1ec7t Tr\u00ec"
}, {
    "province": "Ph\u00fa Th\u1ecd",
    "district": "Th\u1ecb x\u00e3 Ph\u00fa Th\u1ecd"
}, {"province": "Ph\u00fa Th\u1ecd", "district": "Huy\u1ec7n \u0110oan H\u00f9ng"}, {
    "province": "Ph\u00fa Th\u1ecd",
    "district": "Huy\u1ec7n H\u1ea1 Ho\u00e0"
}, {"province": "Ph\u00fa Th\u1ecd", "district": "Huy\u1ec7n Thanh Ba"}, {
    "province": "Ph\u00fa Th\u1ecd",
    "district": "Huy\u1ec7n Ph\u00f9 Ninh"
}, {"province": "Ph\u00fa Th\u1ecd", "district": "Huy\u1ec7n Y\u00ean L\u1eadp"}, {
    "province": "Ph\u00fa Th\u1ecd",
    "district": "Huy\u1ec7n C\u1ea9m Kh\u00ea"
}, {"province": "Ph\u00fa Th\u1ecd", "district": "Huy\u1ec7n Tam N\u00f4ng"}, {
    "province": "Ph\u00fa Th\u1ecd",
    "district": "Huy\u1ec7n L\u00e2m Thao"
}, {"province": "Ph\u00fa Th\u1ecd", "district": "Huy\u1ec7n Thanh S\u01a1n"}, {
    "province": "Ph\u00fa Th\u1ecd",
    "district": "Huy\u1ec7n Thanh Thu\u1ef7"
}, {"province": "Ph\u00fa Th\u1ecd", "district": "Huy\u1ec7n T\u00e2n S\u01a1n"}, {
    "province": "V\u0129nh Ph\u00fac",
    "district": "Th\u00e0nh ph\u1ed1 V\u0129nh Y\u00ean"
}, {
    "province": "V\u0129nh Ph\u00fac",
    "district": "Th\u00e0nh ph\u1ed1 Ph\u00fac Y\u00ean"
}, {
    "province": "V\u0129nh Ph\u00fac",
    "district": "Huy\u1ec7n L\u1eadp Th\u1ea1ch"
}, {
    "province": "V\u0129nh Ph\u00fac",
    "district": "Huy\u1ec7n Tam D\u01b0\u01a1ng"
}, {"province": "V\u0129nh Ph\u00fac", "district": "Huy\u1ec7n Tam \u0110\u1ea3o"}, {
    "province": "V\u0129nh Ph\u00fac",
    "district": "Huy\u1ec7n B\u00ecnh Xuy\u00ean"
}, {"province": "V\u0129nh Ph\u00fac", "district": "Huy\u1ec7n Y\u00ean L\u1ea1c"}, {
    "province": "V\u0129nh Ph\u00fac",
    "district": "Huy\u1ec7n V\u0129nh T\u01b0\u1eddng"
}, {"province": "V\u0129nh Ph\u00fac", "district": "Huy\u1ec7n S\u00f4ng L\u00f4"}, {
    "province": "B\u1eafc Ninh",
    "district": "Th\u00e0nh ph\u1ed1 B\u1eafc Ninh"
}, {"province": "B\u1eafc Ninh", "district": "Huy\u1ec7n Y\u00ean Phong"}, {
    "province": "B\u1eafc Ninh",
    "district": "Huy\u1ec7n Qu\u1ebf V\u00f5"
}, {"province": "B\u1eafc Ninh", "district": "Huy\u1ec7n Ti\u00ean Du"}, {
    "province": "B\u1eafc Ninh",
    "district": "Th\u1ecb x\u00e3 T\u1eeb S\u01a1n"
}, {"province": "B\u1eafc Ninh", "district": "Huy\u1ec7n Thu\u1eadn Th\u00e0nh"}, {
    "province": "B\u1eafc Ninh",
    "district": "Huy\u1ec7n Gia B\u00ecnh"
}, {
    "province": "B\u1eafc Ninh",
    "district": "Huy\u1ec7n L\u01b0\u01a1ng T\u00e0i"
}, {
    "province": "H\u1ea3i D\u01b0\u01a1ng",
    "district": "Th\u00e0nh ph\u1ed1 H\u1ea3i D\u01b0\u01a1ng"
}, {
    "province": "H\u1ea3i D\u01b0\u01a1ng",
    "district": "Th\u00e0nh ph\u1ed1 Ch\u00ed Linh"
}, {
    "province": "H\u1ea3i D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n Nam S\u00e1ch"
}, {
    "province": "H\u1ea3i D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n Kinh M\u00f4n"
}, {
    "province": "H\u1ea3i D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n Kim Th\u00e0nh"
}, {
    "province": "H\u1ea3i D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n Thanh H\u00e0"
}, {
    "province": "H\u1ea3i D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n C\u1ea9m Gi\u00e0ng"
}, {
    "province": "H\u1ea3i D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n B\u00ecnh Giang"
}, {
    "province": "H\u1ea3i D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n Gia L\u1ed9c"
}, {
    "province": "H\u1ea3i D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n T\u1ee9 K\u1ef3"
}, {
    "province": "H\u1ea3i D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n Ninh Giang"
}, {
    "province": "H\u1ea3i D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n Thanh Mi\u1ec7n"
}, {"province": "H\u1ea3i Ph\u00f2ng", "district": "Qu\u1eadn H\u1ed3ng B\u00e0ng"}, {
    "province": "H\u1ea3i Ph\u00f2ng",
    "district": "Qu\u1eadn Ng\u00f4 Quy\u1ec1n"
}, {"province": "H\u1ea3i Ph\u00f2ng", "district": "Qu\u1eadn L\u00ea Ch\u00e2n"}, {
    "province": "H\u1ea3i Ph\u00f2ng",
    "district": "Qu\u1eadn H\u1ea3i An"
}, {"province": "H\u1ea3i Ph\u00f2ng", "district": "Qu\u1eadn Ki\u1ebfn An"}, {
    "province": "H\u1ea3i Ph\u00f2ng",
    "district": "Qu\u1eadn \u0110\u1ed3 S\u01a1n"
}, {
    "province": "H\u1ea3i Ph\u00f2ng",
    "district": "Qu\u1eadn D\u01b0\u01a1ng Kinh"
}, {
    "province": "H\u1ea3i Ph\u00f2ng",
    "district": "Huy\u1ec7n Thu\u1ef7 Nguy\u00ean"
}, {"province": "H\u1ea3i Ph\u00f2ng", "district": "Huy\u1ec7n An D\u01b0\u01a1ng"}, {
    "province": "H\u1ea3i Ph\u00f2ng",
    "district": "Huy\u1ec7n An L\u00e3o"
}, {
    "province": "H\u1ea3i Ph\u00f2ng",
    "district": "Huy\u1ec7n Ki\u1ebfn Thu\u1ef5"
}, {
    "province": "H\u1ea3i Ph\u00f2ng",
    "district": "Huy\u1ec7n Ti\u00ean L\u00e3ng"
}, {"province": "H\u1ea3i Ph\u00f2ng", "district": "Huy\u1ec7n V\u0129nh B\u1ea3o"}, {
    "province": "H\u1ea3i Ph\u00f2ng",
    "district": "Huy\u1ec7n C\u00e1t H\u1ea3i"
}, {
    "province": "H\u01b0ng Y\u00ean",
    "district": "Th\u00e0nh ph\u1ed1 H\u01b0ng Y\u00ean"
}, {"province": "H\u01b0ng Y\u00ean", "district": "Huy\u1ec7n V\u0103n L\u00e2m"}, {
    "province": "H\u01b0ng Y\u00ean",
    "district": "Huy\u1ec7n V\u0103n Giang"
}, {"province": "H\u01b0ng Y\u00ean", "district": "Huy\u1ec7n Y\u00ean M\u1ef9"}, {
    "province": "H\u01b0ng Y\u00ean",
    "district": "Th\u1ecb x\u00e3 M\u1ef9 H\u00e0o"
}, {"province": "H\u01b0ng Y\u00ean", "district": "Huy\u1ec7n \u00c2n Thi"}, {
    "province": "H\u01b0ng Y\u00ean",
    "district": "Huy\u1ec7n Kho\u00e1i Ch\u00e2u"
}, {"province": "H\u01b0ng Y\u00ean", "district": "Huy\u1ec7n Kim \u0110\u1ed9ng"}, {
    "province": "H\u01b0ng Y\u00ean",
    "district": "Huy\u1ec7n Ti\u00ean L\u1eef"
}, {"province": "H\u01b0ng Y\u00ean", "district": "Huy\u1ec7n Ph\u00f9 C\u1eeb"}, {
    "province": "Th\u00e1i B\u00ecnh",
    "district": "Th\u00e0nh ph\u1ed1 Th\u00e1i B\u00ecnh"
}, {
    "province": "Th\u00e1i B\u00ecnh",
    "district": "Huy\u1ec7n Qu\u1ef3nh Ph\u1ee5"
}, {"province": "Th\u00e1i B\u00ecnh", "district": "Huy\u1ec7n H\u01b0ng H\u00e0"}, {
    "province": "Th\u00e1i B\u00ecnh",
    "district": "Huy\u1ec7n \u0110\u00f4ng H\u01b0ng"
}, {
    "province": "Th\u00e1i B\u00ecnh",
    "district": "Huy\u1ec7n Th\u00e1i Th\u1ee5y"
}, {"province": "Th\u00e1i B\u00ecnh", "district": "Huy\u1ec7n Ti\u1ec1n H\u1ea3i"}, {
    "province": "Th\u00e1i B\u00ecnh",
    "district": "Huy\u1ec7n Ki\u1ebfn X\u01b0\u01a1ng"
}, {"province": "Th\u00e1i B\u00ecnh", "district": "Huy\u1ec7n V\u0169 Th\u01b0"}, {
    "province": "H\u00e0 Nam",
    "district": "Th\u00e0nh ph\u1ed1 Ph\u1ee7 L\u00fd"
}, {"province": "H\u00e0 Nam", "district": "Huy\u1ec7n Duy Ti\u00ean"}, {
    "province": "H\u00e0 Nam",
    "district": "Huy\u1ec7n Kim B\u1ea3ng"
}, {"province": "H\u00e0 Nam", "district": "Huy\u1ec7n Thanh Li\u00eam"}, {
    "province": "H\u00e0 Nam",
    "district": "Huy\u1ec7n B\u00ecnh L\u1ee5c"
}, {"province": "H\u00e0 Nam", "district": "Huy\u1ec7n L\u00fd Nh\u00e2n"}, {
    "province": "Nam \u0110\u1ecbnh",
    "district": "Th\u00e0nh ph\u1ed1 Nam \u0110\u1ecbnh"
}, {"province": "Nam \u0110\u1ecbnh", "district": "Huy\u1ec7n M\u1ef9 L\u1ed9c"}, {
    "province": "Nam \u0110\u1ecbnh",
    "district": "Huy\u1ec7n V\u1ee5 B\u1ea3n"
}, {"province": "Nam \u0110\u1ecbnh", "district": "Huy\u1ec7n \u00dd Y\u00ean"}, {
    "province": "Nam \u0110\u1ecbnh",
    "district": "Huy\u1ec7n Ngh\u0129a H\u01b0ng"
}, {"province": "Nam \u0110\u1ecbnh", "district": "Huy\u1ec7n Nam Tr\u1ef1c"}, {
    "province": "Nam \u0110\u1ecbnh",
    "district": "Huy\u1ec7n Tr\u1ef1c Ninh"
}, {
    "province": "Nam \u0110\u1ecbnh",
    "district": "Huy\u1ec7n Xu\u00e2n Tr\u01b0\u1eddng"
}, {"province": "Nam \u0110\u1ecbnh", "district": "Huy\u1ec7n Giao Th\u1ee7y"}, {
    "province": "Nam \u0110\u1ecbnh",
    "district": "Huy\u1ec7n H\u1ea3i H\u1eadu"
}, {"province": "Ninh B\u00ecnh", "district": "Th\u00e0nh ph\u1ed1 Ninh B\u00ecnh"}, {
    "province": "Ninh B\u00ecnh",
    "district": "Th\u00e0nh ph\u1ed1 Tam \u0110i\u1ec7p"
}, {"province": "Ninh B\u00ecnh", "district": "Huy\u1ec7n Nho Quan"}, {
    "province": "Ninh B\u00ecnh",
    "district": "Huy\u1ec7n Gia Vi\u1ec5n"
}, {"province": "Ninh B\u00ecnh", "district": "Huy\u1ec7n Hoa L\u01b0"}, {
    "province": "Ninh B\u00ecnh",
    "district": "Huy\u1ec7n Y\u00ean Kh\u00e1nh"
}, {"province": "Ninh B\u00ecnh", "district": "Huy\u1ec7n Kim S\u01a1n"}, {
    "province": "Ninh B\u00ecnh",
    "district": "Huy\u1ec7n Y\u00ean M\u00f4"
}, {"province": "Thanh H\u00f3a", "district": "Th\u00e0nh ph\u1ed1 Thanh H\u00f3a"}, {
    "province": "Thanh H\u00f3a",
    "district": "Th\u1ecb x\u00e3 B\u1ec9m S\u01a1n"
}, {"province": "Thanh H\u00f3a", "district": "Th\u00e0nh ph\u1ed1 S\u1ea7m S\u01a1n"}, {
    "province": "Thanh H\u00f3a",
    "district": "Huy\u1ec7n M\u01b0\u1eddng L\u00e1t"
}, {"province": "Thanh H\u00f3a", "district": "Huy\u1ec7n Quan H\u00f3a"}, {
    "province": "Thanh H\u00f3a",
    "district": "Huy\u1ec7n B\u00e1 Th\u01b0\u1edbc"
}, {"province": "Thanh H\u00f3a", "district": "Huy\u1ec7n Quan S\u01a1n"}, {
    "province": "Thanh H\u00f3a",
    "district": "Huy\u1ec7n Lang Ch\u00e1nh"
}, {"province": "Thanh H\u00f3a", "district": "Huy\u1ec7n Ng\u1ecdc L\u1eb7c"}, {
    "province": "Thanh H\u00f3a",
    "district": "Huy\u1ec7n C\u1ea9m Th\u1ee7y"
}, {"province": "Thanh H\u00f3a", "district": "Huy\u1ec7n Th\u1ea1ch Th\u00e0nh"}, {
    "province": "Thanh H\u00f3a",
    "district": "Huy\u1ec7n H\u00e0 Trung"
}, {"province": "Thanh H\u00f3a", "district": "Huy\u1ec7n V\u0129nh L\u1ed9c"}, {
    "province": "Thanh H\u00f3a",
    "district": "Huy\u1ec7n Y\u00ean \u0110\u1ecbnh"
}, {"province": "Thanh H\u00f3a", "district": "Huy\u1ec7n Th\u1ecd Xu\u00e2n"}, {
    "province": "Thanh H\u00f3a",
    "district": "Huy\u1ec7n Th\u01b0\u1eddng Xu\u00e2n"
}, {"province": "Thanh H\u00f3a", "district": "Huy\u1ec7n Tri\u1ec7u S\u01a1n"}, {
    "province": "Thanh H\u00f3a",
    "district": "Huy\u1ec7n Thi\u1ec7u H\u00f3a"
}, {"province": "Thanh H\u00f3a", "district": "Huy\u1ec7n Ho\u1eb1ng H\u00f3a"}, {
    "province": "Thanh H\u00f3a",
    "district": "Huy\u1ec7n H\u1eadu L\u1ed9c"
}, {"province": "Thanh H\u00f3a", "district": "Huy\u1ec7n Nga S\u01a1n"}, {
    "province": "Thanh H\u00f3a",
    "district": "Huy\u1ec7n Nh\u01b0 Xu\u00e2n"
}, {"province": "Thanh H\u00f3a", "district": "Huy\u1ec7n Nh\u01b0 Thanh"}, {
    "province": "Thanh H\u00f3a",
    "district": "Huy\u1ec7n N\u00f4ng C\u1ed1ng"
}, {"province": "Thanh H\u00f3a", "district": "Huy\u1ec7n \u0110\u00f4ng S\u01a1n"}, {
    "province": "Thanh H\u00f3a",
    "district": "Huy\u1ec7n Qu\u1ea3ng X\u01b0\u01a1ng"
}, {"province": "Thanh H\u00f3a", "district": "Huy\u1ec7n T\u0129nh Gia"}, {
    "province": "Ngh\u1ec7 An",
    "district": "Th\u00e0nh ph\u1ed1 Vinh"
}, {"province": "Ngh\u1ec7 An", "district": "Th\u1ecb x\u00e3 C\u1eeda L\u00f2"}, {
    "province": "Ngh\u1ec7 An",
    "district": "Th\u1ecb x\u00e3 Th\u00e1i Ho\u00e0"
}, {"province": "Ngh\u1ec7 An", "district": "Huy\u1ec7n Qu\u1ebf Phong"}, {
    "province": "Ngh\u1ec7 An",
    "district": "Huy\u1ec7n Qu\u1ef3 Ch\u00e2u"
}, {"province": "Ngh\u1ec7 An", "district": "Huy\u1ec7n K\u1ef3 S\u01a1n"}, {
    "province": "Ngh\u1ec7 An",
    "district": "Huy\u1ec7n T\u01b0\u01a1ng D\u01b0\u01a1ng"
}, {"province": "Ngh\u1ec7 An", "district": "Huy\u1ec7n Ngh\u0129a \u0110\u00e0n"}, {
    "province": "Ngh\u1ec7 An",
    "district": "Huy\u1ec7n Qu\u1ef3 H\u1ee3p"
}, {"province": "Ngh\u1ec7 An", "district": "Huy\u1ec7n Qu\u1ef3nh L\u01b0u"}, {
    "province": "Ngh\u1ec7 An",
    "district": "Huy\u1ec7n Con Cu\u00f4ng"
}, {"province": "Ngh\u1ec7 An", "district": "Huy\u1ec7n T\u00e2n K\u1ef3"}, {
    "province": "Ngh\u1ec7 An",
    "district": "Huy\u1ec7n Anh S\u01a1n"
}, {"province": "Ngh\u1ec7 An", "district": "Huy\u1ec7n Di\u1ec5n Ch\u00e2u"}, {
    "province": "Ngh\u1ec7 An",
    "district": "Huy\u1ec7n Y\u00ean Th\u00e0nh"
}, {"province": "Ngh\u1ec7 An", "district": "Huy\u1ec7n \u0110\u00f4 L\u01b0\u01a1ng"}, {
    "province": "Ngh\u1ec7 An",
    "district": "Huy\u1ec7n Thanh Ch\u01b0\u01a1ng"
}, {"province": "Ngh\u1ec7 An", "district": "Huy\u1ec7n Nghi L\u1ed9c"}, {
    "province": "Ngh\u1ec7 An",
    "district": "Huy\u1ec7n Nam \u0110\u00e0n"
}, {"province": "Ngh\u1ec7 An", "district": "Huy\u1ec7n H\u01b0ng Nguy\u00ean"}, {
    "province": "Ngh\u1ec7 An",
    "district": "Th\u1ecb x\u00e3 Ho\u00e0ng Mai"
}, {
    "province": "H\u00e0 T\u0129nh",
    "district": "Th\u00e0nh ph\u1ed1 H\u00e0 T\u0129nh"
}, {
    "province": "H\u00e0 T\u0129nh",
    "district": "Th\u1ecb x\u00e3 H\u1ed3ng L\u0129nh"
}, {
    "province": "H\u00e0 T\u0129nh",
    "district": "Huy\u1ec7n H\u01b0\u01a1ng S\u01a1n"
}, {"province": "H\u00e0 T\u0129nh", "district": "Huy\u1ec7n \u0110\u1ee9c Th\u1ecd"}, {
    "province": "H\u00e0 T\u0129nh",
    "district": "Huy\u1ec7n V\u0169 Quang"
}, {"province": "H\u00e0 T\u0129nh", "district": "Huy\u1ec7n Nghi Xu\u00e2n"}, {
    "province": "H\u00e0 T\u0129nh",
    "district": "Huy\u1ec7n Can L\u1ed9c"
}, {
    "province": "H\u00e0 T\u0129nh",
    "district": "Huy\u1ec7n H\u01b0\u01a1ng Kh\u00ea"
}, {"province": "H\u00e0 T\u0129nh", "district": "Huy\u1ec7n Th\u1ea1ch H\u00e0"}, {
    "province": "H\u00e0 T\u0129nh",
    "district": "Huy\u1ec7n C\u1ea9m Xuy\u00ean"
}, {"province": "H\u00e0 T\u0129nh", "district": "Huy\u1ec7n K\u1ef3 Anh"}, {
    "province": "H\u00e0 T\u0129nh",
    "district": "Huy\u1ec7n L\u1ed9c H\u00e0"
}, {"province": "H\u00e0 T\u0129nh", "district": "Th\u1ecb x\u00e3 K\u1ef3 Anh"}, {
    "province": "Qu\u1ea3ng B\u00ecnh",
    "district": "Th\u00e0nh Ph\u1ed1 \u0110\u1ed3ng H\u1edbi"
}, {"province": "Qu\u1ea3ng B\u00ecnh", "district": "Huy\u1ec7n Minh H\u00f3a"}, {
    "province": "Qu\u1ea3ng B\u00ecnh",
    "district": "Huy\u1ec7n Tuy\u00ean H\u00f3a"
}, {
    "province": "Qu\u1ea3ng B\u00ecnh",
    "district": "Huy\u1ec7n Qu\u1ea3ng Tr\u1ea1ch"
}, {
    "province": "Qu\u1ea3ng B\u00ecnh",
    "district": "Huy\u1ec7n B\u1ed1 Tr\u1ea1ch"
}, {"province": "Qu\u1ea3ng B\u00ecnh", "district": "Huy\u1ec7n Qu\u1ea3ng Ninh"}, {
    "province": "Qu\u1ea3ng B\u00ecnh",
    "district": "Huy\u1ec7n L\u1ec7 Th\u1ee7y"
}, {
    "province": "Qu\u1ea3ng B\u00ecnh",
    "district": "Th\u1ecb x\u00e3 Ba \u0110\u1ed3n"
}, {
    "province": "Qu\u1ea3ng Tr\u1ecb",
    "district": "Th\u00e0nh ph\u1ed1 \u0110\u00f4ng H\u00e0"
}, {
    "province": "Qu\u1ea3ng Tr\u1ecb",
    "district": "Th\u1ecb x\u00e3 Qu\u1ea3ng Tr\u1ecb"
}, {"province": "Qu\u1ea3ng Tr\u1ecb", "district": "Huy\u1ec7n V\u0129nh Linh"}, {
    "province": "Qu\u1ea3ng Tr\u1ecb",
    "district": "Huy\u1ec7n H\u01b0\u1edbng H\u00f3a"
}, {"province": "Qu\u1ea3ng Tr\u1ecb", "district": "Huy\u1ec7n Gio Linh"}, {
    "province": "Qu\u1ea3ng Tr\u1ecb",
    "district": "Huy\u1ec7n \u0110a Kr\u00f4ng"
}, {"province": "Qu\u1ea3ng Tr\u1ecb", "district": "Huy\u1ec7n Cam L\u1ed9"}, {
    "province": "Qu\u1ea3ng Tr\u1ecb",
    "district": "Huy\u1ec7n Tri\u1ec7u Phong"
}, {
    "province": "Qu\u1ea3ng Tr\u1ecb",
    "district": "Huy\u1ec7n H\u1ea3i L\u0103ng"
}, {
    "province": "Th\u1eeba Thi\u00ean Hu\u1ebf",
    "district": "Th\u00e0nh ph\u1ed1 Hu\u1ebf"
}, {
    "province": "Th\u1eeba Thi\u00ean Hu\u1ebf",
    "district": "Huy\u1ec7n Phong \u0110i\u1ec1n"
}, {
    "province": "Th\u1eeba Thi\u00ean Hu\u1ebf",
    "district": "Huy\u1ec7n Qu\u1ea3ng \u0110i\u1ec1n"
}, {
    "province": "Th\u1eeba Thi\u00ean Hu\u1ebf",
    "district": "Huy\u1ec7n Ph\u00fa Vang"
}, {
    "province": "Th\u1eeba Thi\u00ean Hu\u1ebf",
    "district": "Th\u1ecb x\u00e3 H\u01b0\u01a1ng Th\u1ee7y"
}, {
    "province": "Th\u1eeba Thi\u00ean Hu\u1ebf",
    "district": "Th\u1ecb x\u00e3 H\u01b0\u01a1ng Tr\u00e0"
}, {
    "province": "Th\u1eeba Thi\u00ean Hu\u1ebf",
    "district": "Huy\u1ec7n A L\u01b0\u1edbi"
}, {
    "province": "Th\u1eeba Thi\u00ean Hu\u1ebf",
    "district": "Huy\u1ec7n Ph\u00fa L\u1ed9c"
}, {
    "province": "Th\u1eeba Thi\u00ean Hu\u1ebf",
    "district": "Huy\u1ec7n Nam \u0110\u00f4ng"
}, {
    "province": "\u0110\u00e0 N\u1eb5ng",
    "district": "Qu\u1eadn Li\u00ean Chi\u1ec3u"
}, {
    "province": "\u0110\u00e0 N\u1eb5ng",
    "district": "Qu\u1eadn Thanh Kh\u00ea"
}, {
    "province": "\u0110\u00e0 N\u1eb5ng",
    "district": "Qu\u1eadn H\u1ea3i Ch\u00e2u"
}, {
    "province": "\u0110\u00e0 N\u1eb5ng",
    "district": "Qu\u1eadn S\u01a1n Tr\u00e0"
}, {
    "province": "\u0110\u00e0 N\u1eb5ng",
    "district": "Qu\u1eadn Ng\u0169 H\u00e0nh S\u01a1n"
}, {
    "province": "\u0110\u00e0 N\u1eb5ng",
    "district": "Qu\u1eadn C\u1ea9m L\u1ec7"
}, {"province": "\u0110\u00e0 N\u1eb5ng", "district": "Huy\u1ec7n H\u00f2a Vang"}, {
    "province": "Qu\u1ea3ng Nam",
    "district": "Th\u00e0nh ph\u1ed1 Tam K\u1ef3"
}, {"province": "Qu\u1ea3ng Nam", "district": "Th\u00e0nh ph\u1ed1 H\u1ed9i An"}, {
    "province": "Qu\u1ea3ng Nam",
    "district": "Huy\u1ec7n T\u00e2y Giang"
}, {"province": "Qu\u1ea3ng Nam", "district": "Huy\u1ec7n \u0110\u00f4ng Giang"}, {
    "province": "Qu\u1ea3ng Nam",
    "district": "Huy\u1ec7n \u0110\u1ea1i L\u1ed9c"
}, {
    "province": "Qu\u1ea3ng Nam",
    "district": "Th\u1ecb x\u00e3 \u0110i\u1ec7n B\u00e0n"
}, {"province": "Qu\u1ea3ng Nam", "district": "Huy\u1ec7n Duy Xuy\u00ean"}, {
    "province": "Qu\u1ea3ng Nam",
    "district": "Huy\u1ec7n Qu\u1ebf S\u01a1n"
}, {"province": "Qu\u1ea3ng Nam", "district": "Huy\u1ec7n Nam Giang"}, {
    "province": "Qu\u1ea3ng Nam",
    "district": "Huy\u1ec7n Ph\u01b0\u1edbc S\u01a1n"
}, {"province": "Qu\u1ea3ng Nam", "district": "Huy\u1ec7n Hi\u1ec7p \u0110\u1ee9c"}, {
    "province": "Qu\u1ea3ng Nam",
    "district": "Huy\u1ec7n Th\u0103ng B\u00ecnh"
}, {"province": "Qu\u1ea3ng Nam", "district": "Huy\u1ec7n Ti\u00ean Ph\u01b0\u1edbc"}, {
    "province": "Qu\u1ea3ng Nam",
    "district": "Huy\u1ec7n B\u1eafc Tr\u00e0 My"
}, {"province": "Qu\u1ea3ng Nam", "district": "Huy\u1ec7n Nam Tr\u00e0 My"}, {
    "province": "Qu\u1ea3ng Nam",
    "district": "Huy\u1ec7n N\u00fai Th\u00e0nh"
}, {"province": "Qu\u1ea3ng Nam", "district": "Huy\u1ec7n Ph\u00fa Ninh"}, {
    "province": "Qu\u1ea3ng Nam",
    "district": "Huy\u1ec7n N\u00f4ng S\u01a1n"
}, {
    "province": "Qu\u1ea3ng Ng\u00e3i",
    "district": "Th\u00e0nh ph\u1ed1 Qu\u1ea3ng Ng\u00e3i"
}, {
    "province": "Qu\u1ea3ng Ng\u00e3i",
    "district": "Huy\u1ec7n B\u00ecnh S\u01a1n"
}, {
    "province": "Qu\u1ea3ng Ng\u00e3i",
    "district": "Huy\u1ec7n Tr\u00e0 B\u1ed3ng"
}, {
    "province": "Qu\u1ea3ng Ng\u00e3i",
    "district": "Huy\u1ec7n T\u00e2y Tr\u00e0"
}, {
    "province": "Qu\u1ea3ng Ng\u00e3i",
    "district": "Huy\u1ec7n S\u01a1n T\u1ecbnh"
}, {
    "province": "Qu\u1ea3ng Ng\u00e3i",
    "district": "Huy\u1ec7n T\u01b0 Ngh\u0129a"
}, {"province": "Qu\u1ea3ng Ng\u00e3i", "district": "Huy\u1ec7n S\u01a1n H\u00e0"}, {
    "province": "Qu\u1ea3ng Ng\u00e3i",
    "district": "Huy\u1ec7n S\u01a1n T\u00e2y"
}, {"province": "Qu\u1ea3ng Ng\u00e3i", "district": "Huy\u1ec7n Minh Long"}, {
    "province": "Qu\u1ea3ng Ng\u00e3i",
    "district": "Huy\u1ec7n Ngh\u0129a H\u00e0nh"
}, {
    "province": "Qu\u1ea3ng Ng\u00e3i",
    "district": "Huy\u1ec7n M\u1ed9 \u0110\u1ee9c"
}, {
    "province": "Qu\u1ea3ng Ng\u00e3i",
    "district": "Huy\u1ec7n \u0110\u1ee9c Ph\u1ed5"
}, {"province": "Qu\u1ea3ng Ng\u00e3i", "district": "Huy\u1ec7n Ba T\u01a1"}, {
    "province": "Qu\u1ea3ng Ng\u00e3i",
    "district": "Huy\u1ec7n L\u00fd S\u01a1n"
}, {
    "province": "B\u00ecnh \u0110\u1ecbnh",
    "district": "Th\u00e0nh ph\u1ed1 Qui Nh\u01a1n"
}, {
    "province": "B\u00ecnh \u0110\u1ecbnh",
    "district": "Huy\u1ec7n An L\u00e3o"
}, {
    "province": "B\u00ecnh \u0110\u1ecbnh",
    "district": "Huy\u1ec7n Ho\u00e0i Nh\u01a1n"
}, {
    "province": "B\u00ecnh \u0110\u1ecbnh",
    "district": "Huy\u1ec7n Ho\u00e0i \u00c2n"
}, {
    "province": "B\u00ecnh \u0110\u1ecbnh",
    "district": "Huy\u1ec7n Ph\u00f9 M\u1ef9"
}, {
    "province": "B\u00ecnh \u0110\u1ecbnh",
    "district": "Huy\u1ec7n V\u0129nh Th\u1ea1nh"
}, {
    "province": "B\u00ecnh \u0110\u1ecbnh",
    "district": "Huy\u1ec7n T\u00e2y S\u01a1n"
}, {
    "province": "B\u00ecnh \u0110\u1ecbnh",
    "district": "Huy\u1ec7n Ph\u00f9 C\u00e1t"
}, {
    "province": "B\u00ecnh \u0110\u1ecbnh",
    "district": "Th\u1ecb x\u00e3 An Nh\u01a1n"
}, {
    "province": "B\u00ecnh \u0110\u1ecbnh",
    "district": "Huy\u1ec7n Tuy Ph\u01b0\u1edbc"
}, {"province": "B\u00ecnh \u0110\u1ecbnh", "district": "Huy\u1ec7n V\u00e2n Canh"}, {
    "province": "Ph\u00fa Y\u00ean",
    "district": "Th\u00e0nh ph\u1ed1 Tuy Ho\u00e0"
}, {
    "province": "Ph\u00fa Y\u00ean",
    "district": "Th\u1ecb x\u00e3 S\u00f4ng C\u1ea7u"
}, {
    "province": "Ph\u00fa Y\u00ean",
    "district": "Huy\u1ec7n \u0110\u1ed3ng Xu\u00e2n"
}, {"province": "Ph\u00fa Y\u00ean", "district": "Huy\u1ec7n Tuy An"}, {
    "province": "Ph\u00fa Y\u00ean",
    "district": "Huy\u1ec7n S\u01a1n H\u00f2a"
}, {"province": "Ph\u00fa Y\u00ean", "district": "Huy\u1ec7n S\u00f4ng Hinh"}, {
    "province": "Ph\u00fa Y\u00ean",
    "district": "Huy\u1ec7n T\u00e2y Ho\u00e0"
}, {"province": "Ph\u00fa Y\u00ean", "district": "Huy\u1ec7n Ph\u00fa Ho\u00e0"}, {
    "province": "Ph\u00fa Y\u00ean",
    "district": "Huy\u1ec7n \u0110\u00f4ng H\u00f2a"
}, {"province": "Kh\u00e1nh H\u00f2a", "district": "Th\u00e0nh ph\u1ed1 Nha Trang"}, {
    "province": "Kh\u00e1nh H\u00f2a",
    "district": "Th\u00e0nh ph\u1ed1 Cam Ranh"
}, {"province": "Kh\u00e1nh H\u00f2a", "district": "Huy\u1ec7n Cam L\u00e2m"}, {
    "province": "Kh\u00e1nh H\u00f2a",
    "district": "Huy\u1ec7n V\u1ea1n Ninh"
}, {
    "province": "Kh\u00e1nh H\u00f2a",
    "district": "Th\u1ecb x\u00e3 Ninh H\u00f2a"
}, {
    "province": "Kh\u00e1nh H\u00f2a",
    "district": "Huy\u1ec7n Kh\u00e1nh V\u0129nh"
}, {
    "province": "Kh\u00e1nh H\u00f2a",
    "district": "Huy\u1ec7n Di\u00ean Kh\u00e1nh"
}, {
    "province": "Kh\u00e1nh H\u00f2a",
    "district": "Huy\u1ec7n Kh\u00e1nh S\u01a1n"
}, {"province": "Kh\u00e1nh H\u00f2a", "district": "Huy\u1ec7n Tr\u01b0\u1eddng Sa"}, {
    "province": "Ninh Thu\u1eadn",
    "district": "Th\u00e0nh ph\u1ed1 Phan Rang-Th\u00e1p Ch\u00e0m"
}, {"province": "Ninh Thu\u1eadn", "district": "Huy\u1ec7n B\u00e1c \u00c1i"}, {
    "province": "Ninh Thu\u1eadn",
    "district": "Huy\u1ec7n Ninh S\u01a1n"
}, {"province": "Ninh Thu\u1eadn", "district": "Huy\u1ec7n Ninh H\u1ea3i"}, {
    "province": "Ninh Thu\u1eadn",
    "district": "Huy\u1ec7n Ninh Ph\u01b0\u1edbc"
}, {"province": "Ninh Thu\u1eadn", "district": "Huy\u1ec7n Thu\u1eadn B\u1eafc"}, {
    "province": "Ninh Thu\u1eadn",
    "district": "Huy\u1ec7n Thu\u1eadn Nam"
}, {
    "province": "B\u00ecnh Thu\u1eadn",
    "district": "Th\u00e0nh ph\u1ed1 Phan Thi\u1ebft"
}, {"province": "B\u00ecnh Thu\u1eadn", "district": "Th\u1ecb x\u00e3 La Gi"}, {
    "province": "B\u00ecnh Thu\u1eadn",
    "district": "Huy\u1ec7n Tuy Phong"
}, {
    "province": "B\u00ecnh Thu\u1eadn",
    "district": "Huy\u1ec7n B\u1eafc B\u00ecnh"
}, {
    "province": "B\u00ecnh Thu\u1eadn",
    "district": "Huy\u1ec7n H\u00e0m Thu\u1eadn B\u1eafc"
}, {
    "province": "B\u00ecnh Thu\u1eadn",
    "district": "Huy\u1ec7n H\u00e0m Thu\u1eadn Nam"
}, {"province": "B\u00ecnh Thu\u1eadn", "district": "Huy\u1ec7n T\u00e1nh Linh"}, {
    "province": "B\u00ecnh Thu\u1eadn",
    "district": "Huy\u1ec7n \u0110\u1ee9c Linh"
}, {
    "province": "B\u00ecnh Thu\u1eadn",
    "district": "Huy\u1ec7n H\u00e0m T\u00e2n"
}, {"province": "B\u00ecnh Thu\u1eadn", "district": "Huy\u1ec7n Ph\u00fa Qu\u00ed"}, {
    "province": "Kon Tum",
    "district": "Th\u00e0nh ph\u1ed1 Kon Tum"
}, {"province": "Kon Tum", "district": "Huy\u1ec7n \u0110\u1eafk Glei"}, {
    "province": "Kon Tum",
    "district": "Huy\u1ec7n Ng\u1ecdc H\u1ed3i"
}, {"province": "Kon Tum", "district": "Huy\u1ec7n \u0110\u1eafk T\u00f4"}, {
    "province": "Kon Tum",
    "district": "Huy\u1ec7n Kon Pl\u00f4ng"
}, {"province": "Kon Tum", "district": "Huy\u1ec7n Kon R\u1eaby"}, {
    "province": "Kon Tum",
    "district": "Huy\u1ec7n \u0110\u1eafk H\u00e0"
}, {"province": "Kon Tum", "district": "Huy\u1ec7n Sa Th\u1ea7y"}, {
    "province": "Kon Tum",
    "district": "Huy\u1ec7n Tu M\u01a1 R\u00f4ng"
}, {"province": "Kon Tum", "district": "Huy\u1ec7n Ia H' Drai"}, {
    "province": "Gia Lai",
    "district": "Th\u00e0nh ph\u1ed1 Pleiku"
}, {"province": "Gia Lai", "district": "Th\u1ecb x\u00e3 An Kh\u00ea"}, {
    "province": "Gia Lai",
    "district": "Th\u1ecb x\u00e3 Ayun Pa"
}, {"province": "Gia Lai", "district": "Huy\u1ec7n KBang"}, {
    "province": "Gia Lai",
    "district": "Huy\u1ec7n \u0110\u0103k \u0110oa"
}, {"province": "Gia Lai", "district": "Huy\u1ec7n Ch\u01b0 P\u0103h"}, {
    "province": "Gia Lai",
    "district": "Huy\u1ec7n Ia Grai"
}, {"province": "Gia Lai", "district": "Huy\u1ec7n Mang Yang"}, {
    "province": "Gia Lai",
    "district": "Huy\u1ec7n K\u00f4ng Chro"
}, {"province": "Gia Lai", "district": "Huy\u1ec7n \u0110\u1ee9c C\u01a1"}, {
    "province": "Gia Lai",
    "district": "Huy\u1ec7n Ch\u01b0 Pr\u00f4ng"
}, {"province": "Gia Lai", "district": "Huy\u1ec7n Ch\u01b0 S\u00ea"}, {
    "province": "Gia Lai",
    "district": "Huy\u1ec7n \u0110\u0103k P\u01a1"
}, {"province": "Gia Lai", "district": "Huy\u1ec7n Ia Pa"}, {
    "province": "Gia Lai",
    "district": "Huy\u1ec7n Kr\u00f4ng Pa"
}, {"province": "Gia Lai", "district": "Huy\u1ec7n Ph\u00fa Thi\u1ec7n"}, {
    "province": "Gia Lai",
    "district": "Huy\u1ec7n Ch\u01b0 P\u01b0h"
}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "district": "Th\u00e0nh ph\u1ed1 Bu\u00f4n Ma Thu\u1ed9t"
}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "district": "Th\u1ecb X\u00e3 Bu\u00f4n H\u1ed3"
}, {"province": "\u0110\u1eafk L\u1eafk", "district": "Huy\u1ec7n Ea H'leo"}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "district": "Huy\u1ec7n Ea S\u00fap"
}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "district": "Huy\u1ec7n Bu\u00f4n \u0110\u00f4n"
}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "district": "Huy\u1ec7n C\u01b0 M'gar"
}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "district": "Huy\u1ec7n Kr\u00f4ng B\u00fak"
}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "district": "Huy\u1ec7n Kr\u00f4ng N\u0103ng"
}, {"province": "\u0110\u1eafk L\u1eafk", "district": "Huy\u1ec7n Ea Kar"}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "district": "Huy\u1ec7n M'\u0110r\u1eafk"
}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "district": "Huy\u1ec7n Kr\u00f4ng B\u00f4ng"
}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "district": "Huy\u1ec7n Kr\u00f4ng P\u1eafc"
}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "district": "Huy\u1ec7n Kr\u00f4ng A Na"
}, {"province": "\u0110\u1eafk L\u1eafk", "district": "Huy\u1ec7n L\u1eafk"}, {
    "province": "\u0110\u1eafk L\u1eafk",
    "district": "Huy\u1ec7n C\u01b0 Kuin"
}, {
    "province": "\u0110\u1eafk N\u00f4ng",
    "district": "Th\u1ecb x\u00e3 Gia Ngh\u0129a"
}, {
    "province": "\u0110\u1eafk N\u00f4ng",
    "district": "Huy\u1ec7n \u0110\u0103k Glong"
}, {
    "province": "\u0110\u1eafk N\u00f4ng",
    "district": "Huy\u1ec7n C\u01b0 J\u00fat"
}, {
    "province": "\u0110\u1eafk N\u00f4ng",
    "district": "Huy\u1ec7n \u0110\u1eafk Mil"
}, {
    "province": "\u0110\u1eafk N\u00f4ng",
    "district": "Huy\u1ec7n Kr\u00f4ng N\u00f4"
}, {
    "province": "\u0110\u1eafk N\u00f4ng",
    "district": "Huy\u1ec7n \u0110\u1eafk Song"
}, {
    "province": "\u0110\u1eafk N\u00f4ng",
    "district": "Huy\u1ec7n \u0110\u1eafk R'L\u1ea5p"
}, {
    "province": "\u0110\u1eafk N\u00f4ng",
    "district": "Huy\u1ec7n Tuy \u0110\u1ee9c"
}, {
    "province": "L\u00e2m \u0110\u1ed3ng",
    "district": "Th\u00e0nh ph\u1ed1 \u0110\u00e0 L\u1ea1t"
}, {
    "province": "L\u00e2m \u0110\u1ed3ng",
    "district": "Th\u00e0nh ph\u1ed1 B\u1ea3o L\u1ed9c"
}, {
    "province": "L\u00e2m \u0110\u1ed3ng",
    "district": "Huy\u1ec7n \u0110am R\u00f4ng"
}, {
    "province": "L\u00e2m \u0110\u1ed3ng",
    "district": "Huy\u1ec7n L\u1ea1c D\u01b0\u01a1ng"
}, {
    "province": "L\u00e2m \u0110\u1ed3ng",
    "district": "Huy\u1ec7n L\u00e2m H\u00e0"
}, {
    "province": "L\u00e2m \u0110\u1ed3ng",
    "district": "Huy\u1ec7n \u0110\u01a1n D\u01b0\u01a1ng"
}, {
    "province": "L\u00e2m \u0110\u1ed3ng",
    "district": "Huy\u1ec7n \u0110\u1ee9c Tr\u1ecdng"
}, {"province": "L\u00e2m \u0110\u1ed3ng", "district": "Huy\u1ec7n Di Linh"}, {
    "province": "L\u00e2m \u0110\u1ed3ng",
    "district": "Huy\u1ec7n B\u1ea3o L\u00e2m"
}, {
    "province": "L\u00e2m \u0110\u1ed3ng",
    "district": "Huy\u1ec7n \u0110\u1ea1 Huoai"
}, {
    "province": "L\u00e2m \u0110\u1ed3ng",
    "district": "Huy\u1ec7n \u0110\u1ea1 T\u1ebbh"
}, {
    "province": "L\u00e2m \u0110\u1ed3ng",
    "district": "Huy\u1ec7n C\u00e1t Ti\u00ean"
}, {
    "province": "B\u00ecnh Ph\u01b0\u1edbc",
    "district": "Th\u1ecb x\u00e3 Ph\u01b0\u1edbc Long"
}, {
    "province": "B\u00ecnh Ph\u01b0\u1edbc",
    "district": "Th\u00e0nh ph\u1ed1 \u0110\u1ed3ng Xo\u00e0i"
}, {
    "province": "B\u00ecnh Ph\u01b0\u1edbc",
    "district": "Th\u1ecb x\u00e3 B\u00ecnh Long"
}, {
    "province": "B\u00ecnh Ph\u01b0\u1edbc",
    "district": "Huy\u1ec7n B\u00f9 Gia M\u1eadp"
}, {
    "province": "B\u00ecnh Ph\u01b0\u1edbc",
    "district": "Huy\u1ec7n L\u1ed9c Ninh"
}, {
    "province": "B\u00ecnh Ph\u01b0\u1edbc",
    "district": "Huy\u1ec7n B\u00f9 \u0110\u1ed1p"
}, {
    "province": "B\u00ecnh Ph\u01b0\u1edbc",
    "district": "Huy\u1ec7n H\u1edbn Qu\u1ea3n"
}, {
    "province": "B\u00ecnh Ph\u01b0\u1edbc",
    "district": "Huy\u1ec7n \u0110\u1ed3ng Ph\u00fa"
}, {
    "province": "B\u00ecnh Ph\u01b0\u1edbc",
    "district": "Huy\u1ec7n B\u00f9 \u0110\u0103ng"
}, {
    "province": "B\u00ecnh Ph\u01b0\u1edbc",
    "district": "Huy\u1ec7n Ch\u01a1n Th\u00e0nh"
}, {
    "province": "B\u00ecnh Ph\u01b0\u1edbc",
    "district": "Huy\u1ec7n Ph\u00fa Ri\u1ec1ng"
}, {"province": "T\u00e2y Ninh", "district": "Th\u00e0nh ph\u1ed1 T\u00e2y Ninh"}, {
    "province": "T\u00e2y Ninh",
    "district": "Huy\u1ec7n T\u00e2n Bi\u00ean"
}, {"province": "T\u00e2y Ninh", "district": "Huy\u1ec7n T\u00e2n Ch\u00e2u"}, {
    "province": "T\u00e2y Ninh",
    "district": "Huy\u1ec7n D\u01b0\u01a1ng Minh Ch\u00e2u"
}, {"province": "T\u00e2y Ninh", "district": "Huy\u1ec7n Ch\u00e2u Th\u00e0nh"}, {
    "province": "T\u00e2y Ninh",
    "district": "Huy\u1ec7n H\u00f2a Th\u00e0nh"
}, {"province": "T\u00e2y Ninh", "district": "Huy\u1ec7n G\u00f2 D\u1ea7u"}, {
    "province": "T\u00e2y Ninh",
    "district": "Huy\u1ec7n B\u1ebfn C\u1ea7u"
}, {
    "province": "T\u00e2y Ninh",
    "district": "Huy\u1ec7n Tr\u1ea3ng B\u00e0ng"
}, {
    "province": "B\u00ecnh D\u01b0\u01a1ng",
    "district": "Th\u00e0nh ph\u1ed1 Th\u1ee7 D\u1ea7u M\u1ed9t"
}, {
    "province": "B\u00ecnh D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n B\u00e0u B\u00e0ng"
}, {
    "province": "B\u00ecnh D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n D\u1ea7u Ti\u1ebfng"
}, {
    "province": "B\u00ecnh D\u01b0\u01a1ng",
    "district": "Th\u1ecb x\u00e3 B\u1ebfn C\u00e1t"
}, {
    "province": "B\u00ecnh D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n Ph\u00fa Gi\u00e1o"
}, {
    "province": "B\u00ecnh D\u01b0\u01a1ng",
    "district": "Th\u1ecb x\u00e3 T\u00e2n Uy\u00ean"
}, {
    "province": "B\u00ecnh D\u01b0\u01a1ng",
    "district": "Th\u1ecb x\u00e3 D\u0129 An"
}, {
    "province": "B\u00ecnh D\u01b0\u01a1ng",
    "district": "Th\u1ecb x\u00e3 Thu\u1eadn An"
}, {
    "province": "B\u00ecnh D\u01b0\u01a1ng",
    "district": "Huy\u1ec7n B\u1eafc T\u00e2n Uy\u00ean"
}, {
    "province": "\u0110\u1ed3ng Nai",
    "district": "Th\u00e0nh ph\u1ed1 Bi\u00ean H\u00f2a"
}, {
    "province": "\u0110\u1ed3ng Nai",
    "district": "Th\u00e0nh ph\u1ed1 Long Kh\u00e1nh"
}, {"province": "\u0110\u1ed3ng Nai", "district": "Huy\u1ec7n T\u00e2n Ph\u00fa"}, {
    "province": "\u0110\u1ed3ng Nai",
    "district": "Huy\u1ec7n V\u0129nh C\u1eedu"
}, {
    "province": "\u0110\u1ed3ng Nai",
    "district": "Huy\u1ec7n \u0110\u1ecbnh Qu\u00e1n"
}, {"province": "\u0110\u1ed3ng Nai", "district": "Huy\u1ec7n Tr\u1ea3ng Bom"}, {
    "province": "\u0110\u1ed3ng Nai",
    "district": "Huy\u1ec7n Th\u1ed1ng Nh\u1ea5t"
}, {"province": "\u0110\u1ed3ng Nai", "district": "Huy\u1ec7n C\u1ea9m M\u1ef9"}, {
    "province": "\u0110\u1ed3ng Nai",
    "district": "Huy\u1ec7n Long Th\u00e0nh"
}, {"province": "\u0110\u1ed3ng Nai", "district": "Huy\u1ec7n Xu\u00e2n L\u1ed9c"}, {
    "province": "\u0110\u1ed3ng Nai",
    "district": "Huy\u1ec7n Nh\u01a1n Tr\u1ea1ch"
}, {
    "province": "B\u00e0 R\u1ecba - V\u0169ng T\u00e0u",
    "district": "Th\u00e0nh ph\u1ed1 V\u0169ng T\u00e0u"
}, {
    "province": "B\u00e0 R\u1ecba - V\u0169ng T\u00e0u",
    "district": "Th\u00e0nh ph\u1ed1 B\u00e0 R\u1ecba"
}, {
    "province": "B\u00e0 R\u1ecba - V\u0169ng T\u00e0u",
    "district": "Huy\u1ec7n Ch\u00e2u \u0110\u1ee9c"
}, {
    "province": "B\u00e0 R\u1ecba - V\u0169ng T\u00e0u",
    "district": "Huy\u1ec7n Xuy\u00ean M\u1ed9c"
}, {
    "province": "B\u00e0 R\u1ecba - V\u0169ng T\u00e0u",
    "district": "Huy\u1ec7n Long \u0110i\u1ec1n"
}, {
    "province": "B\u00e0 R\u1ecba - V\u0169ng T\u00e0u",
    "district": "Huy\u1ec7n \u0110\u1ea5t \u0110\u1ecf"
}, {
    "province": "B\u00e0 R\u1ecba - V\u0169ng T\u00e0u",
    "district": "Th\u1ecb x\u00e3 Ph\u00fa M\u1ef9"
}, {"province": "TP H\u1ed3 Ch\u00ed Minh", "district": "Qu\u1eadn 1"}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Qu\u1eadn 12"
}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Qu\u1eadn Th\u1ee7 \u0110\u1ee9c"
}, {"province": "TP H\u1ed3 Ch\u00ed Minh", "district": "Qu\u1eadn 9"}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Qu\u1eadn G\u00f2 V\u1ea5p"
}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Qu\u1eadn B\u00ecnh Th\u1ea1nh"
}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Qu\u1eadn T\u00e2n B\u00ecnh"
}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Qu\u1eadn T\u00e2n Ph\u00fa"
}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Qu\u1eadn Ph\u00fa Nhu\u1eadn"
}, {"province": "TP H\u1ed3 Ch\u00ed Minh", "district": "Qu\u1eadn 2"}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Qu\u1eadn 3"
}, {"province": "TP H\u1ed3 Ch\u00ed Minh", "district": "Qu\u1eadn 10"}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Qu\u1eadn 11"
}, {"province": "TP H\u1ed3 Ch\u00ed Minh", "district": "Qu\u1eadn 4"}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Qu\u1eadn 5"
}, {"province": "TP H\u1ed3 Ch\u00ed Minh", "district": "Qu\u1eadn 6"}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Qu\u1eadn 8"
}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Qu\u1eadn B\u00ecnh T\u00e2n"
}, {"province": "TP H\u1ed3 Ch\u00ed Minh", "district": "Qu\u1eadn 7"}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Huy\u1ec7n C\u1ee7 Chi"
}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Huy\u1ec7n H\u00f3c M\u00f4n"
}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Huy\u1ec7n B\u00ecnh Ch\u00e1nh"
}, {
    "province": "TP H\u1ed3 Ch\u00ed Minh",
    "district": "Huy\u1ec7n Nh\u00e0 B\u00e8"
}, {"province": "TP H\u1ed3 Ch\u00ed Minh", "district": "Huy\u1ec7n C\u1ea7n Gi\u1edd"}, {
    "province": "Long An",
    "district": "Th\u00e0nh ph\u1ed1 T\u00e2n An"
}, {"province": "Long An", "district": "Th\u1ecb x\u00e3 Ki\u1ebfn T\u01b0\u1eddng"}, {
    "province": "Long An",
    "district": "Huy\u1ec7n T\u00e2n H\u01b0ng"
}, {"province": "Long An", "district": "Huy\u1ec7n V\u0129nh H\u01b0ng"}, {
    "province": "Long An",
    "district": "Huy\u1ec7n M\u1ed9c H\u00f3a"
}, {"province": "Long An", "district": "Huy\u1ec7n T\u00e2n Th\u1ea1nh"}, {
    "province": "Long An",
    "district": "Huy\u1ec7n Th\u1ea1nh H\u00f3a"
}, {"province": "Long An", "district": "Huy\u1ec7n \u0110\u1ee9c Hu\u1ec7"}, {
    "province": "Long An",
    "district": "Huy\u1ec7n \u0110\u1ee9c H\u00f2a"
}, {"province": "Long An", "district": "Huy\u1ec7n B\u1ebfn L\u1ee9c"}, {
    "province": "Long An",
    "district": "Huy\u1ec7n Th\u1ee7 Th\u1eeba"
}, {"province": "Long An", "district": "Huy\u1ec7n T\u00e2n Tr\u1ee5"}, {
    "province": "Long An",
    "district": "Huy\u1ec7n C\u1ea7n \u0110\u01b0\u1edbc"
}, {"province": "Long An", "district": "Huy\u1ec7n C\u1ea7n Giu\u1ed9c"}, {
    "province": "Long An",
    "district": "Huy\u1ec7n Ch\u00e2u Th\u00e0nh"
}, {"province": "Ti\u1ec1n Giang", "district": "Th\u00e0nh ph\u1ed1 M\u1ef9 Tho"}, {
    "province": "Ti\u1ec1n Giang",
    "district": "Th\u1ecb x\u00e3 G\u00f2 C\u00f4ng"
}, {"province": "Ti\u1ec1n Giang", "district": "Th\u1ecb x\u00e3 Cai L\u1eady"}, {
    "province": "Ti\u1ec1n Giang",
    "district": "Huy\u1ec7n T\u00e2n Ph\u01b0\u1edbc"
}, {"province": "Ti\u1ec1n Giang", "district": "Huy\u1ec7n C\u00e1i B\u00e8"}, {
    "province": "Ti\u1ec1n Giang",
    "district": "Huy\u1ec7n Cai L\u1eady"
}, {"province": "Ti\u1ec1n Giang", "district": "Huy\u1ec7n Ch\u00e2u Th\u00e0nh"}, {
    "province": "Ti\u1ec1n Giang",
    "district": "Huy\u1ec7n Ch\u1ee3 G\u1ea1o"
}, {"province": "Ti\u1ec1n Giang", "district": "Huy\u1ec7n G\u00f2 C\u00f4ng T\u00e2y"}, {
    "province": "Ti\u1ec1n Giang",
    "district": "Huy\u1ec7n G\u00f2 C\u00f4ng \u0110\u00f4ng"
}, {
    "province": "Ti\u1ec1n Giang",
    "district": "Huy\u1ec7n T\u00e2n Ph\u00fa \u0110\u00f4ng"
}, {"province": "B\u1ebfn Tre", "district": "Th\u00e0nh ph\u1ed1 B\u1ebfn Tre"}, {
    "province": "B\u1ebfn Tre",
    "district": "Huy\u1ec7n Ch\u00e2u Th\u00e0nh"
}, {"province": "B\u1ebfn Tre", "district": "Huy\u1ec7n Ch\u1ee3 L\u00e1ch"}, {
    "province": "B\u1ebfn Tre",
    "district": "Huy\u1ec7n M\u1ecf C\u00e0y Nam"
}, {"province": "B\u1ebfn Tre", "district": "Huy\u1ec7n Gi\u1ed3ng Tr\u00f4m"}, {
    "province": "B\u1ebfn Tre",
    "district": "Huy\u1ec7n B\u00ecnh \u0110\u1ea1i"
}, {"province": "B\u1ebfn Tre", "district": "Huy\u1ec7n Ba Tri"}, {
    "province": "B\u1ebfn Tre",
    "district": "Huy\u1ec7n Th\u1ea1nh Ph\u00fa"
}, {"province": "B\u1ebfn Tre", "district": "Huy\u1ec7n M\u1ecf C\u00e0y B\u1eafc"}, {
    "province": "Tr\u00e0 Vinh",
    "district": "Th\u00e0nh ph\u1ed1 Tr\u00e0 Vinh"
}, {"province": "Tr\u00e0 Vinh", "district": "Huy\u1ec7n C\u00e0ng Long"}, {
    "province": "Tr\u00e0 Vinh",
    "district": "Huy\u1ec7n C\u1ea7u K\u00e8"
}, {"province": "Tr\u00e0 Vinh", "district": "Huy\u1ec7n Ti\u1ec3u C\u1ea7n"}, {
    "province": "Tr\u00e0 Vinh",
    "district": "Huy\u1ec7n Ch\u00e2u Th\u00e0nh"
}, {"province": "Tr\u00e0 Vinh", "district": "Huy\u1ec7n C\u1ea7u Ngang"}, {
    "province": "Tr\u00e0 Vinh",
    "district": "Huy\u1ec7n Tr\u00e0 C\u00fa"
}, {"province": "Tr\u00e0 Vinh", "district": "Huy\u1ec7n Duy\u00ean H\u1ea3i"}, {
    "province": "Tr\u00e0 Vinh",
    "district": "Th\u1ecb x\u00e3 Duy\u00ean H\u1ea3i"
}, {"province": "V\u0129nh Long", "district": "Th\u00e0nh ph\u1ed1 V\u0129nh Long"}, {
    "province": "V\u0129nh Long",
    "district": "Huy\u1ec7n Long H\u1ed3"
}, {"province": "V\u0129nh Long", "district": "Huy\u1ec7n Mang Th\u00edt"}, {
    "province": "V\u0129nh Long",
    "district": "Huy\u1ec7n V\u0169ng Li\u00eam"
}, {"province": "V\u0129nh Long", "district": "Huy\u1ec7n Tam B\u00ecnh"}, {
    "province": "V\u0129nh Long",
    "district": "Th\u1ecb x\u00e3 B\u00ecnh Minh"
}, {"province": "V\u0129nh Long", "district": "Huy\u1ec7n Tr\u00e0 \u00d4n"}, {
    "province": "V\u0129nh Long",
    "district": "Huy\u1ec7n B\u00ecnh T\u00e2n"
}, {
    "province": "\u0110\u1ed3ng Th\u00e1p",
    "district": "Th\u00e0nh ph\u1ed1 Cao L\u00e3nh"
}, {
    "province": "\u0110\u1ed3ng Th\u00e1p",
    "district": "Th\u00e0nh ph\u1ed1 Sa \u0110\u00e9c"
}, {
    "province": "\u0110\u1ed3ng Th\u00e1p",
    "district": "Th\u1ecb x\u00e3 H\u1ed3ng Ng\u1ef1"
}, {
    "province": "\u0110\u1ed3ng Th\u00e1p",
    "district": "Huy\u1ec7n T\u00e2n H\u1ed3ng"
}, {
    "province": "\u0110\u1ed3ng Th\u00e1p",
    "district": "Huy\u1ec7n H\u1ed3ng Ng\u1ef1"
}, {
    "province": "\u0110\u1ed3ng Th\u00e1p",
    "district": "Huy\u1ec7n Tam N\u00f4ng"
}, {
    "province": "\u0110\u1ed3ng Th\u00e1p",
    "district": "Huy\u1ec7n Th\u00e1p M\u01b0\u1eddi"
}, {
    "province": "\u0110\u1ed3ng Th\u00e1p",
    "district": "Huy\u1ec7n Cao L\u00e3nh"
}, {
    "province": "\u0110\u1ed3ng Th\u00e1p",
    "district": "Huy\u1ec7n Thanh B\u00ecnh"
}, {
    "province": "\u0110\u1ed3ng Th\u00e1p",
    "district": "Huy\u1ec7n L\u1ea5p V\u00f2"
}, {"province": "\u0110\u1ed3ng Th\u00e1p", "district": "Huy\u1ec7n Lai Vung"}, {
    "province": "\u0110\u1ed3ng Th\u00e1p",
    "district": "Huy\u1ec7n Ch\u00e2u Th\u00e0nh"
}, {"province": "An Giang", "district": "Th\u00e0nh ph\u1ed1 Long Xuy\u00ean"}, {
    "province": "An Giang",
    "district": "Th\u00e0nh ph\u1ed1 Ch\u00e2u \u0110\u1ed1c"
}, {"province": "An Giang", "district": "Huy\u1ec7n An Ph\u00fa"}, {
    "province": "An Giang",
    "district": "Th\u1ecb x\u00e3 T\u00e2n Ch\u00e2u"
}, {"province": "An Giang", "district": "Huy\u1ec7n Ph\u00fa T\u00e2n"}, {
    "province": "An Giang",
    "district": "Huy\u1ec7n Ch\u00e2u Ph\u00fa"
}, {"province": "An Giang", "district": "Huy\u1ec7n T\u1ecbnh Bi\u00ean"}, {
    "province": "An Giang",
    "district": "Huy\u1ec7n Tri T\u00f4n"
}, {"province": "An Giang", "district": "Huy\u1ec7n Ch\u00e2u Th\u00e0nh"}, {
    "province": "An Giang",
    "district": "Huy\u1ec7n Ch\u1ee3 M\u1edbi"
}, {"province": "An Giang", "district": "Huy\u1ec7n Tho\u1ea1i S\u01a1n"}, {
    "province": "Ki\u00ean Giang",
    "district": "Th\u00e0nh ph\u1ed1 R\u1ea1ch Gi\u00e1"
}, {"province": "Ki\u00ean Giang", "district": "Th\u00e0nh ph\u1ed1 H\u00e0 Ti\u00ean"}, {
    "province": "Ki\u00ean Giang",
    "district": "Huy\u1ec7n Ki\u00ean L\u01b0\u01a1ng"
}, {"province": "Ki\u00ean Giang", "district": "Huy\u1ec7n H\u00f2n \u0110\u1ea5t"}, {
    "province": "Ki\u00ean Giang",
    "district": "Huy\u1ec7n T\u00e2n Hi\u1ec7p"
}, {"province": "Ki\u00ean Giang", "district": "Huy\u1ec7n Ch\u00e2u Th\u00e0nh"}, {
    "province": "Ki\u00ean Giang",
    "district": "Huy\u1ec7n Gi\u1ed3ng Ri\u1ec1ng"
}, {"province": "Ki\u00ean Giang", "district": "Huy\u1ec7n G\u00f2 Quao"}, {
    "province": "Ki\u00ean Giang",
    "district": "Huy\u1ec7n An Bi\u00ean"
}, {"province": "Ki\u00ean Giang", "district": "Huy\u1ec7n An Minh"}, {
    "province": "Ki\u00ean Giang",
    "district": "Huy\u1ec7n V\u0129nh Thu\u1eadn"
}, {"province": "Ki\u00ean Giang", "district": "Huy\u1ec7n Ph\u00fa Qu\u1ed1c"}, {
    "province": "Ki\u00ean Giang",
    "district": "Huy\u1ec7n Ki\u00ean H\u1ea3i"
}, {"province": "Ki\u00ean Giang", "district": "Huy\u1ec7n U Minh Th\u01b0\u1ee3ng"}, {
    "province": "Ki\u00ean Giang",
    "district": "Huy\u1ec7n Giang Th\u00e0nh"
}, {"province": "C\u1ea7n Th\u01a1", "district": "Qu\u1eadn Ninh Ki\u1ec1u"}, {
    "province": "C\u1ea7n Th\u01a1",
    "district": "Qu\u1eadn \u00d4 M\u00f4n"
}, {"province": "C\u1ea7n Th\u01a1", "district": "Qu\u1eadn B\u00ecnh Thu\u1ef7"}, {
    "province": "C\u1ea7n Th\u01a1",
    "district": "Qu\u1eadn C\u00e1i R\u0103ng"
}, {"province": "C\u1ea7n Th\u01a1", "district": "Qu\u1eadn Th\u1ed1t N\u1ed1t"}, {
    "province": "C\u1ea7n Th\u01a1",
    "district": "Huy\u1ec7n V\u0129nh Th\u1ea1nh"
}, {"province": "C\u1ea7n Th\u01a1", "district": "Huy\u1ec7n C\u1edd \u0110\u1ecf"}, {
    "province": "C\u1ea7n Th\u01a1",
    "district": "Huy\u1ec7n Phong \u0110i\u1ec1n"
}, {"province": "C\u1ea7n Th\u01a1", "district": "Huy\u1ec7n Th\u1edbi Lai"}, {
    "province": "H\u1eadu Giang",
    "district": "Th\u00e0nh ph\u1ed1 V\u1ecb Thanh"
}, {"province": "H\u1eadu Giang", "district": "Th\u1ecb x\u00e3 Ng\u00e3 B\u1ea3y"}, {
    "province": "H\u1eadu Giang",
    "district": "Huy\u1ec7n Ch\u00e2u Th\u00e0nh A"
}, {"province": "H\u1eadu Giang", "district": "Huy\u1ec7n Ch\u00e2u Th\u00e0nh"}, {
    "province": "H\u1eadu Giang",
    "district": "Huy\u1ec7n Ph\u1ee5ng Hi\u1ec7p"
}, {"province": "H\u1eadu Giang", "district": "Huy\u1ec7n V\u1ecb Thu\u1ef7"}, {
    "province": "H\u1eadu Giang",
    "district": "Huy\u1ec7n Long M\u1ef9"
}, {"province": "H\u1eadu Giang", "district": "Th\u1ecb x\u00e3 Long M\u1ef9"}, {
    "province": "S\u00f3c Tr\u0103ng",
    "district": "Th\u00e0nh ph\u1ed1 S\u00f3c Tr\u0103ng"
}, {
    "province": "S\u00f3c Tr\u0103ng",
    "district": "Huy\u1ec7n Ch\u00e2u Th\u00e0nh"
}, {"province": "S\u00f3c Tr\u0103ng", "district": "Huy\u1ec7n K\u1ebf S\u00e1ch"}, {
    "province": "S\u00f3c Tr\u0103ng",
    "district": "Huy\u1ec7n M\u1ef9 T\u00fa"
}, {"province": "S\u00f3c Tr\u0103ng", "district": "Huy\u1ec7n C\u00f9 Lao Dung"}, {
    "province": "S\u00f3c Tr\u0103ng",
    "district": "Huy\u1ec7n Long Ph\u00fa"
}, {"province": "S\u00f3c Tr\u0103ng", "district": "Huy\u1ec7n M\u1ef9 Xuy\u00ean"}, {
    "province": "S\u00f3c Tr\u0103ng",
    "district": "Th\u1ecb x\u00e3 Ng\u00e3 N\u0103m"
}, {
    "province": "S\u00f3c Tr\u0103ng",
    "district": "Huy\u1ec7n Th\u1ea1nh Tr\u1ecb"
}, {
    "province": "S\u00f3c Tr\u0103ng",
    "district": "Th\u1ecb x\u00e3 V\u0129nh Ch\u00e2u"
}, {
    "province": "S\u00f3c Tr\u0103ng",
    "district": "Huy\u1ec7n Tr\u1ea7n \u0110\u1ec1"
}, {
    "province": "B\u1ea1c Li\u00eau",
    "district": "Th\u00e0nh ph\u1ed1 B\u1ea1c Li\u00eau"
}, {"province": "B\u1ea1c Li\u00eau", "district": "Huy\u1ec7n H\u1ed3ng D\u00e2n"}, {
    "province": "B\u1ea1c Li\u00eau",
    "district": "Huy\u1ec7n Ph\u01b0\u1edbc Long"
}, {"province": "B\u1ea1c Li\u00eau", "district": "Huy\u1ec7n V\u0129nh L\u1ee3i"}, {
    "province": "B\u1ea1c Li\u00eau",
    "district": "Th\u1ecb x\u00e3 Gi\u00e1 Rai"
}, {
    "province": "B\u1ea1c Li\u00eau",
    "district": "Huy\u1ec7n \u0110\u00f4ng H\u1ea3i"
}, {"province": "B\u1ea1c Li\u00eau", "district": "Huy\u1ec7n Ho\u00e0 B\u00ecnh"}, {
    "province": "C\u00e0 Mau",
    "district": "Th\u00e0nh ph\u1ed1 C\u00e0 Mau"
}, {"province": "C\u00e0 Mau", "district": "Huy\u1ec7n U Minh"}, {
    "province": "C\u00e0 Mau",
    "district": "Huy\u1ec7n Th\u1edbi B\u00ecnh"
}, {"province": "C\u00e0 Mau", "district": "Huy\u1ec7n Tr\u1ea7n V\u0103n Th\u1eddi"}, {
    "province": "C\u00e0 Mau",
    "district": "Huy\u1ec7n C\u00e1i N\u01b0\u1edbc"
}, {"province": "C\u00e0 Mau", "district": "Huy\u1ec7n \u0110\u1ea7m D\u01a1i"}, {
    "province": "C\u00e0 Mau",
    "district": "Huy\u1ec7n N\u0103m C\u0103n"
}, {"province": "C\u00e0 Mau", "district": "Huy\u1ec7n Ph\u00fa T\u00e2n"}, {
    "province": "C\u00e0 Mau",
    "district": "Huy\u1ec7n Ng\u1ecdc Hi\u1ec3n"
}];
const urlParams = new URLSearchParams(window.location.search);
const myParam = urlParams.get('ref');
const baseUrl = $('#site_env').attr('data-env') == 'local' ? $('#site_meta').attr('data-url') : window.location.origin;
var UiLanding = function () {
    var SUCCESS_CODE = 0;
    var totalTime = 0;
    var arrTime = [];

    var startSlideAmount = 0;
    var endSlideAmount = 0;

    var startSlideDuration = 0;
    var endSlideDuration = 0;

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="token"]').attr('content')
        }
    });


    var toggleFront = function () {
        $('#form-landbot').fadeOut('slow', function () {
            $('#form-moreinfo').fadeIn('slow', function () {
                var width = $(window).width();
                if (width < 450) {
                    $("#section-home h1").addClass('hidden-sm');
                }
            });

        })

    }

    var formatPrice = function (value) {
        var val = (value / 1).toFixed(0).replace('.', ',')
        return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
    }

    var initSlider = function () {
        var handle = $("#custom-handle-amount");
        $("#slider-amount").slider({
            range: "min",
            value: 30,
            min: 1,
            max: 90,
            create: function () {
                handle.text($(this).slider("value"));
            },
            slide: function (event, ui) {
                $("#amount").val(ui.value + ' triệu đồng.');
                gtag('event', 'scroll', {
                    'event_category': 'Form scroll amount',
                    'event_label': 'Form',
                });
                handle.text(ui.value);
            },
            start(event, ui) {

            },
            stop(event, ui) {

            }
        });
        $("#amount").val($("#slider-amount").slider("value") + ' triệu đồng.');

        var handleDuration = $("#custom-handle-duration");
        $("#slider-duration").slider({
            range: "min",
            value: 12,
            min: 6,
            step: 6,
            max: 60,
            create: function () {
                handleDuration.text($(this).slider("value"));
            },
            slide: function (event, ui) {
                $("#duration").val(ui.value + ' tháng.');
                gtag('event', 'scroll', {
                    'event_category': 'Form scroll duration',
                    'event_label': 'Form',
                });
                handleDuration.text(ui.value);
            },
            start(event, ui) {
            },
            stop(event, ui) {

            }
        });
        $("#duration").val($("#slider-duration").slider("value") + ' tháng.');

        var handleIncome = $("#custom-handle-income");
        $("#slider-income").slider({
            range: "min",
            value: 50,
            min: 10,
            step: 1,
            max: 300,
            create: function () {
                handleIncome.text(parseFloat($(this).slider("value")) / 10);
            },
            slide: function (event, ui) {
                $("#income").val(formatPrice(ui.value * 1e5));
                gtag('event', 'scroll', {
                    'event_category': 'Form scroll income',
                    'event_label': 'Form',
                });

                handleIncome.text(parseFloat(ui.value) / 10);
            },
            start(event, ui) {
            },
            stop(event, ui) {

            }
        });
        $("#income").val(formatPrice(parseInt($("#slider-income").slider("value")) * 1e5));
    }


    var submitData = function (type) {
        if (firstTime) {
            firstTime = false;
            return;
        }
        var checkedProfile = [];
        $.each($("input[name='profile[]']:checked"), function () {
            checkedProfile.push($(this).val());
        });

        $.ajax({
            type: "POST",
            url: baseUrl + '/landing/registerk',
            data: {
                // 'code': response.code,
                'mobile': $('input[name="mobile"]').val(),
                'name': $('input[name="name"]').val(),
                'social_id': $('input[name="social_id"]').val(),
                'city': $('#city').val(),
                'loan': $('#custom-handle-amount').html(),
                'duration': $('#custom-handle-duration').html(),

                'ref': myParam,
                'company': $('input[name="company"]').val(),
                'income': $('#custom-handle-income').html(),
                'income_type': $('select[name="income_type"]').val(),
                'checkedProfiles': checkedProfile,
                'district': $('#district').val(),
                'address': $('input[name="address"]').val(),
                'birth': $('select[name="identity_birth"]').val(),
                'email': $('input[name="email"]').val(),
                'type': type
            }, // serializes the form's elements.
            success: function (data) {

            },
            error: function (error) {

            }
        });
    }
    var handleChangeInput = function () {
        $('input').on('blur', function () {
            gtag('send', 'event', 'Form', 'text', 'Form_text_' + $(this).attr('name'));

            gtag('event', 'text', {
                'event_category': 'Form text ' + $(this).attr('name'),
                'event_label': 'Form',
            });
            submitData('log');
        });
    }

    var initSelect2 = function () {
        var htmlProvince = !selectedProvince ? '<option selected="selected" disabled>--Tỉnh/Thành phố đang sống--</option>' : '';
        for (var i = 0; i < provinces.length; i++) {
            if (selectedProvince && selectedProvince == provinces[i].province) {
                htmlProvince += '<option value="' + provinces[i].province + '" selected="selected">' + provinces[i].province + '</option>';
            } else {
                htmlProvince += '<option value="' + provinces[i].province + '">' + provinces[i].province + '</option>';
            }

        }
        $('#city').html(htmlProvince);

        $(".selection-2").on('change', function () {
            gtag('event', 'select', {
                'event_category': 'Form select ' + $(this).attr('name'),
                'event_label': 'Form',
            });

            submitData('log');
        });

        $("#city").on('change', function () {
            submitData('log');
            gtag('event', 'select', {
                'event_category': 'Form select city',
                'event_label': 'Form',
            });

        });

        $('input[name="profile[]"]').on('change', function () {
            gtag('event', 'checkbox', {
                'event_category': 'Form checkbox',
                'event_label': 'Form',
            });
        });

        $("#city").val($("#city option[selected='selected']").html() ? $("#city option[selected='selected']").html() : 'TP Hồ Chí Minh').trigger('change');
    }

    var handleClickBtn = function () {
        $('#btn-submit').on('click', function () {
            gtag('event', 'register', {
                'event_category': 'Form register',
                'event_label': 'Form',
            });
        });

        $('#complete-register').on('click', function () {
            gtag('event', 'complete', {
                'event_category': 'Form complete',
                'event_label': 'Form',
            });
        })

        $('.nav-link').on('click', function () {
            gtag('event', 'click', {
                'event_category': 'Menu click ' + $(this).attr('href'),
                'event_label': 'Menu',
            });
        })
    }

    var initValidateFront = function () {
        $('#form-landbot').validate({
            ignore: [],
            rules: {
                name: {
                    required: true,
                },
                mobile: {
                    required: true,
                    regex: /^[0-9]{10,11}$/
                },
                social_id: {
                    required: true,
                    regex: /^[0-9]{9,12}$/
                },
                address: {
                    required: true
                },
                city: {
                    required: true
                },
                company: {
                    required: true
                },
            },
            messages: {
                name: {
                    required: "Vui lòng điền họ tên của bạn",
                    regex: 'Họ và tên không phù hợp'
                },
                mobile: {
                    required: "Vui lòng nhập số điện thoại đăng ký tư vấn",
                    regex: 'Số điện thoại không đúng định dạng'
                },
                social_id: {
                    required: "Vui lòng nhập số CMND/Thẻ căn cước của bạn",
                    regex: 'Vui lòng nhập số CMND/Thẻ căn cước phù hợp'
                },
                address: {
                    required: "Vui lòng chọn địa chỉ thu hồ sơ"
                },
                city: {
                    required: "Vui lòng chọn tỉnh thành bạn sinh sống"
                },
                company: {
                    required: "Vui lòng nhập tên công ty bạn làm việc"
                },
            },
            errorClass: "help-inline text-danger",
            errorElement: "span",
            highlight: function (element, errorClass, validClass) {
                $(element).parents('.form-group').addClass('has-error');
                return false;
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).parents('.form-group').removeClass('has-error');
                $(element).parents('.form-group').addClass('has-success');
            },
            submitHandler: function (form, e) {
                submitData('form');
                e.preventDefault();
                $('#btn-submit').attr('disabled', 'disabled');

                fbq('track', 'CompleteRegistration');
                gtag_report_conversion();
                gtag('event', 'register', {
                    'event_category': 'Form register success',
                    'event_label': 'Form',
                });


                AccountKit.init(
                    {
                        appId: "404291800431097",
                        state: "true",
                        version: "v1.0",
                        fbAppEventsEnabled: true,
                        redirect: baseUrl,
                        debug: false,
                        display: 'modal',
                    }
                );

                AccountKit.login(
                    'PHONE',
                    {
                        countryCode: '+84',
                        phoneNumber: $('input[name="mobile"]').val()
                    }, // will use default values if not specified
                    function (response) {

                        if (response.status === "PARTIALLY_AUTHENTICATED") {
                            var dialog = bootbox.dialog({
                                message: '<p class="text-center mb-0"><i class="fa fa-spin fa-spinner"></i> Đang đăng ký...</p>',
                                closeButton: false
                            });
                            var request = $.ajax({
                                type: "POST",
                                url: baseUrl + '/landing/registerk',
                                async: false,
                                timeout: 500,
                                data: {
                                    'code': response.code,
                                    'mobile': $('input[name="mobile"]').val(),
                                    'name': $('input[name="name"]').val(),
                                    'social_id': $('input[name="social_id"]').val(),
                                    'city': $('#city').val(),
                                    'loan': $('#custom-handle-amount').html(),
                                    'duration': $('#custom-handle-duration').html(),

                                    'ref': myParam,
                                    // 'address': $('input[name="address"]').val(),
                                    // 'question': $('input[name="question"]').val(),
                                    // 'district': $('#district').val(),
                                    // 'income': $('#custom-handle-income').html(),
                                    // 'company': $('input[name="company"]').val(),
                                    // 'birth': $('select[name="identity_birth"]').val(),
                                    'type': 'form'

                                }, // serializes the form's elements.
                            });

                            request.always(function (data) {
                                setTimeout(function () {
                                    dialog.modal('hide');
                                }, 1000);
                                // set value district select
                                var provinceName = $('#city').val();
                                var filteredDistricts = districts.filter(function (district) {
                                    return district.province == provinceName;
                                });
                                var htmlDistrict = '<option selected="selected" disabled value="">-- Chọn Quận/Huyện --</option>';
                                for (var i = 0; i < filteredDistricts.length; i++) {
                                    htmlDistrict += '<option value="' + filteredDistricts[i].district + '">' + filteredDistricts[i].district + '</option>'
                                }
                                $("#district").html(htmlDistrict);
                                $('#district').val('').trigger('change');

                                // set value for birth
                                var curYear = parseInt(new Date().getFullYear());
                                var htmlBirth = '<option disabled selected>-Năm sinh-</option>';
                                for (var i = curYear - 18; i >= curYear - 60; i--) {
                                    htmlBirth += '<option value="' + i + '">' + i + '</option>';
                                }
                                $('select[name="identity_birth"]').html(htmlBirth);

                                // toggle back form
                                if (data.code == SUCCESS_CODE) {
                                    toastr.success('Đã đăng ký. Bạn vui lòng hoàn thành thông tin để chúng tôi có thể phê duyệt khoản vay.');
                                    toggleFront();
                                } else {
                                    toastr.error("Có lỗi xảy ra, vui lòng thử lại sau.");
                                }
                            });

                            request.fail(function (error) {
                                setTimeout(function () {
                                    dialog.modal('hide');
                                }, 1000);
                                if (error && error.responseJSON) {
                                    error = error.responseJSON;
                                    $.each(error.errors, function (key, value) {
                                        toastr.error(decodeURI(value));
                                    });
                                } else {
                                    toastr.error("Có lỗi xảy ra, vui lòng thử lại sau.");
                                }
                            });
                        } else {

                        }

                    }
                );

            }
        });
    }

    var initValidateBack = function () {
        $('#form-moreinfo').validate({
            ignore: 'input[type=hidden]',
            rules: {
                company: {
                    required: true
                },
                address: {
                    required: true
                },
                identity_birth: {
                    required: true
                },
                income_type: {
                    required: true
                },
                district: {
                    required: true
                }
            },
            messages: {
                company: {
                    required: "Vui lòng nhập tên công ty"
                },
                address: {
                    required: "Vui lòng chọn địa chỉ thu hồ sơ"
                },
                identity_birth: {
                    required: 'Vui lòng nhập độ tuổi'
                },
                income_type: {
                    required: 'Vui lòng chọn hình thức thu nhập'
                },
                district: {
                    required: 'Vui lòng chọn quận/huyện sinh sống'
                }
            },
            errorClass: "help-inline text-danger",
            errorElement: "span",
            highlight: function (element, errorClass, validClass) {
                $(element).parents('.form-group').addClass('has-error');
                return false;
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).parents('.form-group').removeClass('has-error');
                $(element).parents('.form-group').addClass('has-success');
            },
            submitHandler: function (form, e) {
                gtag('event', 'register', {
                    'event_category': 'Form register complete',
                    'event_label': 'Form',
                });

                var dialog = bootbox.dialog({
                    message: '<p class="text-center mb-0"><i class="fa fa-spin fa-spinner"></i> Đang hoàn tất đăng ký...</p>',
                    closeButton: false
                });
                var checkedProfile = [];
                $.each($("input[name='profile[]']:checked"), function () {
                    checkedProfile.push($(this).val());
                });
                $.ajax({
                    type: "POST",
                    url: baseUrl + '/landing/registerk',
                    data: {
                        'mobile': $('input[name="mobile"]').val(),
                        'name': $('input[name="name"]').val(),
                        'social_id': $('input[name="social_id"]').val(),
                        'city': $('#city').val(),
                        'loan': $('#custom-handle-amount').html(),
                        'duration': $('#custom-handle-duration').html(),

                        'ref': myParam,
                        'company': $('input[name="company"]').val(),
                        'income': $('#custom-handle-income').html(),
                        'income_type': $('select[name="income_type"]').val(),
                        'checkedProfiles': checkedProfile,
                        'district': $('#district').val(),
                        'address': $('input[name="address"]').val(),
                        'birth': $('select[name="identity_birth"]').val(),
                        'email': $('input[name="email"]').val(),
                        'type': 'form'
                    }, // serializes the form's elements.
                    success: function (data) {
                        setTimeout(function () {
                            dialog.modal('hide');
                        }, 1000);
                        if (data.code == SUCCESS_CODE) {
                            // $('input').val('');
                            bootbox.alert("Đăng ký thành công, chúng tôi sẽ sớm liên lạc với bạn.", function () {
                                window.open('https://dcredit.vn/hoi-dap/?show=most-answered', '_blank');
                            });
                        } else {
                            toastr.error("Có lỗi xảy ra, vui lòng thử lại sau.");
                        }
                    },
                    error: function (error) {
                        setTimeout(function () {
                            dialog.modal('hide');
                        }, 1000);
                        if (error && error.responseJSON) {
                            error = error.responseJSON;
                            $.each(error.errors, function (key, value) {
                                toastr.error(decodeURI(value));
                            });
                        } else {
                            toastr.error("Có lỗi xảy ra, vui lòng thử lại sau.");
                        }
                    }
                });

            }
        });
    }

    var scrollWindow = function () {
        $(window).scroll(function () {
            var $w = $(this), st = $w.scrollTop(), navbar = $('.pb_navbar'), sd = $('.js-scroll-wrap');
            if (st > 150) {
                if (!navbar.hasClass('scrolled')) {
                    navbar.addClass('scrolled');
                }
            }
            if (st < 150) {
                if (navbar.hasClass('scrolled')) {
                    navbar.removeClass('scrolled sleep');
                }
            }
            if (st > 350) {
                if (!navbar.hasClass('awake')) {
                    navbar.addClass('awake');
                }
                if (sd.length > 0) {
                    sd.addClass('sleep');
                }
            }
            if (st < 350) {
                if (navbar.hasClass('awake')) {
                    navbar.removeClass('awake');
                    navbar.addClass('sleep');
                }
                if (sd.length > 0) {
                    sd.removeClass('sleep');
                }
            }
        });
    };
    var OnePageNav = function () {
        var navToggler = $('.navbar-toggler');
        $(".smoothscroll[href^='#'], #probootstrap-navbar ul li a[href^='#']").on('click', function (e) {
            e.preventDefault();
            var hash = this.hash;
            $('html, body').animate({scrollTop: $(hash).offset().top}, 700, 'easeInOutExpo', function () {
                window.location.hash = hash;
            });
        });
        $("#probootstrap-navbar ul li a[href^='#']").on('click', function (e) {
            if (navToggler.is(':visible')) {
                navToggler.click();
            }
        });
        $('body').on('activate.bs.scrollspy', function () {
            console.log('nice');
        })
    };
    var offCanvasNav = function () {
        var toggleNav = $('.js-pb_nav-toggle'), offcanvasNav = $('.js-pb_offcanvas-nav_v1');
        if (toggleNav.length > 0) {
            toggleNav.click(function (e) {
                $(this).toggleClass('active');
                offcanvasNav.addClass('active');
                e.preventDefault();
            });
        }
        offcanvasNav.click(function (e) {
            if (offcanvasNav.hasClass('active')) {
                offcanvasNav.removeClass('active');
                toggleNav.removeClass('active');
            }
            e.preventDefault();
        })
    };
    //
    // var loadImg = function () {
    //     $("img.page-img").lazyload({
    //         effect: "fadeIn"
    //     });
    // }


    return {
        init() {
            scrollWindow(),
                OnePageNav(),
                offCanvasNav(),
                initSlider(),
                handleChangeInput(),
                // loadCssFiles(),
                initSelect2(),
                initValidateFront(),
                initValidateBack(),
                handleClickBtn()
            // loadImg()

        }
    }
}


$(document).ready(function () {
    UiLanding().init();
});
