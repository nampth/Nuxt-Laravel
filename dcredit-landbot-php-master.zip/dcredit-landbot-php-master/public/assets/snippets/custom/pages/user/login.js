var baseUrl = jQuery('#site_meta').attr('data-url');
var SnippetLogin = function () {
    jQuery.extend(jQuery.validator.messages, {
        required: "Thông tin không được để trống.",
        remote: "Please fix this field.",
        email: "Địa chỉ email bạn vừa điền không hợp lệ.",
        phone: "Số điện thoại bạn vừa điền không hợp lệ.",
        identity: "Số CMND/CCCD bạn vừa điền không hợp lệ.",
        url: "Please enter a valid URL.",
        date: "Please enter a valid date.",
        dateISO: "Please enter a valid date (ISO).",
        number: "Please enter a valid number.",
        digits: "Please enter only digits.",
        creditcard: "Please enter a valid credit card number.",
        equalTo: "Please enter the same value again.",
        accept: "Please enter a value with a valid extension.",
        maxlength: jQuery.validator.format("Please enter no more than {0} characters."),
        minlength: jQuery.validator.format("Please enter at least {0} characters."),
        rangelength: jQuery.validator.format("Please enter a value between {0} and {1} characters long."),
        range: jQuery.validator.format("Please enter a value between {0} and {1}."),
        max: jQuery.validator.format("Please enter a value less than or equal to {0}."),
        min: jQuery.validator.format("Please enter a value greater than or equal to {0}.")
    });

    var pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.?)+[a-z]{2,}|' + // domain name
        '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
        '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
        '(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator


    var loginForm = $("#m_login"), i = function (e, i, a) {
        var l = $('<div class="m-alert m-alert--outline alert alert-' + i + ' alert-dismissible" role="alert">\t\t\t<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>\t\t\t<span></span>\t\t</div>');
        e.find(".alert").remove(), l.prependTo(e), mUtil.animateClass(l[0], "fadeIn animated"), l.find("span").html(a)
    }, a = function () {
        loginForm.removeClass("m-login--forget-password"), loginForm.removeClass("m-login--signup"), loginForm.removeClass("m-login-otp"), loginForm.addClass("m-login--signin"), mUtil.animateClass(loginForm.find(".m-login__signin")[0], "flipInX animated")
    }, l = function () {
        $("#m_login_forget_password").click(function (i) {
            i.preventDefault(), loginForm.removeClass("m-login--signin"), loginForm.removeClass("m-login-otp"), loginForm.removeClass("m-login--signup"), loginForm.addClass("m-login--forget-password"), mUtil.animateClass(loginForm.find(".m-login__forget-password")[0], "flipInX animated")
        }), $("#m_login_forget_password_cancel").click(function (e) {
            e.preventDefault(), a()
        }), $("#m_login_signup").click(function (i) {
            i.preventDefault(), loginForm.removeClass("m-login--forget-password"), loginForm.removeClass("m-login-otp"), loginForm.removeClass("m-login--signin"), loginForm.addClass("m-login--signup"), mUtil.animateClass(loginForm.find(".m-login__signup")[0], "flipInX animated")
        }), $("#m_login_signup_cancel").click(function (e) {
            e.preventDefault(), a()
        }), $("#m_login_otp_cancel").click(function (e) {
            e.preventDefault(), a()
        })
    };
    return {
        init: function () {
            l(), $("#m_login_signin_submit").click(function (e) {
                e.preventDefault();
                var a = $(this), l = $(this).closest("form");
                l.validate({
                    rules: {
                        username: {required: !0},
                        password: {required: !0}
                    }
                }), l.valid() && (a.addClass("m-loader m-loader--right m-loader--light").attr("disabled", !0), l.ajaxSubmit({
                    url: l.attr('action'),
                    success: function (e, t, r, s) {
                        if (t && t == 'success') {
                            if (pattern.test(e)) {
                                window.location.href = e;
                            } else {
                                a.removeClass("m-loader m-loader--right m-loader--light").attr("disabled", !1);
                                toastr.error('Tài khoản không hợp lệ. Vui lòng đăng ký lại hoặc liên hệ với người quản trị');
                            }
                        } else {
                            a.removeClass("m-loader m-loader--right m-loader--light").attr("disabled", !1), i(l, "danger", "Tên đăng nhập hoặc mật khẩu không chính xác. Vui lòng thử lại")
                        }
                    },
                    error: function (e) {
                        a.removeClass("m-loader m-loader--right m-loader--light").attr("disabled", !1), i(l, "danger", "Tên đăng nhập hoặc mật khẩu không chính xác. Vui lòng thử lại")
                    }
                }))
            }), $("#m_login_signup_submit").click(function (l) {
                l.preventDefault();
                var t = $(this), registerForm = $(this).closest("form");
                registerForm.validate({
                    rules: {
                        username: {required: !0},
                        fullname: {required: !0},
                        email: {required: !0, email: !0},
                        phone: {required: !0},
                        identity: {required: !0},
                        password: {required: !0},
                        rpassword: {required: !0},
                        agree: {required: !0}
                    }
                }), registerForm.valid() && (t.addClass("m-loader m-loader--right m-loader--light").attr("disabled", !0),
                        registerForm.ajaxSubmit({
                            url: registerForm.attr('action'),
                            success: function (l, s, n, o) {
                                var response = l;

                                if (response && response.phone) {
                                    setTimeout(function () {
                                        toastr.success('Bạn vui lòng xác thực số điện thoại để có thể đăng nhập vào hệ thống.');
                                        t.removeClass("m-loader m-loader--right m-loader--light").attr("disabled", !1), registerForm.clearForm(), registerForm.validate().resetForm();
                                        var loginForm = $("#m_login")
                                        var l = loginForm.find(".m-login__signin form");
                                        var phone = response.phone;
                                        l.clearForm(), l.validate().resetForm();
                                        // loginForm.removeClass("m-login--forget-password"), loginForm.removeClass("m-login--signup"), loginForm.removeClass("m-login--signin");

                                        AccountKit.init(
                                            {
                                                appId: "417775139069133",
                                                state: "true",
                                                version: "v1.0",
                                                fbAppEventsEnabled: true,
                                                redirect: "http://p2p.kalapa.vn",
                                                debug: false,
                                                display: 'modal',
                                            }
                                        );

                                        AccountKit.login(
                                            'PHONE',
                                            {
                                                countryCode: '+84',
                                                phoneNumber: response.phone
                                            }, // will use default values if not specified
                                            function (response) {
                                                if (response.status === "PARTIALLY_AUTHENTICATED") {
                                                    mApp.block("#m_login", {
                                                        overlayColor: "#000000",
                                                        type: "loader",
                                                        state: "success",
                                                        message: "Đang xác thực ..."
                                                    });
                                                    $.ajax({
                                                        type: "POST",
                                                        url: baseUrl + '/verify',
                                                        headers: {
                                                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                                        },
                                                        data: {
                                                            'code': response.code,
                                                            'phone': phone,
                                                        }, // serializes the form's elements.
                                                        success: function (data) {
                                                            mApp.unblock('#m_login');
                                                            if (data && data.status == 'success') {
                                                                window.location.href = $('#site_meta').attr('data-url') + data.url;
                                                            } else {
                                                                toastr.error("Số điện thoại chưa được xác thực.");
                                                            }
                                                        },
                                                        error: function (error) {
                                                            mApp.unblock('#m_login');
                                                            if (error && error.responseJSON) {
                                                                error = error.responseJSON;
                                                                $.each(error.errors, function (key, value) {
                                                                    toastr.error(decodeURI(value));
                                                                });
                                                            } else {
                                                                toastr.error("Có lỗi xảy ra, vui lòng thử lại sau.");
                                                            }
                                                            // $('#' + vm.id).modal('hide');
                                                        }
                                                    });
                                                }
                                            }
                                        );
                                    }, 2e3)
                                } else {
                                    if (response.status == 'registered') {
                                        t.removeClass("m-loader m-loader--right m-loader--light").attr("disabled", !1), registerForm.clearForm(), registerForm.validate().resetForm();
                                        var loginForm = $("#m_login")
                                        var l = loginForm.find(".m-login__signin form");
                                        l.clearForm(), l.validate().resetForm();

                                        toastr.error('Số điện thoại đã tồn tại. Vui lòng đăng nhập để tiếp tục');
                                    } else {
                                        toastr.error('Có lỗi xảy ra.');
                                    }

                                }

                            },
                            error: function (e) {
                                var text = '';
                                var errors = JSON.parse(e.responseText);
                                if (errors.errors) {
                                    errors = errors.errors;
                                    for (var key in errors) {
                                        // check also if property is not inherited from prototype
                                        if (errors.hasOwnProperty(key)) {
                                            var value = errors[key][0];
                                            text += value + '<br/>';
                                        }
                                    }
                                }
                                t.removeClass("m-loader m-loader--right m-loader--light").attr("disabled", !1), i(registerForm, "danger", text)
                            }
                        })
                )
            }), $("#m_login_forget_password_submit").click(function (l) {
                l.preventDefault();
                var t = $(this), r = $(this).closest("form");
                r.validate({
                    rules: {
                        email: {
                            required: !0,
                            email: !0
                        }
                    }
                }), r.valid() && (t.addClass("m-loader m-loader--right m-loader--light").attr("disabled", !0), r.ajaxSubmit({
                    url: "",
                    success: function (l, s, n, o) {
                        setTimeout(function () {
                            t.removeClass("m-loader m-loader--right m-loader--light").attr("disabled", !1), r.clearForm(), r.validate().resetForm(), a();
                            var l = e.find(".m-login__signin form");
                            l.clearForm(), l.validate().resetForm(), i(l, "success", "Cool! Password recovery instruction has been sent to your email.")
                        }, 2e3)
                    }
                }))
            }),
                $("#m_login_otp_submit").click(function (l) {
                    l.preventDefault();
                    var t = $(this), r = $(this).closest("form");
                    r.validate({
                        rules: {
                            phone: {
                                required: !0,
                            },
                            otp: {
                                required: !0,
                            },
                        }
                    }), r.valid() && (t.addClass("m-loader m-loader--right m-loader--light").attr("disabled", !0), r.ajaxSubmit({
                        url: r.attr('action'),
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function (l, s, n, o) {
                            var response = l;
                            setTimeout(function () {
                                if (response && response.status == 'success') {
                                    window.location.href = $('#site_meta').attr('data-url') + response.url;
                                } else {
                                    t.removeClass("m-loader m-loader--right m-loader--light").attr("disabled", !1);
                                    r.find('input[name="otp"]').val(''), i(r, "danger", "Mã xác thực không đúng hoặc đã vượt quá 5 phút.")
                                }

                            }, 2e3)

                        }
                    }))
                }),
                $("#m_login_otp_refresh").click(function (l) {
                    l.preventDefault();
                    var t = $(this), r = $(this).closest("form");
                    r.validate({
                        rules: {
                            phone: {
                                required: !0,
                            },
                            otp: {
                                required: !0,
                            },
                        }
                    }), r.valid() && (t.addClass("m-loader m-loader--right m-loader--light").attr("disabled", !0), r.ajaxSubmit({
                        url: r.attr('action'),
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function (l, s, n, o) {


                        }
                    }))
                })
        }
    }
}();
jQuery(document).ready(function () {
    SnippetLogin.init()
});
