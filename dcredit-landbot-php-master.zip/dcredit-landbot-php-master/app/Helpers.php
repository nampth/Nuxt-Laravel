<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 10/16/2018
 * Time: 11:43 AM
 */
if (!function_exists('include_route_files')) {

    /**
     * Loops through a folder and requires all PHP files
     * Searches sub-directories as well.
     *
     * @param $folder
     */
    function include_route_files($folder)
    {
        try {
            $rdi = new recursiveDirectoryIterator($folder);
            $it = new recursiveIteratorIterator($rdi);

            while ($it->valid()) {
                if (!$it->isDot() && $it->isFile() && $it->isReadable() && $it->current()->getExtension() === 'php') {
                    require $it->key();
                }

                $it->next();
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
}

if (!function_exists('do_curl')) {
    function do_curl($url, $headers = [])
    {
        $ch = curl_init();
        if ($headers && count($headers) > 0) {
            $arrHeader = [
                "Authorization: Bearer keyYRwECCrAiUSoKm",
                "Content-Type: application/json"
            ];

            curl_setopt($ch, CURLOPT_HTTPHEADER, $arrHeader);
        }
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $data = json_decode(curl_exec($ch), true);
        curl_close($ch);

        return $data;
    }
}

if (!function_exists('curl_form')) {
    function curl_form($method = "GET", $url = "", $param = [], $headers = [], $sessionId = '')
    {
        $data_string = '';
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        if ($method == 'POST') {
            $data_string = json_encode($param);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
        }
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_MAXREDIRS, 3);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $arrHeader = $headers;
        $arrHeader[] = 'Content-type: application/json';
        $arrHeader[] = 'Content-length: ' . strlen($data_string);

        $fp = fopen(dirname(__FILE__) . '/curl_log.txt', 'w');
        curl_setopt($curl, CURLOPT_VERBOSE, 1);
        curl_setopt($curl, CURLOPT_STDERR, $fp);

        curl_setopt($curl, CURLOPT_HTTPHEADER, $arrHeader);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($curl);

        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $responseTime = curl_getinfo($curl, CURLINFO_TOTAL_TIME);

        curl_close($curl);
        log_curl($url, $data_string, $result, "http code: $httpcode", "", $responseTime);

//        if (intval($httpcode) == 200) {
        return [
            'data' => $result,
            'code' => $httpcode
        ];
//        }
//        return null;
    }
}

if (!function_exists('save_traffic_log')) {
    function save_traffic_log($ip, $ua, $view, $keyword, $headers = '', $sessionId = '', $sourceIp = '', $uri = '', $responseTime = null)
    {
        $trafficLog = new \App\Models\TrafficLog();
        $trafficLog->from_ip = $ip . '-' . $sourceIp;
        $trafficLog->user_agent = $ua;
        $trafficLog->view = $view;
        $trafficLog->keyword = $keyword;
        $trafficLog->header = $headers;
        $trafficLog->session_id = $sessionId;
        $trafficLog->uri = $uri;
        $trafficLog->save();
    }
}

if (!function_exists('log_curl')) {
    function log_curl($url, $data, $response, $note, $sessionId, $responseTime)
    {
        $firstSession = \App\Models\TrafficLog::where('session_id', $sessionId)->first();
        $log = new \App\Models\Log();
        $action = '';
        switch ($url) {
            case  KAL_API_LOG:
                $action = 'submit_log';
                break;
            case KAL_API:
                $action = 'submit_form';
                break;
            case KAL_CREDIT_API:
                $action = 'submit_form_credit';
                break;
            case '':
                $action = 'log_client_request';
                break;
            default:
                $action = "new_api_$url";
                break;
        }
        $log->action = $action;
        $log->data = $data;
        $log->response = $response;
        $log->note = $note;
        $log->response_time = $responseTime;
        $log->session_id = $sessionId;
        if ($firstSession) {
            $t1 = strtotime($firstSession->created_at);
            $t2 = strtotime(date('Y-m-d H:i:s'));
            $log->duration = ($t2 - $t1);
        } else {
            $log->duration = -1;
        }
        $log->save();
    }
}

if (!function_exists('render_asset')) {
    function render_asset($url)
    {
        if (env('APP_METHOD') == 'https') {
            return secure_asset($url);
        } else {
            return asset($url);
        }
    }
}

if (!function_exists('get_data_acckit')) {
    function get_data_acckit($code)
    {
        $token_exchange_url = 'https://graph.accountkit.com/' . ACCKIT_VERSION . '/access_token?' .
            'grant_type=authorization_code' .
            '&code=' . $code . "&access_token=AA|" . ACCKIT_APP_ID . "|" . ACCKIT_SECRET;
        if (strlen($code) < 156) {
            $me_endpoint_url = 'https://graph.accountkit.com/' . ACCKIT_VERSION . '/me?' .
                'access_token=' . $code;
            $data = do_curl($me_endpoint_url);
            return $data;
        } else {
            $data = do_curl($token_exchange_url);
            if ($data && isset($data['id']) && isset($data['access_token'])) {
                $user_id = $data['id'];
                $user_access_token = $data['access_token'];
                $refresh_interval = $data['token_refresh_interval_sec'];

                // Get Account Kit information
                $me_endpoint_url = 'https://graph.accountkit.com/' . ACCKIT_VERSION . '/me?' .
                    'access_token=' . $user_access_token;
                $data = do_curl($me_endpoint_url);

                return $data;
            } else {
                return null;
            }
        }
    }
}

if (!function_exists('normalize_phone_number')) {
    function normalize_phone_number($str)
    {
        if (strlen($str) < 10) {
            return null;
        }

        $number = preg_replace('/[^0-9]/', '', $str) . '';

        if (strpos($number, '0') === 0) {
            $number = '84' . substr($number, 1, strlen($number) - 1);
        }

        if (strlen($number) != 11) {
            return null;
        }
        return $number;
    }
}

if (!function_exists('normalize_phone_number2')) {
    function normalize_phone_number2($str)
    {
        if (strlen($str) != 11 && strlen($str) != 10) {
            return null;
        }

        $number = preg_replace('/[^0-9]/', '', $str) . '';

        if (strpos($number, '84') === 0) {
            $number = '0' . substr($number, 2, strlen($number) - 1);
        }

        if (strlen($number) != 10) {
            return null;
        }
        return $number;
    }
}

if (!function_exists(('register_airtable'))) {
    function register_airtable($registerData)
    {
        $postData = [
            'records' => [
                ['fields' => $registerData]
            ]
        ];

        $curl = curl_init(KAL_API_AIRTABLE_REGISTER);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
        $data_string = json_encode($postData);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_MAXREDIRS, 3);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $arrHeader = [
            "Authorization: Bearer keyYRwECCrAiUSoKm",
            "Content-Type: application/json"
        ];

        curl_setopt($curl, CURLOPT_HTTPHEADER, $arrHeader);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($curl);

        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $responseTime = curl_getinfo($curl, CURLINFO_TOTAL_TIME);

        curl_close($curl);

        $log = new \App\Models\Log();
        $log->action = 'submit_end2end';
        $log->data = json_encode($postData, JSON_UNESCAPED_UNICODE);
        $log->response = json_encode($result, JSON_UNESCAPED_UNICODE);
        $log->note = "http code: $httpcode";
        $log->response_time = $responseTime;
        $log->session_id = '';
        $log->save();

        return [
            'data' => $result,
            'code' => $httpcode,
            'response_time' => $responseTime
        ];
    }
}

if (!function_exists(('update_airtable'))) {
    function update_airtable($phone, $updateData)
    {
        $url = sprintf(KAL_API_AIRTABLE_GETID, $phone);
        $resultRecordId = do_curl($url, [
            "Authorization: Bearer keyYRwECCrAiUSoKm",
            "Content-Type: application/json"
        ]);

        if ($resultRecordId && $resultRecordId['records'] && count($resultRecordId['records']) > 0) {
            $recordId = $resultRecordId['records'][0]['id'];
            $postData = [
                'records' => [
                    [
                        'id' => $recordId,
                        'fields' => $updateData
                    ]
                ]
            ];


            $curl = curl_init(KAL_API_AIRTABLE_REGISTER);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PATCH');
            $data_string = json_encode($postData);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 0);
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($curl, CURLOPT_MAXREDIRS, 3);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $arrHeader = [
                "Authorization: Bearer keyYRwECCrAiUSoKm",
                "Content-Type: application/json"
            ];

            curl_setopt($curl, CURLOPT_HTTPHEADER, $arrHeader);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($curl);

            $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            $responseTime = curl_getinfo($curl, CURLINFO_TOTAL_TIME);

            curl_close($curl);

            $log = new \App\Models\Log();
            $log->action = 'update_end2end';
            $log->data = json_encode($postData, JSON_UNESCAPED_UNICODE);
            $log->response = json_encode($result, JSON_UNESCAPED_UNICODE);
            $log->note = "http code: $httpcode";
            $log->response_time = $responseTime;
            $log->session_id = '';
            $log->save();

            return [
                'data' => $result,
                'code' => $httpcode,
                'response_time' => $responseTime
            ];

        } else {
            $log = new \App\Models\Log();
            $log->action = 'update_end2end_error';
            $log->data = json_encode($updateData, JSON_UNESCAPED_UNICODE);
            $log->response = json_encode($resultRecordId, JSON_UNESCAPED_UNICODE);
            $log->note = "phone: $phone";
            $log->response_time = null;
            $log->session_id = '';
            $log->save();

            return [
                'data' => $resultRecordId,
                'code' => null,
                'response_time' => null
            ];
        }


    }
}

if (!function_exists('send_voice_otp')) {
    function send_voice_otp($otp, $phone, $type)
    {
        $postData = [
            "from" => VOICE_CMC_PHONE_FROM,
            "to" => '0' . substr($phone, 2, 9),
            "otp" => [
                "encrypted" => bin2hex(base64_decode(openssl_encrypt($otp, 'aes-256-cbc', VOICE_CMC_KEY, 0, VOICE_CMC_IV))),
                "algorithm" => "aes-256-cbc",
                "iv" => VOICE_CMC_IV
            ]
        ];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => API_VOICE_OTP_CMC,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($postData),
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "Authorization: Basic NWU1NzM5ZGRiMGYyYTkyOGE4ZTY5NDRlOk9zNnJ3U1I5NzRhZFFrbmtmVVZVU2l2Qw=="
//                'Authorization: Basic ' . base64_encode(ACCKIT_APP_ID . ":" . VOICE_CMC_APP_SECRET)
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;

    }
}

if (!function_exists('censore_data')) {
    function censore_data(&$user)
    {
        if (isset($user->metric_data)) {
            foreach ($user->metric_data as $metricData) {
                // string do dai tu 8-12 thi replace 2/3 ky tu thanh *** ***
                if (strlen($metricData->value) >= 8) {
                    $glue = '';
                    $len = intval(0.5 * strlen($metricData->value));
                    for ($i = 0; $i < $len; $i++) $glue .= "*";
                    $str1 = mb_substr($metricData->value, 0, intval((strlen($metricData->value) - $len) / 2));
                    $str2 = mb_substr($metricData->value, strlen($str1 . $glue), strlen($metricData->value) - strlen($str1 . $glue));
                    $metricData->value = $str1 . ' ' . $glue . ' ' . $str2;
                }
            }
        }
        return $user;

    }
}

if (!function_exists('verify_basic_auth')) {
    function verify_basic_auth($token, $username, $pw)
    {
        if (!$token || !$username || !$pw) {
            return false;
        }
        if ($token != "Basic " . base64_encode($username . ':' . $pw)) {
            return false;
        }
        return true;

    }
}
