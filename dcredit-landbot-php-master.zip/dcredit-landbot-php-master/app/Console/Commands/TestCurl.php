<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class TestCurl extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'curl:test';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $data_string = '';
        $curl = curl_init(KAL_CREDIT_API);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');

        $data_string = json_encode([
            'name' => 'phan thai hong nam',
            'email' => 'nampth@kalapa.vn',
            'address' => 'Tuyên Quang',
            'income' => '4',
            'card' => 'Sacombank Classic Mastercard',
            'paper' => 'Photo Sổ hộ khẩu,KT3,XN tạm trú bản chính',
            'adv' => 'NULL',
            'ref' => NULL,
            'form_type' => 'credit_scb',
            'session_id' => 'atJAExCXKGgQufTCs8ToJgDGIFOfQRSByzwaUyC8',
            'phone' => '0385789556',
            'verified' => false,
        ]);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);

        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_MAXREDIRS, 3);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $arrHeader = ['Content-type: application/json'];

        curl_setopt($curl, CURLOPT_HTTPHEADER, $arrHeader);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($curl);
        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $this->info(json_encode($result));
//        log_curl(KAL_CREDIT_API, $data_string, $result, "http code: $httpcode", 'atJAExCXKGgQufTCs8ToJgDGIFOfQRSByzwaUyC8');
        if (intval($httpcode) == 200) {
            return $result;
        } else {
        }
        curl_close($curl);
        return null;
    }
}
