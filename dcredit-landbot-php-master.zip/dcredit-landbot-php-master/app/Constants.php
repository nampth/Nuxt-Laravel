<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 10/17/2018
 * Time: 3:12 PM
 */

define('SUCCESS_CODE', 0);
define('ERROR_CODE', 1);
define('NOT_EXIST_CODE', 2);
define('EXISTED_CODE', 3);
// define url demo
define('KAL_API', 'https://api.kalapa.vn/support-lead/airtable/crm_telesale');
define('KAL_API_TEST', 'https://api.kalapa.vn/support-lead/airtable/crm_telesale');
define('KAL_API_LOG', 'https://api.kalapa.vn/support-lead/airtable/crm_telesale_log');

define('KAL_APPRAISE', 'https://api.kalapa.vn/postback_report/appraise/');
define('KAL_CREDIT_API', 'http://sv5:6016/card/put/');
define('KAL_CREDIT_API_LOG', 'http://sv5:6016/card/log/');
//define('LANDBOT_IFRAME', 'https://landbot.io/u/H-98894-USQ2EU7K8JUU2SMH/index.html');
define('LANDBOT_IFRAME', 'https://landbot.io/u/H-217641-HK9Y1WOUNP0WEAGE/index.html');

define('KAL_API_LOAN_CHECK', 'http://68.183.184.163:9011/loan/check/');
define('KAL_API_LOAN_REAPPLY', 'http://68.183.184.163:9011/loan/request/');
define('KAL_API_GATEWAY', 'http://68.183.184.163:9011/insert/');
define('KAL_API_GET_LOAN_STT', 'http://68.183.184.163:7010/user/status?phone=%s');
define('KAL_API_GET_USER_AIRTABLE', 'http://68.183.184.163:9011/get');
define('KAL_API_AIRTABLE_REGISTER', 'https://api.airtable.com/v0/apphaydM4wwVWuNSz/General');
define('KAL_API_AIRTABLE_GETID', "https://api.airtable.com/v0/apphaydM4wwVWuNSz/General?filterByFormula={phone}='%s'");
define('KAL_COLUMN_MULTIPLECHOICES', ['Công việc hiện tại', 'Giấy tờ', 'Giới tính', 'Chức danh công việc', 'Loại hợp đồng', 'Phương thức nhận lương/thu nhập', 'Tần suất nhận lương/thu nhập', 'Loại hình công việc', 'Tình trạng hôn nhân', 'Loại hình nhà ở', 'Mục đích vay', 'Phương thức giải ngân', 'Địa chỉ nhận thư', 'Hình thức liên lạc khác', 'Mối quan hệ 1', 'Mối quan hệ 2']);

define('APP_VERSION', '1.1.26');

define('ACCKIT_APP_ID', '404291800431097');
define('ACCKIT_SECRET', 'b7431fff93e4047cec5e135095b5a469');

define('ACCKIT_APP_ID_VNCREDIT', '499109704245455');
define('ACCKIT_SECRET_VNCREDIT', 'aeaa1224635ab172358aa860d35c360c');

define('ACCKIT_VERSION', 'v1.1'); // 'v1.1' for example

define('ACCKIT_APP_VNCREDIT_ID', '499109704245455');
define('ACCKIT_VNCREDIT_SECRET', '8dd934ab64ebe0285d514d56dc0bd037');

define('USER_STATUS_ACTIVE', 0);
define('USER_STATUS_INACTIVE', 1);
define('USER_STATUS_DELETED', 2);


define('FORM_TYPE_NUXT', 'nuxt_landing');

define('FORM_REQUIRED', 0);
define('FORM_UNREQUIRE', 1);

define('FB_PAGE_TOKEN', 'EAAGwRlZCkdO0BALSSBE4khBJkvCSitUtsca2Mk6SJYGqeXuMcB16HoMZCprF8fqad46cIxwdn6vMiHhQYFhDP4vCseDj6J3NqIimlMB6TJR7jdkqeV94MjDV6OcyknCXvq4pSNdKO5VcrH7kCALshTJksc6GBGkxZBWlQ2VNYuZASIe2ScV9E8ckQk0Ew1cZD');
define('GOOGLE_API_OPENAUTHEN', 'https://www.googleapis.com/userinfo/v2/me?access_token=%s');
define('FACEBOOK_API_OPENAUTHEN', 'https://graph.facebook.com/me?access_token=%s&fields=email,name');


define('GG_SHEET_CLIENT_SECRET', '4/vgGBJNZ0gd-f1mgK6cLjvet-sbg7Su6ks3nQrVhfJ_EZkjD2r-Fw50Q'); // 37qCVptJEqtB3x6YvWMdsnmb // 93NCyxwjTLeURKXE8PQx_x //c92c180e574c3163805be3734b17dc3c144fdcf7
define('GG_SHEET_SHEET_ID', '16NKShIPJKJZnl1bqVyMXr_-H0C0p9sDkT201mYGhP_o');
define('GG_SHEET_ROOT_API', 'https://sheets.googleapis.com');
define('GG_SHEET_API_KEY', 'AIzaSyA7V-GLdcvdYjwJ5sgIvGV_F6SjXwt2SOI');
//define('GG_SHEET_GET_DATA', GG_SHEET_ROOT_API . '/v4/spreadsheets/%s?key=%s'); // AIzaSyCVhjRkUtcSwkh_lWo2RTnH3zn2xG-AsRU  |  AIzaSyAJWIsvTaPAb9ordFyw4tWj-JLphL80asI
//define('GG_SHEET_GET_DATA_FROM_SHEET', GG_SHEET_ROOT_API . 'https://sheets.googleapis.com/v4/spreadsheets/%s?ranges=%s&fields=properties.title,sheets(properties,data.rowData.values(effectiveValue,effectiveFormat))&key=%s');

define('API_VOICE_OTP', 'https://aicallcenter.vn/api/autocall/voiceOTP?phone=%s&user_id=%s&cert=%s&campaign_id=%s&code=%s');
define('API_VOICE_OTP_CMC', 'https://api-connect.io/voice-otp/voice-otp');
define('API_VOICE_OTP_CMC_STATUS', 'https://api-connect.io/voice-otp/voice-otp/%s');
define('VOICE_CMC_IV', '0000000000000000');
define('VOICE_CMC_PHONE_FROM', '02471022456');
define('VOICE_CMC_APP_ID', '5e5739ddb0f2a928a8e6944e');
define('VOICE_CMC_APP_SECRET', 'Os6rwSR974adQknkfUVUSivC');
define('VOICE_CMC_KEY', 'sNcgTZwk4nSNQCtQzH82Jh8Ys9c0iZlk');
define('OTP_STATUS_UNVERIFIED', 0);
define('OTP_STATUS_VERIFIED', 1);
define('OTP_STATUS_EXPIRED', 2);

define('METRIC_DATA_VERIFIED', 0);
define('METRIC_DATA_UNVERIFIED', 1);

define('PDL_STATUS_PENDING', 0);
define('PDL_STATUS_DONE', 1);
define('PDL_STATUS_ERROR', 2);
define('API_TAMO_OTP', 'https://api.tamo.vn/web/public/client/phone/sms-code-ts');

define('NOTIFICATION_UN', 'WEB_NOTI');
define('NOTIFICATION_PW', 'WW3UmmpL3ax9sfb5');
define('NOTIFICATION_URL', 'https://api.pushalert.co/rest/v1/send');