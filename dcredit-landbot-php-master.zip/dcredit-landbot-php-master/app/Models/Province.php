<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 6/11/2019
 * Time: 11:05 AM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Province extends Model
{
    protected $table = 'provinces';

    protected $fillable = ['province', 'province_id', 'district', 'district_id', 'ward', 'ward_id', 'created_at', 'updated_at'];
}
