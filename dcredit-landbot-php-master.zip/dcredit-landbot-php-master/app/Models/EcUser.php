<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 9/13/2019
 * Time: 4:50 PM
 */

namespace App\Models;


use App\Traits\EcUserMetricDataTrait;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Tymon\JWTAuth\Contracts\JWTSubject;

class EcUser extends Authenticatable implements  JWTSubject
{
    use EcUserMetricDataTrait;

    protected $table = 'ec_users';

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        // TODO: Implement getJWTIdentifier() method.
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        // TODO: Implement getJWTCustomClaims() method.
        return [];
    }
}
