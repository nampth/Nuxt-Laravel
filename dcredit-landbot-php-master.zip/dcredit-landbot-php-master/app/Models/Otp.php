<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 12/5/2019
 * Time: 11:47 AM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Otp extends Model
{
    protected $table = 'otps';
}