<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 1/17/2020
 * Time: 2:08 PM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class UserFeedback extends Model
{
    protected $table = 'user_feedback';
}