<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 9/13/2019
 * Time: 5:20 PM
 */

namespace App\Models;


use App\Traits\MetricDataInfo;
use Illuminate\Database\Eloquent\Model;

class MetricData extends Model
{
    use MetricDataInfo;

    protected $table = 'metric_data';
    protected $fillable = ['user_id', 'metric_id', 'value', 'status', 'created_at', 'updated_at'];
}
