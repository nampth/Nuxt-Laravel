<?php
/**
 * Created by PhpStorm.
 * User: nampth
 * Date: 4/9/2020
 * Time: 11:17 AM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Social extends Model
{
    protected $table = 'socials';
    protected $fillable = ['sid', 'fb_id', 'data', 'note', 'created_at', 'updated_at'];
}