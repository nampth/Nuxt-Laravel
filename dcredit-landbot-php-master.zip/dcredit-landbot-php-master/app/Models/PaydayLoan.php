<?php
/**
 * Created by PhpStorm.
 * User: nampth
 * Date: 4/2/2020
 * Time: 11:19 AM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class PaydayLoan extends Model
{
    protected $table = 'paydayloan';
    protected $fillable = ['id', 'name', 'phone', 'data', 'status', 'created_at', 'updated_at'];
}