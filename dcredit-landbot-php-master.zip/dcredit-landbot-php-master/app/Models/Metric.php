<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 9/13/2019
 * Time: 4:50 PM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Metric extends Model
{

    protected $table = 'metrics';
}
