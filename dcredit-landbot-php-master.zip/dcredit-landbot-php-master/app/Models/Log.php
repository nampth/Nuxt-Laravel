<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 7/22/2019
 * Time: 11:18 AM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Log extends Model
{
    protected $table = 'logs';
    protected $fillable = ['action','phone','data','response','note','session_id'];
}
