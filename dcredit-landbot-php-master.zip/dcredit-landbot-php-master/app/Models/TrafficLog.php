<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 7/3/2019
 * Time: 5:10 PM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class TrafficLog extends Model
{
    protected $table = 'traffic_logs';
}