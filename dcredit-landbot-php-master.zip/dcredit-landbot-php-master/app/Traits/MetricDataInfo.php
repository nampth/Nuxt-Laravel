<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 9/13/2019
 * Time: 5:23 PM
 */

namespace App\Traits;

trait MetricDataInfo
{
    public function info()
    {
        return $this->belongsTo('App\Models\Metric', 'metric_id');
    }
}
