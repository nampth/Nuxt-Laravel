<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 9/13/2019
 * Time: 4:50 PM
 */

namespace App\Traits;

trait EcUserMetricDataTrait{
    public function metric_data(){
        return $this->hasMany('App\Models\MetricData','user_id');
    }
}
