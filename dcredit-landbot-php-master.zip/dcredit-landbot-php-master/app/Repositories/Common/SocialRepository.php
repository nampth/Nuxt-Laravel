<?php
/**
 * Created by PhpStorm.
 * User: nampth
 * Date: 4/9/2020
 * Time: 11:43 AM
 */

namespace App\Repositories\Common;


use App\Models\Social;
use App\Repositories\BaseRepository;

class SocialRepository extends BaseRepository
{

    /**
     * Specify Model class name.
     *
     * @return mixed
     */
    public function model()
    {
        // TODO: Implement model() method.
        return Social::class;
    }
}