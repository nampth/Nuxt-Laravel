<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 6/11/2019
 * Time: 2:46 PM
 */

namespace App\Repositories\Common;


use App\Models\Province;
use App\Repositories\BaseRepository;

class ProvinceRepository extends BaseRepository
{

    /**
     * Specify Model class name.
     *
     * @return mixed
     */
    public function model()
    {
        // TODO: Implement model() method.
        return Province::class;
    }

    public function listingAllProvince()
    {
        return $this->model->select('province', 'province_id')
            ->groupBy('province')
            ->orderBy('id', 'asc')
            ->get();
    }

    public function listingAllDistrict($province = null)
    {
        $query = $this->model->select('province', 'district', 'district_id');
        if ($province) {
            $query->where('province', 'like', "%$province%");
        }

        return $query->groupBy('district', 'district_id')
            ->orderBy('id', 'asc')
            ->get();
    }

    public function districtAjax($province, $keyword)
    {
        $query = $this->model->select('district', 'district_id')
            ->where('province', 'like', "%$province%")
            ->where('district', 'like', "%$keyword%")
            ->groupBy('district', 'district_id')
            ->orderBy('id', 'asc');
        $result = $query->get();
        return [
            'items' => $result,
            'total_count' => count($result)
        ];
    }

    public function getAllWards()
    {
        $query = $this->model->select('province', 'district', 'ward');

        return $query->orderBy('id', 'asc')
            ->get();
    }

    public function getAddress($q, $page, $countAll)
    {
        $query = $this->model
            ->where('province', 'like', "%$q%")
            ->orWhere('district', 'like', "%$q%")
            ->orWhere('ward', 'like', "%$q%");
        if ($countAll) {
            return $query->count();
        }

        return $query->limit(30, $page * 30)
            ->get();
    }


}
