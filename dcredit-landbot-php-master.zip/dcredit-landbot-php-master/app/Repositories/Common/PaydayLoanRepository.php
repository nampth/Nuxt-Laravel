<?php
/**
 * Created by PhpStorm.
 * User: nampth
 * Date: 4/2/2020
 * Time: 11:23 AM
 */

namespace App\Repositories\Common;


use App\Models\PaydayLoan;
use App\Repositories\BaseRepository;

class PaydayLoanRepository extends BaseRepository
{

    /**
     * Specify Model class name.
     *
     * @return mixed
     */
    public function model()
    {
        // TODO: Implement model() method.
        return PaydayLoan::class;
    }
}