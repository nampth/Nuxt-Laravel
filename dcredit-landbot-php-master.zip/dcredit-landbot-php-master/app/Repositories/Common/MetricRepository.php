<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 9/16/2019
 * Time: 10:21 AM
 */

namespace App\Repositories\Common;


use App\Models\Metric;
use App\Repositories\BaseRepository;

class MetricRepository extends BaseRepository
{

    /**
     * Specify Model class name.
     *
     * @return mixed
     */
    public function model()
    {
        // TODO: Implement model() method.
        return Metric::class;
    }

    public function getForm($formLv)
    {
        return Metric::where('form_level', $formLv)->get();
    }
}
