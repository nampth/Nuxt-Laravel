<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 3/17/2020
 * Time: 10:54 AM
 */

namespace App\Repositories\Common;


use App\Models\EcUser;
use App\Repositories\BaseRepository;

class EcUserRepository extends BaseRepository
{

    /**
     * Specify Model class name.
     *
     * @return mixed
     */
    public function model()
    {
        // TODO: Implement model() method.
        return EcUser::class;
    }

    public function deleteInArray($phone)
    {
        try {
            $blacklist = ['84385789556', '84356299110', '84379817898', '84374251748', '84972023258', '84972179189',
                '84962359783', '84358358374', '84981674339', '84965419980', '84968618697', '84979593196', '84978724693', '84868239035', '84989277662'];
            if (!$phone || !in_array($phone, $blacklist)) {
                return 'invalid phone';
            }
            $count = EcUser::where('phone', $phone)->count();
            if ($count == 0 || !$count) {
                return 'user deleted';
            }
            $users = EcUser::with('metric_data')->where('phone', $phone)->get();
            foreach($users as $user){
                $user->metric_data()->delete();
                $user->delete();
            }
            return 'ok';
        } catch (\Exception $e) {
            return 'bad';
        }
    }
}