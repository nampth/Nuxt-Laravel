<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 3/17/2020
 * Time: 10:48 AM
 */

namespace App\Repositories\Common;


use App\Models\UserFeedback;
use App\Repositories\BaseRepository;

class FeedbackRepository extends BaseRepository
{

    /**
     * Specify Model class name.
     *
     * @return mixed
     */
    public function model()
    {
        // TODO: Implement model() method.
        return UserFeedback::class;
    }

    public function addFeedback($sid, $type, $rate, $comment, $page, $note)
    {
        $feedback = new UserFeedback();
        $feedback->sid = $sid;
        $feedback->type = $type;
        $feedback->feedback_rate = $rate;
        $feedback->feedback_comment = $comment;
        $feedback->page = $page;
        $feedback->note = $note;
        if (!$feedback->save()) {
            return [
                'code' => ERROR_CODE
            ];
        }
        try {
            $client = $this->getClient();
            $client->addScope(\Google_Service_Sheets::SPREADSHEETS);
            $service = new \Google_Service_Sheets($client);
            if ($type == 'feedback') {
                $response1 = $service->spreadsheets_values->get(GG_SHEET_SHEET_ID, 'Data1!A:H');
                $response2 = $service->spreadsheets_values->get(GG_SHEET_SHEET_ID, 'Clone!A:H');

                $values1 = $response1->getValues();
                $values2 = $response2->getValues();
                $numRows1 = $values1 != null && is_array($values1) ? count($values1) : 0;
                $numRows2 = $values2 != null && is_array($values2) ? count($values2) : 0;
                $numRows1++;
                $numRows2++;
                $insertValue = [
                    [
                        $feedback->id . ' ',
                        $sid . ' ',
                        $rate . ' ',
                        $comment . ' ',
                        $page . ' ',
                        $note . ' ',
                        date($feedback->created_at) . ' '
                    ]
                ];
                $body = new \Google_Service_Sheets_ValueRange([
                    'values' => $insertValue
                ]);
                $result1 = $service->spreadsheets_values->append(GG_SHEET_SHEET_ID,
                    "Data1!A$numRows1:H$numRows1",
                    $body,
                    ['valueInputOption' => 'USER_ENTERED']
                );
                if (strlen(trim($note)) > 0) {
                    $result2 = $service->spreadsheets_values->append(GG_SHEET_SHEET_ID,
                        "Clone!A$numRows2:H$numRows2",
                        $body,
                        ['valueInputOption' => 'USER_ENTERED']
                    );
                } else {
                    $result2 = null;
                }

            } else {
                $response = $service->spreadsheets_values->get(GG_SHEET_SHEET_ID, 'NPS!A:E');
                $values = $response->getValues();
                $numRows = $values != null && is_array($values) ? count($values) : 0;
                $numRows++;
                $insertValue = [
                    [
                        $feedback->id . ' ',
                        $sid . ' ',
                        $rate . ' ',
                        $note . ' ',
                        date($feedback->created_at) . ' '
                    ]
                ];
                $body = new \Google_Service_Sheets_ValueRange([
                    'values' => $insertValue
                ]);
                $result1 = $service->spreadsheets_values->append(GG_SHEET_SHEET_ID,
                    "NPS!A$numRows:E$numRows",
                    $body,
                    ['valueInputOption' => 'USER_ENTERED']
                );
                $result2 = null;
            }

            return [
                'code' => SUCCESS_CODE,
                'result1' => $result1,
                'result2' => $result2,
            ];
        } catch (\Exception $error) {
            return [
                'code' => ERROR_CODE,
                'data' => 'google sheet'
            ];
        }
    }

    private function getClient()
    {
        $client = new \Google_Client();
        $client->setApplicationName('Google Sheets API PHP Quickstart');
        $client->setScopes(\Google_Service_Sheets::SPREADSHEETS_READONLY);
        $client->setAuthConfig(storage_path('app/credentials.json'));
        $client->setAccessType('offline');
        $client->setPrompt('select_account consent');

        // Load previously authorized token from a file, if it exists.
        // The file token.json stores the user's access and refresh tokens, and is
        // created automatically when the authorization flow completes for the first
        // time.
        $tokenPath = storage_path('app/token.json');
        if (file_exists($tokenPath)) {
            $accessToken = json_decode(file_get_contents($tokenPath), true);
            $client->setAccessToken($accessToken);
        }

        // If there is no previous token or it's expired.
        if ($client->isAccessTokenExpired()) {
            // Refresh the token if possible, else fetch a new one.
            if ($client->getRefreshToken()) {
                $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
            } else {
                // Request authorization from the user.
                $authUrl = $client->createAuthUrl();
                printf("Open the following link in your browser:\n%s\n", $authUrl);
                print 'Enter verification code: ';
                $authCode = trim(fgets(STDIN));

                // Exchange authorization code for an access token.
                $accessToken = $client->fetchAccessTokenWithAuthCode($authCode);
                $client->setAccessToken($accessToken);

                // Check to see if there was an error.
                if (array_key_exists('error', $accessToken)) {
                    throw new Exception(join(', ', $accessToken));
                }
            }
            if (!file_exists(dirname($tokenPath))) {
                mkdir(dirname($tokenPath), 0700, true);
            }
            file_put_contents($tokenPath, json_encode($client->getAccessToken()));
        }
        return $client;
    }
}