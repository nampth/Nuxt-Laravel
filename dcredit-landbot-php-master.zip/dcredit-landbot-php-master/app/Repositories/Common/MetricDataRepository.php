<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 3/17/2020
 * Time: 10:59 AM
 */

namespace App\Repositories\Common;


use App\Models\Metric;
use App\Models\MetricData;
use App\Repositories\BaseRepository;

class MetricDataRepository extends BaseRepository
{

    /**
     * Specify Model class name.
     *
     * @return mixed
     */
    public function model()
    {
        // TODO: Implement model() method.
        return MetricData::class;
    }

    public function addData($userId, $formLv, $arrData)
    {

        MetricData::whereHas('info', function ($q) use ($formLv) {
            $q->where('form_level', $formLv);
        })->where('user_id', $userId)->delete();

        $result = MetricData::insert($arrData);
    }

    public function updateInstant($userId, $formLevel, $key, $value)
    {
        $metric = Metric::where('key', $key)
            ->where('form_level', $formLevel)->first();
        if (!$metric || $metric->form_level == 1 || $metric->form_level == 11) {
            return false;
        }
        $metricData = MetricData::where('user_id', $userId)
            ->where('metric_id', $metric->id)
            ->first();
        if (!$metricData) {
            return $this->create([
                'user_id' => $userId,
                'metric_id' => $metric->id,
                'value' => $value,
                'status' => METRIC_DATA_UNVERIFIED
            ]);
        } else {
            $metricData->value = $value;
            return $metricData->save();
        }
    }

    public function renderArrayInsert($metrics, $request, $sid, $user, $phone, $formLv)
    {
        $arrData = [];
        $arrApi = [];

        foreach ($metrics as $metric) {
            $item = [];
            if ($metric->required == FORM_REQUIRED && !$request->exists($metric->key)) {
                return [
                    'code' => ERROR_CODE,
                    'result' => $metric->label_validation,
                    'data' => [],
                    'api' => []
                ];
            } else {
                $date = date('Y-m-d H:i:s');
                $item['metric_id'] = $metric->id;
                $item['user_id'] = $user->id;
                if ($metric->key == 'phone') {
                    $item['value'] = normalize_phone_number(trim(strip_tags($request->input($metric->key))));
                } else if ($metric->key == 'amount' || $metric->key == 'duration') {
                    $item['value'] = intval($request->input($metric->key));
                } else if ($metric->key == 'req_info') {
                    $item['value'] = '';
                } else if ($metric->key == 'sid') {
                    $sid = trim(strip_tags($request->input($metric->key)));
                    $item['value'] = trim(strip_tags($request->input($metric->key)));
                } else {
                    $item['value'] = trim(strip_tags($request->input($metric->key)));
                }
                $item['status'] = METRIC_DATA_VERIFIED;
                $item['created_at'] = $date;
                $item['updated_at'] = $date;

                // send API
                $arrApi[$metric->key] = $request->exists($metric->key) ? trim(strip_tags($request->input($metric->key))) : null;

            }
            $arrData[] = $item;
        }
        // map sid/social info with user
        if ($sid) {
            $social = \App\Models\Social::where('sid', $sid)->orderBy('created_at', 'desc')->first();
            $social = $social ? json_decode($social->data) : null;
            if ($social && $social->email) {
                $metricEmail = Metric::where('key', 'email_address')->first();
                if ($metricEmail) {
                    $arrData[] = array(
                        'metric_id' => $metricEmail->id,
                        'user_id' => $user->id,
                        'value' => $social->email,
                        'status' => METRIC_DATA_VERIFIED,
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    );
                }
            }
        }
        $arrApi['phone'] = $phone;
        $arrApi['form_level'] = $formLv;

        return [
            'code' => SUCCESS_CODE,
            'result' => null,
            'data' => $arrData,
            'api' => $arrApi
        ];
    }
}