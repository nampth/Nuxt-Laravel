<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 3/24/2020
 * Time: 10:33 AM
 */

namespace App\Repositories\Common;


use App\Models\Log;
use App\Repositories\BaseRepository;

class LogRepository extends BaseRepository
{

    /**
     * Specify Model class name.
     *
     * @return mixed
     */
    public function model()
    {
        // TODO: Implement model() method.
        return Log::class;
    }
}