<?php

namespace App\Http\Middleware;

//use App\Models\Log;
use Closure;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Log;

class SaveUserParam
{
//    private $startTime;

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
//        $this->startTime = microtime(true);
//        $this->terminate($request, '');
        return $next($request);
    }

    public function terminate($request, $response)
    {
        if ($request->method() == 'GET') {
            Log::info($request->method() . ' ' . 'access' . ' ' . $_SERVER['REQUEST_URI'] . ' ' . json_encode([
                    'from_ip' => $request->ip() . '-' . ($request->hasHeader('x-forwarded-for') ? $request->header('x-forwarded-for') : ''),
                    'header' => json_encode($request->header(), JSON_UNESCAPED_UNICODE),
                    'user_agent' => $request->header('User-Agent'),
                    'session_id' => md5(time() . ' ' . rand(0, 9999)),
                    'uri' => $_SERVER['REQUEST_URI'],
                    'view' => '2nd_version_uilanding',
                    'keyword' => str_replace("+", " ", $request->k)
                ], JSON_UNESCAPED_UNICODE));
        } else {
            $objRequest = $request->all();
            $objRequest['session_id'] = md5(time() . ' ' . rand(0, 9999));
            $arrRequest = (array)$objRequest;
            $arrResponse = (array)$response->original;
            Log::info($request->method() . ' ' . $request->get('type') . ' ' . $_SERVER['REQUEST_URI'] . ' '
                . json_encode($arrRequest, JSON_UNESCAPED_UNICODE) . '|||' . json_encode($arrResponse, JSON_UNESCAPED_UNICODE));
        }

    }
}
