<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 9/16/2019
 * Time: 2:25 PM
 */

namespace App\Http\Controllers\Auth;


use App\Http\Controllers\Controller;
use App\Http\Requests\FeedbackFormRequest;
use App\Http\Requests\NpsFormRequest;
use App\Http\Requests\UpdateInstantRequest;
use App\Models\EcUser;
use App\Models\Log;
use App\Models\MetricData;
use App\Models\UserFeedback;
use App\Repositories\Common\EcUserRepository;
use App\Repositories\Common\FeedbackRepository;
use App\Repositories\Common\MetricDataRepository;
use Illuminate\Support\Facades\Config;
use Revolution\Google\Sheets\Sheets;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Repositories\Common\MetricRepository;
use Illuminate\Http\Request;

class EcUserController extends Controller
{
    protected $auth;
    protected $metricRepo;
    protected $feedbackRepo;
    protected $ecuserRepo;
    protected $metricDataRepo;

    public function __construct(JWTAuth $auth, MetricRepository $metricRepository, FeedbackRepository $feedbackRepository, EcUserRepository $ecuserRepo, MetricDataRepository $metricDataRepo)
    {
        Config::set('jwt.user', EcUser::class);
        Config::set('auth.providers', ['users' => [
            'driver' => 'eloquent',
            'model' => EcUser::class,
        ]]);
        $this->auth = $auth;
        $this->feedbackRepo = $feedbackRepository;
        $this->metricRepo = $metricRepository;
        $this->ecuserRepo = $ecuserRepo;
        $this->metricDataRepo = $metricDataRepo;
    }

    public function log(Request $request)
    {
        return response()->json([
            'data' => ''
        ]);
    }

    public function loanstt(Request $request)
    {
        $result = curl_form("GET",
            sprintf(KAL_API_GET_LOAN_STT, $request->user()->phone),
            [], ['token: 04092019']
        );

        return response()->json(
            isset($result['data']) ? json_decode($result['data']) : $result
        );
    }

    public function infoec(Request $request)
    {
        $user = null;
        if ($request->exists('form_level')) {
            $user = EcUser::with(['metric_data' => function ($q) {
                $q->with('info');
            }])->where('form_level', $request->input('form_level'))
                ->where('verified', '<>', USER_STATUS_DELETED)
                ->find($request->user()->id);
        } else {
            $user = EcUser::with(['metric_data' => function ($q) {
                $q->with('info');
            }])->where('verified', '<>', USER_STATUS_DELETED)
                ->find($request->user()->id);
        }


        return response()->json([
            'success' => true,
            'data' => $user
        ]);
    }

    public function updateec(Request $request)
    {
        $formLv = $request->input('form_level');
        $phone = normalize_phone_number($request->input('phone'));

        // manual validation
        if (!$formLv || !$phone) {
            return response()->json([
                'success' => false,
                'result' => (!$phone ? 'SDT' : 'Form level') . ' bị thiếu',
                'data' => null,
                'code' => ERROR_CODE,
                'token' => null
            ]);
        }

        $user = EcUser::where('phone', $phone)
            ->where('verified', '<>', USER_STATUS_DELETED)
            ->first();
        if (!$user) {
            return response()->json([
                'success' => false,
                'result' => 'Tài khoản không tồn tại',
                'data' => null,
                'code' => ERROR_CODE,
                'token' => null
            ]);
        }

        // initial array data
        $metrics = $this->metricRepo->getForm($formLv);
        $arrData = [];
        $arrApi = [];
        foreach ($metrics as $metric) {
            $item = [];
            if ($metric->required == FORM_REQUIRED && !$request->exists($metric->key)) {
                return response()->json([
                    'success' => false,
                    'result' => $metric->label_validation . ' là bắt buộc',
                    'data' => 'Thông tin bị thiếu',
                    'code' => ERROR_CODE,
                    'token' => null
                ]);
            } else {
                $date = date('Y-m-d H:i:s');
                $item['metric_id'] = $metric->id;
                $item['user_id'] = $user->id;
                if ($metric->key == 'phone') {
                    $item['value'] = normalize_phone_number(trim(strip_tags($request->input($metric->key))));
                } else if ($metric->key == 'amount' || $metric->key == 'duration') {
                    $item['value'] = intval($request->input($metric->key));
                } else {
                    $item['value'] = trim(strip_tags($request->exists($metric->key) ? $request->input($metric->key) : ''));
                }
                $item['status'] = METRIC_DATA_VERIFIED;
                $item['created_at'] = $date;
                $item['updated_at'] = $date;
                $arrApi[$metric->key] = $request->exists($metric->key) ? trim(strip_tags($request->input($metric->key))) : null;
            }
            $arrData[] = $item;
        }
        $arrApi['phone'] = $phone;
        $arrApi['form_level'] = $formLv;

        return response()->json([
            'success' => true,
            'result' => $this->metricDataRepo->addData($user->id, $formLv, $arrData),
            'result2' => curl_form("POST", KAL_API_GATEWAY, $arrApi),
            'data' => json_encode($request->all()),
            'code' => SUCCESS_CODE,
            'token' => null
        ]);

    }

    public function updateInstant(UpdateInstantRequest $request)
    {
        $key = $request->input('key');
        $value = $request->input('value');
        $formLv = $request->input('form_level');
        $phone = normalize_phone_number($request->input('phone'));
        $user = EcUser::where('phone', $phone)
            ->where('verified', '<>', USER_STATUS_DELETED)
            ->first();
        if (!$user || !$phone) {
            return response()->json([
                'success' => false,
                'result' => 'Tài khoản không tồn tại',
                'data' => null,
                'code' => ERROR_CODE,
                'token' => null
            ]);
        }
        return response()->json([
            'code' => $this->metricDataRepo->updateInstant($user->id, $formLv, $key, $value) ? SUCCESS_CODE : ERROR_CODE
        ]);

    }

    public function feedback(FeedbackFormRequest $request)
    {
        $sid = $request->input('sid');
        $type = $request->exists('type') ? $request->input('type') : 'feedback';
        $rate = $request->input('feedback_rate');
        $comment = $request->input('feedback_comment');
        $page = $request->input('page');
        $note = $request->input('note');

        return response()->json($this->feedbackRepo->addFeedback($sid, $type, $rate, $comment, $page, $note));
    }

    public function nps(NpsFormRequest $request)
    {
        $sid = $request->input('sid');
        $type = $request->input('type');
        $rate = $request->input('feedback_rate');
        $note = $request->input('note');

        return response()->json($this->feedbackRepo->addFeedback($sid, $type, $rate, '', '', $note));
    }

    public function delete(Request $request)
    {
        $phone = $request->exists('phone') ? normalize_phone_number($request->input('phone')) : null;
        return $this->ecuserRepo->deleteInArray($phone);
    }
}