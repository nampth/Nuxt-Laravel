<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginFormRequest;
use App\Http\Requests\RegisterFormRequest;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Tymon\JWTAuth\Facades\JWTAuth;

class AuthController extends Controller
{
    protected $auth;

    public function __construct(JWTAuth $auth)
    {
        $this->auth = $auth;
    }

    public function register(RegisterFormRequest $request)
    {
        $mobile = $request->exists('phone') ? normalize_phone_number($request->input('phone')) : '';
        $name = $request->exists('name') ? $request->input('name') : '';
        $social_id = $request->exists('identity') ? $request->input('identity') : '';
        $city = $request->exists('province') ? $request->input('province') : '';
        $loan = $request->exists('amount') ? $request->input('amount') : '';
        $duration = $request->exists('duration') ? $request->input('duration') : '';

        $ref = $request->input('ref');
        $trafficSource = $request->input('traffic_source');
        $trafficId = $request->input('traffic_id');
        if (!$mobile) {
            return response()->json([]);
        }

        $postData = [
            'Phone' => $mobile,
            'Name' => $name,
            'CMND' => $social_id,
            'Tỉnh thành' => $city,
            'Nhu cầu' => $loan,
            'Kì hạn vay' => intval($duration),
            'FormLevel' => 1,
            'SessionID' => md5($mobile . ' ' . $social_id),
            'ADV' => "NULL",
            'ref' => $ref,
            'traffic_source' => $trafficSource,
            'traffic_id' => $trafficId,
//===================================
            'Địa chỉ liên hệ' => '',
            'Câu hỏi' => '',
            'QUẬN/HUYỆN' => '',
            'form_type' => FORM_TYPE_NUXT,
            'Thu nhập' => 0,
            'Loại Thu nhập' => '',
            'Công ty' => '',
            'Email' => '',
            'Giấy tờ' => implode(',', []),
            'Năm sinh' => 0,
            'verified' => false
        ];

        $result = curl_form('POST', KAL_API_TEST, $postData);


        $user = User::where('phone', $mobile)->first();
        if (!$user) {
            $user = new User();
            $user->phone = $mobile;
            $user->fullname = $name;
            $user->identity = $social_id;
            $user->province = $city;
            $user->verified = USER_STATUS_INACTIVE;
            $user->save();
        } else {
            $user->verified = USER_STATUS_INACTIVE;
            $user->save();
        }

        return response()->json([
            'success' => true,
            'result' => $result,
            'data' => json_encode($postData),
            'token' => null
        ]);
    }

    public function user(Request $request)
    {
        $user = Auth::user();

        if ($user) {
            return response($user, Response::HTTP_OK);
        }

        return response(null, Response::HTTP_BAD_REQUEST);
    }

    /**
     * Log out
     * Invalidate the token, so user cannot use it anymore
     * They have to relogin to get a new token
     *
     * @param Request $request
     */
    public function logout(Request $request)
    {
        $this->validate($request, ['token' => 'required']);

        try {
            JWTAuth::invalidate($request->input('token'));
            return response()->json('You have successfully logged out.', Response::HTTP_OK);
        } catch (JWTException $e) {
            return response()->json('Failed to logout, please try again.', Response::HTTP_BAD_REQUEST);
        }
    }

    public function refresh()
    {
        return response(JWTAuth::getToken(), Response::HTTP_OK);
    }

}
