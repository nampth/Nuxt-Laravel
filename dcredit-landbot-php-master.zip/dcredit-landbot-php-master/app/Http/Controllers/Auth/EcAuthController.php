<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 9/16/2019
 * Time: 2:26 PM
 */

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginFormRequest;
use App\Http\Requests\VerifyVoiceOtpRequest;
use App\Models\EcUser;
use App\Models\Log;
use App\Models\Metric;
use App\Models\Otp;
use App\Models\Social;
use App\Repositories\Common\MetricDataRepository;
use App\Repositories\Common\SocialRepository;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Repositories\Common\MetricRepository;
use Illuminate\Http\Request;
use App\Models\MetricData;

class EcAuthController extends Controller
{
    protected $auth;
    protected $metricRepo;
    protected $metricDataRepo;
    protected $socialRepo;

    public function __construct(JWTAuth $auth, MetricRepository $metricRepository, MetricDataRepository $metricDataRepository, SocialRepository $socialRepo)
    {
        Config::set('jwt.user', EcUser::class);
        Config::set('auth.providers', ['users' => [
            'driver' => 'eloquent',
            'model' => EcUser::class,
        ]]);
        $this->auth = $auth;
        $this->socialRepo = $socialRepo;
        $this->metricRepo = $metricRepository;
        $this->metricDataRepo = $metricDataRepository;
    }

    public function registerec(Request $request)
    {
        $formLv = $request->exists('form_level') ? $request->input('form_level') : null;
        $phone = $request->exists('phone') ? normalize_phone_number($request->input('phone')) : null;
        $sid = '';
        // manual validation
        if (!$formLv || !$phone) {
            $log = new Log();
            $log->action = 'register_error';
            $log->data = "$phone\_$formLv\_" . json_encode($request->all(), JSON_UNESCAPED_UNICODE);
            $log->response = '';
            $log->save();
            return response()->json([
                'code' => ERROR_CODE,
                'result' => "Phone number is missing",
                'data' => null,
                'token' => null
            ]);
        }
        $registered = false;
        // create user
        try {
            $user = EcUser::where('phone', $phone)
                ->where('verified', '<>', USER_STATUS_DELETED)
                ->first();
            if (!$user) {
                $user = new EcUser();
                $user->phone = $phone;
                $user->verified = USER_STATUS_INACTIVE;
                $user->save();
                \Illuminate\Support\Facades\Log::info('create_new_user ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE));
            } else {
                $log = new Log();
                $log->phone = $phone;
                $log->action = 'user_registered';
                $log->data = "$phone\_$formLv\_" . json_encode($request->all(), JSON_UNESCAPED_UNICODE);
                $log->response = '';
                $log->save();
                $registered = true;
                \Illuminate\Support\Facades\Log::info('user_registered ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE));
            }

            $user = new EcUser();
            $user->phone = $phone;
            $user->verified = USER_STATUS_INACTIVE;
            $user->save();
            \Illuminate\Support\Facades\Log::info('create_new_user ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE));

        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::info('insert_db_error ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE));
            throw $e;
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::info('insert_db_error ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE));
            throw $e;

        }
        // initial array data
        $metrics = $this->metricRepo->getForm($formLv);
        $initials = $this->metricDataRepo->renderArrayInsert($metrics, $request, $sid, $user, $phone, $formLv);
        if ($initials && $initials['code'] == SUCCESS_CODE) {
            $arrData = $initials['data'];
            $arrApi = $initials['api'];
        } else {
            return response()->json([
                'code' => $initials['code'],
                'result' => $initials['result'],
                'data' => null,
                'token' => null
            ]);
            $arrData = [];
            $arrApi = [];
        }

        // insert Data
        if (!$registered) {
            $result = $this->metricDataRepo->addData($user->id, $formLv, $arrData);
        }
        $resultApi = curl_form("POST", KAL_API_GATEWAY, $arrApi);
        $log = new Log();
        $log->action = $registered ? 're_submit_api' : 'submit_api';
        $log->data = json_encode($arrApi, JSON_UNESCAPED_UNICODE);
        $log->response = json_encode($resultApi, JSON_UNESCAPED_UNICODE);
        $log->save();

        if ($registered) {
            return response()->json([
                'code' => ERROR_CODE,
                'result' => 'Tài khoản đã tồn tại',
                'token' => null
            ]);
        } else {
            return response()->json([
                'code' => SUCCESS_CODE,
                'result' => $result,
                'token' => null
            ]);
        }
    }

    public function reRegister(Request $request)
    {
        $formLv = $request->exists('form_level') ? $request->input('form_level') : null;
        $phone = $request->exists('phone') ? normalize_phone_number($request->input('phone')) : null;
        $sid = '';
        // manual validation
        if (!$formLv || !$phone) {
            $log = new Log();
            $log->action = 'register_error';
            $log->data = "$phone\_$formLv\_" . json_encode($request->all(), JSON_UNESCAPED_UNICODE);
            $log->response = '';
            $log->save();
            return response()->json([
                'code' => ERROR_CODE,
                'result' => "Phone number is missing",
                'data' => null,
                'token' => null
            ]);
        }
        $registered = false;
        // create user
        try {
            $oldUser = EcUser::where('phone', $phone)
                ->where('verified', '<>', USER_STATUS_DELETED)->first();
            if ($oldUser) {
                $oldUser->verified = USER_STATUS_DELETED;
                $oldUser->save();

                $log = new Log();
                $log->phone = $phone;
                $log->action = 'user_registered';
                $log->data = "$phone\_$formLv\_" . json_encode($request->all(), JSON_UNESCAPED_UNICODE);
                $log->response = '';
                $log->save();
                $registered = true;
                \Illuminate\Support\Facades\Log::info('user_registered ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE));
            }

            $user = new EcUser();
            $user->phone = $phone;
            $user->verified = USER_STATUS_INACTIVE;
            $user->save();
            \Illuminate\Support\Facades\Log::info('create_new_user ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE));

        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::info('insert_db_error ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE));
            throw $e;
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::info('insert_db_error ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE));
            throw $e;

        }
        // initial array data
        $metrics = $this->metricRepo->getForm($formLv);
        $initials = $this->metricDataRepo->renderArrayInsert($metrics, $request, $sid, $user, $phone, $formLv);
        if ($initials && $initials['code'] == SUCCESS_CODE) {
            $arrData = $initials['data'];
            $arrApi = $initials['api'];
        } else {
            return response()->json([
                'code' => $initials['code'],
                'result' => $initials['result'],
                'data' => null,
                'token' => null
            ]);
            $arrData = [];
            $arrApi = [];
        }

        // insert Data
        $result = $this->metricDataRepo->addData($user->id, $formLv, $arrData);
        $resultApi = curl_form("POST", KAL_API_GATEWAY, $arrApi);


        return response()->json([
            'code' => SUCCESS_CODE,
            'result' => $result,
            'token' => $token = JWTAuth::fromUser($user)
        ]);
    }

    public function loginec(Request $request)
    {
//        $credentials = $request->only('phone', 'code');
        $postCode = $request->input('code');
        $postPhone = normalize_phone_number($request->input('phone'));

        $result = get_data_acckit($postCode);
        $phone = ($result && isset($result['phone']) ? normalize_phone_number($result['phone']['number']) : '');
        $email = $result && isset($result['email']) ? $result['email']['address'] : '';

        $user = ($phone && ($postPhone == $phone)) ? EcUser::where('phone', $phone)->where('verified', '<>', USER_STATUS_DELETED)->first() : null;
//        $user = EcUser::where('phone', $postPhone)->first();
        if (!$user) {
            return response()->json([
                'success' => false,
                'token' => null,
                'status' => 'error',
                'error' => 'invalid.credentials',
                'msg' => 'Invalid Credentials.',
            ], Response::HTTP_BAD_REQUEST);
        } else {
            $token = JWTAuth::fromUser($user);
            $user->verified = USER_STATUS_ACTIVE;
            $user->save();
            $resultApi = null;
            if (intval($user->verified) == USER_STATUS_INACTIVE) {
                $arrApi = [];
                $arrApi['phone'] = $user->phone;
                $arrApi['verified'] = USER_STATUS_ACTIVE;
                $resultApi = curl_form("POST", KAL_API_GATEWAY, $arrApi);
            }


            return response()->json([
                'success' => true,
                'result' => $resultApi,
                'token' => $token
            ], Response::HTTP_OK);
        }
    }

    public function socialLogin(Request $request)
    {
        try {
            $type = $request->exists('type') ? $request->input('type') : 'google';
            $sid = $request->exists('sid') ? $request->input('sid') : '';
            $token = $request->exists('access_token') ? $request->input('access_token') : null;
            $authToken = $request->exists('token') ? $request->input('token') : null;
            if ($sid && $token) {
                // get info from facebook
                $info = do_curl(sprintf($type == 'google' ? GOOGLE_API_OPENAUTHEN : FACEBOOK_API_OPENAUTHEN, $token));
                $fbId = isset($info['id']) ? $info['id'] : '';
                $email = isset($info['email']) ? $info['email'] : '';
                // save into socials table
                $this->socialRepo->create([
                    'sid' => $sid,
                    'fb_id' => $fbId,
                    'data' => json_encode($info),
                    'note' => $token
                ]);

                if ($info) {
                    // check existed fb id
                    $metricFbidIds = Metric::where('key', "fbid")->get();
                    $arrMetricFbId = [];
                    foreach ($metricFbidIds as $metricFbidId) {
                        $arrMetricFbId[] = $metricFbidId->id;
                    }
                    $count = MetricData::whereIn('metric_id', $arrMetricFbId)->where('value', $fbId)->count();
                    $metricData = MetricData::whereIn('metric_id', $arrMetricFbId)->where('value', $fbId)->first();

                    if ($metricData) {
                        // user exist
                        $user = EcUser::find($metricData->user_id);
                        if ($user) {
                            $token = JWTAuth::fromUser($user);
                            $metric = Metric::where('key', 'sid')->first();
                            //if facebook hadnt mapped to any account then add current facebook to account
                            if ($count == 0) {
                                // assign facebook to account
                                $metricDataFbid = Metric::where('key', 'fbid')->first();
                                $this->metricDataRepo->create([
                                    'user_id' => $user->id,
                                    'metric_id' => $metricDataFbid->id,
                                    'value' => $fbId,
                                    'status' => METRIC_DATA_VERIFIED
                                ]);

                                // assign email to account
                                if ($email && $metric) {
                                    MetricData::where('metric_id', $metric->id)->where('user_id', $user->id)->delete();
                                    $this->metricDataRepo->create([
                                        'user_id' => $user->id,
                                        'metric_id' => $metric->id,
                                        'value' => $email,
                                        'status' => METRIC_DATA_VERIFIED
                                    ]);
                                }
                            }

                            return response()->json([
                                'success' => true,
                                'token' => !$authToken ? $token : $authToken,
                                'status' => $count > 0 ? 'existed' : 'new'
                            ]);
                        }
                    }
                    // user not exist return null or current auth token
                    return response()->json([
                        'success' => true,
                        'token' => $authToken,
                        'status' => 'error'
                    ]);

                } else {
                    return response()->json([
                        'success' => false,
                        'token' => $authToken,
                        'status' => 'error',
                        'error' => 'invalid.credentials',
                        'msg' => 'Invalid Credentials.',
                    ]);
                }
            } else {
                return response()->json([
                    'success' => false,
                    'token' => $authToken,
                    'status' => 'error',
                    'error' => 'invalid.credentials',
                    'msg' => 'Invalid Credentials.',
                ]);
            }
        } catch (\Exception $exception) {
            return response()->json([
                'success' => false,
                'token' => null,
                'status' => 'error',
                'error' => 'Something wents wrong',
                'msg' => 'Something wents wrong',
            ]);
        }
    }

    public function voiceOtp(Request $request)
    {
        $reqInfo = $request->method() . '|||' . $_SERVER['REQUEST_URI'] . '|||' . $request->ip() . '|||' . ($request->hasHeader('x-forwarded-for') ? $request->header('x-forwarded-for') : '')
            . '|||' . json_encode($request->header(), JSON_UNESCAPED_UNICODE) . '|||' . $request->header('User-Agent');
        $phone = normalize_phone_number($request->input('phone'));
        $user = EcUser::where('phone', $phone)
            ->where('verified', '<>', USER_STATUS_DELETED)
            ->first();
        if (!$user) {
            return response()->json([
                'code' => ERROR_CODE,
                'message' => 'user not existed'
            ]);
        }
//        try {
        $checkExisted = Otp::where('user_id', $user->id)->where('status', OTP_STATUS_UNVERIFIED)->first();
        if ($checkExisted) {
            $date1Timestamp = strtotime($checkExisted->created_at);
            $date2Timestamp = strtotime(date('Y-m-d H:i:s'));
            $difference = ($date2Timestamp - $date1Timestamp) / 60; // get diffrence by min
            if ($difference <= 5) {
                // get call status
                $result = curl_form('GET', sprintf(API_VOICE_OTP_CMC_STATUS, $checkExisted->call_id), [], ["Authorization: Basic NWU1NzM5ZGRiMGYyYTkyOGE4ZTY5NDRlOk9zNnJ3U1I5NzRhZFFrbmtmVVZVU2l2Qw=="]);
                $data = json_decode($result['data']);
                if ($data->status != 'pending') {
                    return response()->json([
                        'code' => ERROR_CODE,
                        'message' => 'otp sent',
                        'status' => $data->status
                    ]);
                }

            }
            $checkExisted->status = OTP_STATUS_EXPIRED;
            $checkExisted->save();


        }
        $otpNumber = rand(1e3, 1e4);
        $otp = new Otp();
        $otp->otp = $otpNumber;
        $otp->user_id = $user->id;
        $otp->req_info = $reqInfo;
        $otp->status = OTP_STATUS_UNVERIFIED;
        $otp->save();


        $type = 'south-side';
        $result = send_voice_otp($otpNumber, $phone, $type);
        if ($result) {
            $otp->response = $result;
            $result = json_decode($result);
            $otp->call_id = $result->id;
            $otp->save();
            return response()->json([
                'code' => SUCCESS_CODE,
                'data' => $result
            ]);
        } else {
            return response()->json([
                'code' => SUCCESS_CODE
            ]);
        }
//        } catch (\Exception $e) {
//            return response()->json([
//                'code' => ERROR_CODE,
//                'msg' => 'something wents wrong'
//            ]);
//        }
    }

    public function verifyVoiceOtp(VerifyVoiceOtpRequest $request)
    {
        $phone = normalize_phone_number($request->input('phone'));
        $code = $request->input('code');


        $user = EcUser::where('phone', $phone)
            ->where('verified', '<>', USER_STATUS_DELETED)->first();
        if (!$user) {
            return response()->json([
                'code' => ERROR_CODE,
                'msg' => 'user not existed'
            ]);
        }

        $otp = Otp::where('otp', $code)
            ->where('user_id', $user->id)
            ->where('status', OTP_STATUS_UNVERIFIED)
            ->first();
        if (!$otp) {
            return response()->json([
                'code' => ERROR_CODE,
                'msg' => 'otp wrong'
            ]);
        }
        $date1Timestamp = strtotime($otp->created_at);
        $date2Timestamp = strtotime(date('Y-m-d H:i:s'));
        $difference = ($date2Timestamp - $date1Timestamp) / 60;
        if ($difference > 5) {
            return response()->json([
                'code' => ERROR_CODE,
                'message' => 'otp expired'
            ]);
        } else {
            $otp->status = OTP_STATUS_VERIFIED;
            $otp->save();

            $user->verified = USER_STATUS_ACTIVE;
            $user->save();

            $token = JWTAuth::fromUser($user);

            return response()->json([
                'code' => SUCCESS_CODE,
                'success' => true,
                'token' => $token
            ], Response::HTTP_OK);
        }
    }

    public function logout(Request $request)
    {
        try {
            JWTAuth::invalidate($request->header('Authorization'));
            return response()->json('You have successfully logged out.', Response::HTTP_OK);
        } catch (JWTException $e) {
            return response()->json('Failed to logout, please try again.', Response::HTTP_BAD_REQUEST);
        }
    }

    public function refresh()
    {
        return response(JWTAuth::getToken(), Response::HTTP_OK);
    }

    public function exist(Request $request)
    {
        $formLv = $request->exists('form_level') ? $request->input('form_level') : null;
        $phone = $request->exists('phone') ? normalize_phone_number($request->input('phone')) : null;

        if (!$formLv || !$phone) {
            $log = new Log();
            $log->action = 'register_error';
            $log->data = "$phone\_$formLv\_" . json_encode($request->all(), JSON_UNESCAPED_UNICODE);
            $log->response = '';
            $log->save();
            return response()->json([
                'code' => ERROR_CODE,
                'result' => "Phone number is missing",
                'data' => null,
                'token' => null
            ]);
        }
        // check if user registered
        $registered = false;
//        try {
        $user = EcUser::with(['metric_data' => function ($q) {
            $q->with('info');
        }])->where('phone', $phone)
            ->where('verified', '<>', USER_STATUS_DELETED)
            ->first();
        if (!$user) {
            return response()->json([
                'code' => SUCCESS_CODE,
                'result' => "Ok",
                'data' => null,
                'token' => null
            ]);
        } else {
            return response()->json([
                'code' => EXISTED_CODE,
                'result' => "User existed",
                'data' => censore_data($user),
                'token' => null
            ])->withHeaders([
                'Content-Type' => 'application/json; charset=utf-8'
            ]);
        }
//        } catch (\Exception $e) {
//            return response()->json([
//                'code' => ERROR_CODE,
//                'result' => "Phone number is missing",
//                'data' => null,
//                'token' => null
//            ]);
//        }
    }

    public function score(Request $request)
    {
        try {
            $phone = normalize_phone_number($request->input('phone'));
            if (!$phone) {
                return response()->json([
                    'data' => null,
                    'code' => ERROR_CODE
                ]);
            }
            $url = "https://api.kalapa.vn/postback_report/score/?phone=$phone";
            $result = curl_form('GET', $url);
            if ($result && $result['code'] == 200) {
                return response()->json([
                    'code' => SUCCESS_CODE,
                    'data' => $result['data']
                ]);
            }
            return response()->json([
                'data' => null,
                'code' => ERROR_CODE
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'data' => null,
                'code' => ERROR_CODE
            ]);
        }
    }


    public function adv(Request $request)
    {
        try {
            $phone = normalize_phone_number($request->input('phone'));
            if (!$phone) {
                return response()->json([
                    'data' => null,
                    'code' => ERROR_CODE
                ]);
            }
            $url = "https://api.kalapa.vn/postback_report/adv/?phone=$phone";
            $result = curl_form('GET', $url);
            if ($result && $result['code'] == 200) {
                return response()->json([
                    'code' => SUCCESS_CODE,
                    'data' => $result['data']
                ]);
            }
            return response()->json([
                'data' => null,
                'code' => ERROR_CODE
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'data' => null,
                'code' => ERROR_CODE
            ]);
        }
    }
}
