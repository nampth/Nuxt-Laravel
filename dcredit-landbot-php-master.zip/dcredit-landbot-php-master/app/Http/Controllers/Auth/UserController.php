<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\User;

class UserController extends Controller
{
    protected $auth;

    public function __construct(JWTAuth $auth)
    {
        $this->auth = $auth;
    }

    public function log(Request $request)
    {
        return response()->json([
            'data' => ''
        ]);
    }

    public function home(Request $request)
    {
        $token = null;
        try {
            $token = JWTAuth::parseToken();
        } catch (\Exception $e) {

        }
        return view('pages.auth.user-info')
            ->with([
                'token' => $token
            ]);
    }

    public function info(Request $request)
    {
        $token = null;
        try {
            $token = JWTAuth::parseToken();
        } catch (\Exception $e) {

        }
        return view('pages.auth.user-info')
            ->with([
                'token' => $token
            ]);
    }

    public function loanProcess(Request $request)
    {
        $token = null;
        try {
            $token = JWTAuth::parseToken();
        } catch (\Exception $e) {

        }
        return view('pages.auth.loan-process')
            ->with([
                'token' => $token
            ]);
    }

    public function refer(Request $request)
    {
        $token = null;
        try {
            $token = JWTAuth::parseToken();
        } catch (\Exception $e) {

        }

        return view('pages.auth.refer')
            ->with([
                'token' => $token ? true : false
            ]);
    }


    public function policy(Request $request)
    {
        $token = null;
        try {
            $token = JWTAuth::parseToken();
        } catch (\Exception $e) {

        }
        return view('pages.common.policy')
            ->with([
                'token' => $token
            ]);
    }

    public function update(Request $request)
    {
        $form = $request->input('form');
        $phone = normalize_phone_number($request->input('phone'));

        $user = User::where('phone', $phone)->first();
        if (!$user) {
            return response()->json([]);
        }
        // form 1
        $income = $request->input('income');
        $incomeType = $request->input('income_type');
        $company = $request->input('company');
        $district = $request->input('district');
        $email = $request->input('email');
        $birth = $request->input('identity_birth');
        $address = $request->input('address');

        switch ($form) {
            case 'form1':
                $user->income = $income;
                $user->income_type = $incomeType;
                $user->company = $company;
                $user->district = $district;
                $user->address = $address;
                $user->age = $birth;
                $user->email = $email;
                $user->save();

                $postData = [
                    'FormLevel' => 2,
                    'ADV' => "NULL",
                    'Phone' => $phone,
                    'Địa chỉ liên hệ' => $address,
                    'Câu hỏi' => '',
                    'QUẬN/HUYỆN' => $district,
                    'form_type' => FORM_TYPE_NUXT,
                    'Thu nhập' => $address ? floatval($income) / 10 : 0,
                    'Loại Thu nhập' => $incomeType,
                    'Công ty' => $company,
                    'Email' => $email,
                    'Giấy tờ' => implode(',', []),
                    'Năm sinh' => intval($birth),
                    'SessionID' => md5($user->phone . ' ' . $user->identity),
                    'verified' => true
                ];


                $result = curl_form('POST', KAL_API_TEST, $postData);

                return response()->json([
                    'code' => SUCCESS_CODE,
                    'result' => json_encode($result),
                    'request' => json_encode($postData),
                ]);
                break;
            default:
                break;
        }


    }

    public function logout(Request $request)
    {
        try {
            JWTAuth::invalidate($request->header('Authorization'));
            return redirect('/');
        } catch (\Exception $e) {
            return redirect('/');
        }
    }


}
