<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 7/30/2019
 * Time: 5:13 PM
 */

namespace App\Http\Controllers\Frontend;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\Common\ProvinceRepository;
use Illuminate\Support\Facades\Session;

class UILandingController extends Controller
{
    protected $provinceRepo;

    public function __construct(ProvinceRepository $provinceRepository)
    {
        $this->provinceRepo = $provinceRepository;
    }


    public function registerk(Request $request)
    {
        $mobile = $request->exists('mobile') ? $request->input('mobile') : '';
        $name = $request->exists('name') ? $request->input('name') : '';
        $social_id = $request->exists('social_id') ? $request->input('social_id') : '';
        $city = $request->exists('city') ? $request->input('city') : '';
        $loan = $request->exists('loan') ? $request->input('loan') : '';
        $duration = $request->exists('duration') ? $request->input('duration') : '';

        $ref = $request->exists('ref') ? $request->input('ref') : '';
        $address = $request->exists('address') ? $request->input('address') : '';
        $email = $request->exists('email') ? $request->input('email') : '';
        $question = $request->exists('question') ? $request->input('question') : '';
        $district = $request->exists('district') ? $request->input('district') : '';
        $income = $request->exists('income') ? $request->input('income') : '';
        $income_type = $request->exists('income_type') ? $request->input('income_type') : '';
        $checkedProfiles = $request->exists('checkedProfiles') ? $request->input('checkedProfiles') : [];
        $company = $request->exists('company') ? $request->input('company') : '';
        $birth = $request->exists('identity_birth') ? $request->input('identity_birth') : '';
        $type = $request->exists('type') ? $request->input('type') : 'form';

        $postData = [
            'Name' => $name,
            'CMND' => $social_id,
            'Tỉnh thành' => $city,
            'Nhu cầu' => $loan,
            'Kì hạn vay' => intval($duration),
            'FormLevel' => $address ? 2 : 1,
            'SessionID' => Session::getId(),
            'ADV' => "NULL",
            'ref' => Session::exists('ref') ? Session::get('ref') : $ref,
            'traffic_source' => Session::exists('traffic_source') ? Session::get('traffic_source') : '',
            'traffic_id' => Session::exists('traffic_id') ? Session::get('traffic_id') : '',
//===================================
            'Địa chỉ liên hệ' => $address,
            'Câu hỏi' => $question,
            'QUẬN/HUYỆN' => $district,
            'form_type' => '2nd_version_uilanding_optimized_keyword',
            'Thu nhập' => $address ? floatval($income) : 0,
            'Loại Thu nhập' => $income_type,
            'Công ty' => $company,
            'Email' => $email,
            'Giấy tờ' => implode(',', $checkedProfiles),
            'Năm sinh' => intval($birth)
        ];

        $result = null;
        if ($request->exists('code') && $type == 'form') {
            // Exchange authorization code for access token
            $result = get_data_acckit($request->input('code'));

            $phone = isset($result['phone']) ? $result['phone']['number'] : '';
            $email = isset($result['email']) ? $result['email']['address'] : '';

            if ($phone) {
                $postData['Phone'] = $phone;
                $postData['verified'] = true;

                $result = curl_form('POST', KAL_API_TEST, $postData);
                return response()->json([
                    'code' => SUCCESS_CODE,
                    'result' => json_encode($result, JSON_UNESCAPED_UNICODE),
                    'request' => json_encode($postData, JSON_UNESCAPED_UNICODE),
                    'session_id' => Session::getId()
                ]);
            }
            return response()->json([
                'code' => SUCCESS_CODE,
                'result' => json_encode($result, JSON_UNESCAPED_UNICODE),
                'request' => json_encode($postData, JSON_UNESCAPED_UNICODE),
                'session_id' => Session::getId()
            ]);
        } else {

            $postData['Phone'] = $mobile;
            $postData['verified'] = false;

            if ($type == 'form') {
                $result = curl_form('POST', $type == 'log' ? KAL_API_LOG : KAL_API_TEST, $postData);
            }
            return response()->json([
                'code' => SUCCESS_CODE,
                'result' => json_encode($result, JSON_UNESCAPED_UNICODE),
                'request' => json_encode($postData, JSON_UNESCAPED_UNICODE),
                'session_id' => Session::getId()
            ]);
        }

    }

    public function facebook(Request $request)
    {
        $ch = curl_init();
        $pageToken = FB_PAGE_TOKEN;
        curl_setopt($ch, CURLOPT_URL, "https://graph.facebook.com/v2.6/me/messages?access_token=$pageToken");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "{\n  \"recipient\": {\n    \"user_ref\":\"" . $request->input('user_ref') . "\"\n  }, \n  \"message\": {\n    \"text\":\"Cảm ơn quý khách đã lựa chọn Dcredit, quý khách đã đăng ký thành công các thông tin cơ bản, để được hỗ trợ tiếp, quý khách vui lòng xác nhận số chứng minh nhân dân hoặc căn cước công dân.\"\n  }\n}");
        curl_setopt($ch, CURLOPT_POST, 1);

        $headers = array();
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        print_r($result);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);

        // Generated by curl-to-PHP: http://incarnate.github.io/curl-to-php/
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://graph.facebook.com/v2.6/me/messages?access_token=$pageToken");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "{\n  \"recipient\": {\n    \"user_ref\":\"" . $request->input('user_ref') . "\"\n  },\n  \"message\":{\n    \"text\": \"xác nhận\",\n    \"quick_replies\":[\n      {\n        \"content_type\":\"text\",\n        \"title\":\"" . $request->input('identity') . "\",\n\t\"payload\":\"\"\n      }\n    ]\n  }\n}");
        curl_setopt($ch, CURLOPT_POST, 1);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $result = curl_exec($ch);
        print_r($result);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);

    }
}

