<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 10/17/2018
 * Time: 2:20 PM
 */

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\Common\ProvinceRepository;
use Illuminate\Support\Facades\Session;

class HomeController extends Controller
{
    protected $provinceRepo;

    public function __construct(ProvinceRepository $provinceRepository)
    {
        $this->provinceRepo = $provinceRepository;
    }


    public function index(Request $request)
    {
        $keyword = str_replace("+", " ", $request->k);
        $paramProvince = str_replace("+", " ", $request->p);

        $ref = $request->ref;
        $trafficSource = $request->traffic_source;
        $trafficId = $request->traffic_id;
        $userRef = md5(microtime());
        if (!Session::exists('ref')) {
            Session::put('ref', $ref);
        }
        if (!Session::exists('traffic_source') && $trafficSource) {
            Session::put('traffic_source', $trafficSource);
        }
        if (!Session::exists('traffic_id') && $trafficId) {
            Session::put('traffic_id', $trafficId);
        }
        header("Cache-Control: no-cache, must-revalidate"); //HTTP 1.1
        header("Pragma: no-cache"); //HTTP 1.0
        header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past

        return view('landing.form.formkeyword')->with([
            'keyword' => $keyword,
            'p' => $paramProvince,
            'userRef' => $userRef,
        ]);
    }

    public function districtAjax(Request $request)
    {
        return response()->json(
            $this->provinceRepo->districtAjax(
                $request->input('id'),
                $request->input('search')
            ));
    }

}
