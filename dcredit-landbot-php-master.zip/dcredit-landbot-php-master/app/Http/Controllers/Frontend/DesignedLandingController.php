<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 8/14/2019
 * Time: 2:51 PM
 */

namespace App\Http\Controllers\Frontend;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\Common\ProvinceRepository;
use Illuminate\Support\Facades\Session;

class DesignedLandingController extends Controller
{
    protected $provinceRepo;

    public function __construct(ProvinceRepository $provinceRepository)
    {
        $this->provinceRepo = $provinceRepository;
    }


    public function index(Request $request)
    {
        $keyword = str_replace("+", " ", $request->k);
        $paramProvince = str_replace("+", " ", $request->p);
        $ref = $request->ref;
        $trafficSource = $request->traffic_source;
        $trafficId = $request->traffic_id;

        $ip = $request->ip();
        $ua = $request->header('User-Agent');
        $headers = $request->header();
        $sessionId = Session::getId();
        $uri = $_SERVER['REQUEST_URI'];
        $sourceIp = $request->hasHeader('x-forwarded-for') ? $request->header('x-forwarded-for') : '';

        $provinces = $this->provinceRepo->listingAllProvince();
        $districts = $this->provinceRepo->listingAllDistrict();

        $index = rand(0, 9);
        $new = false;
        if (Session::exists('number')) {
            $index = Session::get('number');
        } else {
            $new = true;
            Session::put('number', $index);
        }
        if (!Session::exists('ref')) {
            Session::put('ref', $ref);
        }
        if (!Session::exists('traffic_source')) {
            Session::put('traffic_source', $trafficSource);
        }
        if (!Session::exists('traffic_id')) {
            Session::put('traffic_id', $trafficId);
        }
        if ($new) {
            save_traffic_log($ip, $ua, '1st_designed_landing', $keyword, json_encode($headers), $sessionId, $sourceIp, $uri);
        }

        return view('new-landing.form.index')->with([
            'keyword' => $keyword,
            'provinces' => $provinces,
            'districts' => $districts,
            'p' => $paramProvince
        ]);
    }

    public function register(Request $request)
    {
        $mobile = $request->exists('mobile') ? $request->input('mobile') : '';
        $name = $request->exists('name') ? $request->input('name') : '';
        $social_id = $request->exists('social_id') ? $request->input('social_id') : '';
        $city = $request->exists('city') ? $request->input('city') : '';
        $loan = $request->exists('amount') ? $request->input('amount') : '';
        $duration = $request->exists('duration') ? $request->input('duration') : '';

        $ref = $request->exists('ref') ? $request->input('ref') : '';
        $address = $request->exists('address') ? $request->input('address') : '';
        $email = $request->exists('email') ? $request->input('email') : '';
        $question = $request->exists('question') ? $request->input('question') : '';
        $district = $request->exists('district') ? $request->input('district') : '';
        $income = $request->exists('income') ? $request->input('income') : '';
        $income_type = $request->exists('income_type') ? $request->input('income_type') : '';
        $checkedProfiles = $request->exists('checkedProfiles') ? $request->input('checkedProfiles') : [];
        $company = $request->exists('company') ? $request->input('company') : '';
        $birth = $request->exists('identity_birth') ? $request->input('identity_birth') : '';
        $type = $request->exists('type') ? $request->input('type') : 'data';


        $postData = [
            'Name' => $name,
            'CMND' => $social_id,
            'Tỉnh thành' => $city,
            'Nhu cầu' => $loan,
            'Kì hạn vay' => intval($duration),
            'FormLevel' => $address ? 2 : 1,
            'SessionID' => Session::getId(),
            'ADV' => "NULL",
            'ref' => Session::exists('ref') ? Session::get('ref') : $ref,
            'traffic_source' => Session::exists('traffic_source') ? Session::get('traffic_source') : '',
            'traffic_id' => Session::exists('traffic_id') ? Session::get('traffic_id') : '',
//===================================
            'Địa chỉ liên hệ' => $address,
            'Câu hỏi' => $question,
            'QUẬN/HUYỆN' => $district,
            'form_type' => '1st_designed_landing',
            'Thu nhập' => floatval($income / 10),
            'Loại Thu nhập' => $income_type,
            'Công ty' => $company,
            'Email' => $email,
            'Giấy tờ' => implode(',', $checkedProfiles),
            'Năm sinh' => intval($birth)
        ];

        if ($request->exists('code') && $type == 'data') {
            $app_id = '404291800431097';
            $secret = 'b7431fff93e4047cec5e135095b5a469';
            $version = 'v1.1'; // 'v1.1' for example

            // Exchange authorization code for access token
            $token_exchange_url = 'https://graph.accountkit.com/' . $version . '/access_token?' .
                'grant_type=authorization_code' .
                '&code=' . $request->input('code') . "&access_token=AA|$app_id|$secret";
            $data = do_curl($token_exchange_url);

            $user_id = $data['id'];
            $user_access_token = $data['access_token'];
            $refresh_interval = $data['token_refresh_interval_sec'];

            // Get Account Kit information
            $me_endpoint_url = 'https://graph.accountkit.com/' . $version . '/me?' .
                'access_token=' . $user_access_token;
            $data = do_curl($me_endpoint_url);

            $phone = isset($data['phone']) ? $data['phone']['number'] : '';
            $email = isset($data['email']) ? $data['email']['address'] : '';

            if ($phone) {
                $postData['Phone'] = $phone;
                $postData['verified'] = true;

                $result = curl_form('POST', KAL_API_TEST, $postData);
                return response()->json([
                    'code' => SUCCESS_CODE,
                ]);
            } else {

            }
            return response()->json([
                'code' => ERROR_CODE
            ]);
        } else {

            $postData['Phone'] = $mobile;
            $postData['verified'] = false;

            $result = curl_form('POST', $type == 'log' ? KAL_API_LOG : KAL_API_TEST, $postData);
            return response()->json([
                'code' => SUCCESS_CODE,
            ]);
        }

    }
}
