<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 8/6/2019
 * Time: 6:39 PM
 */

namespace App\Http\Controllers\Frontend;

use App\Repositories\Common\ProvinceRepository;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class ShbController extends Controller
{
    protected $provinceRepo;

    public function __construct(ProvinceRepository $provinceRepository)
    {
        $this->provinceRepo = $provinceRepository;
    }


    public function index(Request $request)
    {
        $keyword = str_replace("+", " ", $request->k);
        $paramProvince = str_replace("+", " ", $request->p);
        $ip = $request->ip();
        $ua = $request->header('User-Agent');
        $headers = $request->header();
        $sessionId = Session::getId();
        $uri = $_SERVER['REQUEST_URI'];
        $sourceIp = $request->hasHeader('x-forwarded-for') ? $request->header('x-forwarded-for') : '';

        $provinces = $this->provinceRepo->listingAllProvince();
        $districts = $this->provinceRepo->listingAllDistrict();

        $index = rand(0, 9);
        $new = false;
        if (Session::exists('number')) {
            $index = Session::get('number');
        } else {
            $new = true;
            Session::put('number', $index);
        }
        if ($new) {
            save_traffic_log($ip, $ua, 'form', $keyword, json_encode($headers), $sessionId, $sourceIp, $uri);
        }

//        $index = 0;
        return view('frontend.home.formv2')->with([
            'keyword' => $keyword,
            'provinces' => $provinces,
            'districts' => $districts,
            'p' => $paramProvince
        ]);
//        }
    }
}
