<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    public function index(Request $request)
    {
        $k = $request->input('k');
        $trafficId = $request->input('traffic_id');
        $trafficSource = $request->input('traffic_source');
        $p = $request->input('p');
        $ref = $request->input('ref');
        return Redirect::to("https://vncredit.com.vn?k=$k&traffic_id=$trafficId&traffic_source=$trafficSource&p=$p&ref=$ref");
    }

}
