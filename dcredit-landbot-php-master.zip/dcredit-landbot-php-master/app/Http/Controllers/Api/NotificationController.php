<?php
/**
 * Created by PhpStorm.
 * User: nampth
 * Date: 5/13/2020
 * Time: 1:43 PM
 */

namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use App\Models\EcUser;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function loanUpdate(Request $request)
    {
        $authorization = $request->header('Authorization');
        if (!verify_basic_auth($authorization, NOTIFICATION_UN, NOTIFICATION_PW)) {
            return response()->json([
                'code' => ERROR_CODE,
                'msg' => 'Unauthorization'
            ], 401);
        }
        $phone = $request->exists('phone') ? normalize_phone_number($request->input('phone')) : null;
        if (!$phone) {
            return response()->json([
                'code' => ERROR_CODE,
                'msg' => 'Phone is missing'
            ], 403);
        }
        $user = EcUser::with(['metric_data' => function ($q) {
            $q->with('info');
        }])
            ->where('verified', '<>', USER_STATUS_DELETED)
            ->where('phone', $phone)
            ->first();
        if (!$user) {
            return response()->json([
                'code' => ERROR_CODE,
                'msg' => 'user not existed'
            ], 403);
        }
        $subscriber = null;
        foreach ($user->metric_data as $metricData) {
            if ($metricData->info->key == 'subscriber_id') {
                $subscriber = $metricData->value;
            }
        }
        if (!$subscriber) {
            return response()->json([
                'code' => ERROR_CODE,
                'msg' => 'user not subscribe for notification'
            ], 403);
        }
        $title = 'VNCredit - Cập nhật khoản vay';
        $msg = 'Khoản vay của bạn đã được cập nhật. Truy cập ngay VNCredit để xem tiến độ';
        $url = 'https://vncredit.com.vn/loan-process';

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.pushalert.co/rest/v1/send",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => array('title' => $title, 'message' => $msg, 'url' => $url, 'subscriber' => $subscriber),
            CURLOPT_HTTPHEADER => array(
                "Authorization: api_key=246ec0bd68ec59ca4aa9a3da0f83ef5c"
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;
    }
}