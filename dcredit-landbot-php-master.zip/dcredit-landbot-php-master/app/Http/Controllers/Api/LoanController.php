<?php
/**
 * Created by PhpStorm.
 * User: nampth
 * Date: 4/14/2020
 * Time: 9:39 AM
 */

namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LoanController extends Controller
{
    public function reApply(Request $request)
    {
        $phone = normalize_phone_number($request->input('phone'));
        $amount = $request->input('amount');
        $duration = $request->input('duration');
        $ref = $request->input('ref');
        $trafficSource = $request->input('traffic_source');
        $trafficId = $request->input('traffic_id');
        $pubId = $request->input('pub_id');
        if (!$phone) {
            return response()->json([
                'code' => ERROR_CODE,
                'msg' => 'Invalid Phone'
            ]);
        }
        $loanCheck = curl_form("POST", KAL_API_LOAN_CHECK, [
            'phone' => $phone
        ]);

        if (!$loanCheck || !$loanCheck['code'] || intval($loanCheck['code']) != 200) {
            $data = json_decode($loanCheck['data']);

            return response()->json([
                'code' => ERROR_CODE,
                'msg' => 'Loan check Failed',
                'data' => isset($data->data) && isset($data->data->loans) ? $data->data->loans : []
            ]);
        }

        $params = [
            "phone" => $phone,
            "amount" => $amount,
            "duration" => $duration,
            "ref" => $ref,
            "traffic_source" => $trafficSource,
            "traffic_id" => $trafficId,
            "pub_id" => $pubId
        ];
        $newLoan = curl_form("POST", KAL_API_LOAN_REAPPLY, $params);

        if ($newLoan && intval($newLoan['code']) == 200) {
            return response()->json([
                'code' => SUCCESS_CODE,
                'msg' => 'ok'
            ]);
        }
        return response()->json([
            'code' => ERROR_CODE,
            'msg' => 'Reapply Failed',
            'data' => [],
            'post_data' => json_encode($params)
        ]);
    }

    public function appraise(Request $request)
    {
        $phone = normalize_phone_number($request->input('phone'));
        $province = $request->input('province');
        $amount = $request->exists('amount') ? $request->input('amount') : 0;
        $identity = $request->input('identity_id');
        if (!$phone) {
            return response()->json([
                'code' => ERROR_CODE,
                'data' => 'phone invalid'
            ]);
        }
        try {
            $result = curl_form('POST', KAL_APPRAISE, [
                'phone' => $phone,
                'amount' => $amount,
                'province' => $province,
                'identity_id' => $identity
            ]);
            return response()->json([
                'code' => SUCCESS_CODE,
                'data' => json_decode($result['data'])
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'code' => ERROR_CODE,
            ]);
        }
    }

}