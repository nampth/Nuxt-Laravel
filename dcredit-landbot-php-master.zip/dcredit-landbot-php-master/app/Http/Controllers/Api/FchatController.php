<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 3/24/2020
 * Time: 10:28 AM
 */

namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use App\Repositories\Common\LogRepository;
use Illuminate\Http\Request;

class FchatController extends Controller
{
    protected $logRepo;

    public function __construct(LogRepository $logRepository)
    {
        $this->logRepo = $logRepository;
    }

    public function callback3rdParty(Request $request)
    {
        $phone = $request->exists('phone') ? $request->input('phone') : null;
        $duration = $request->exists('duration') ? $request->input('duration') : 12;
        $name = $request->exists('fullname') ? $request->input('fullname') : null;
        $address = $request->exists('current_address') ? $request->input('current_address') : null;
        $identity = $request->exists('identity_id') ? $request->input('identity_id') : null;
        $amount = $request->exists('amount') ? $request->input('amount') : null;
        $ref = $request->exists('ref') ? $request->input('ref') : null;
        $formLevel = $request->exists('form_level') ? $request->input('form_level') : null;
        $trafficSource = $request->exists('traffic_source') ? $request->input('traffic_source') : null;
        $trafficId = $request->exists('traffic_id') ? $request->input('traffic_id') : null;
        $keyword = $request->exists('keyword') ? $request->input('keyword') : null;
        $domain = $request->exists('keyword') ? $request->input('keyword') : null;
        $pubId = $request->exists('keyword') ? $request->input('keyword') : null;
        $province = $request->exists('keyword') ? $request->input('keyword') : null;

        $postData = [
            'form_level' => $formLevel,
            'phone' => $phone,
            'fullname' => $name,
            'identity_id' => $identity,
            'current_address' => $address,
            'amount' => $amount,
            'ref' => $ref,
            'traffic_source' => $trafficSource,
            'traffic_id' => $trafficId,
            'keyword' => $keyword,
            'domain' => $domain,
            'pub_id' => $pubId,
            'province' => $province,
            'duration' => $duration,
            'theme' => 'fchat'
        ];
        $result = curl_form('POST', 'https://webapi.vncredit.com.vn/api/registerec', $postData);
        $this->logRepo->create([
            'action' => 'fchat_callback',
            'phone' => $phone,
            'data' => json_encode($request->all(), JSON_UNESCAPED_UNICODE),
            'response' => json_encode($result, JSON_UNESCAPED_UNICODE),
            'note' => null,
            'session_id' => null,
        ]);

        if ($result['code'] && $result['code'] == 200) {
            $data = json_decode($result['data'], JSON_UNESCAPED_UNICODE);
            return response()->json([
                'code' => $data['code'],
                'message' => $data['result']
            ]);
        } else {
            return response()->json([
                'code' => ERROR_CODE,
                'message' => 'Something went wrong',
                'data' => (is_array($result) && isset($result['data'])) ? json_decode($result['data']) : json_encode($result)
            ]);
        }
    }
}