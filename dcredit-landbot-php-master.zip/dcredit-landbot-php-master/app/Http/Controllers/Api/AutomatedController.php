<?php
/**
 * Created by PhpStorm.
 * User: nampth
 * Date: 4/1/2020
 * Time: 4:47 PM
 */

namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use App\Models\PaydayLoan;
use App\Repositories\Common\PaydayLoanRepository;
use Facebook\WebDriver\Chrome\ChromeOptions;
use Facebook\WebDriver\Remote\DesiredCapabilities;
use Facebook\WebDriver\Remote\RemoteWebDriver;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Laravel\Dusk\Browser;
use Laravel\Dusk\Chrome\ChromeProcess;
use Laravel\Dusk\ElementResolver;

class AutomatedController extends Controller
{
    protected $pdlRepo;

    public function __construct(PaydayLoanRepository $paydayLoanRepository)
    {
        $this->pdlRepo = $paydayLoanRepository;
    }

    public function register(Request $request)
    {
//        try {
        $name = $request->input('name');
        $identity = $request->input('identity_id');
        $phone = normalize_phone_number2($request->input('phone'));
        $email = $request->input('email');
        $password = $request->input('password');
        $url = $request->input('url');
        if (!$phone) {
            return response()->json([
                'code' => ERROR_CODE,
                'data' => 'Invalid Phone'
            ]);
        }
        $pdl = $this->pdlRepo->create([
            'name' => $name,
            'phone' => $phone,
            'data' => json_encode([
                'phone' => $phone,
                'identity' => $identity,
                'email' => $email,
                'password' => $password,
                'url' => $url
            ]),
            'status' => PDL_STATUS_PENDING
        ]);

        $result = curl_form('POST', API_TAMO_OTP, [
                "mobilePhone" => [
                    "number" => $phone
                ]
            ]
        );

        $data = json_decode($result['data']);
        if (intval($result['code']) == 200 && $data) {
            return response()->json([
                'code' => SUCCESS_CODE
            ]);
        } else {
            $pdl->status = PDL_STATUS_ERROR;
            $pdl->save();
            return response()->json([
                'code' => ERROR_CODE,
                'data' => $result['data']
            ]);
        }
//        } catch (\Exception $e) {
//            return response()->json([
//                'code' => ERROR_CODE
//            ]);
//        }
    }

    public function registerOtp(Request $request)
    {
        $phone = normalize_phone_number2($request->input('phone'));

        $otp = $request->input('otp');
        $name = $request->input('name');
        $pdl = PaydayLoan::where('name', $name)->where('phone', $phone)->where('status', PDL_STATUS_PENDING)->first();

        if (!$pdl || !$phone || !$otp || !$name) {
            return response()->json([
                'code' => ERROR_CODE,
                'msg' => 'not existed'
            ]);
        }

        $data = (array)json_decode($pdl->data);
        $data['otp'] = $otp;
        $pdl->data = $data;
        $pdl->save();

        $process = (new ChromeProcess)->toProcess();
        if ($process->isStarted()) {
            $process->stop();
        }
        $process->start();

        $options = (new ChromeOptions)->addArguments([
            '--disable-gpu',
            '--headless',
            '--window-size=375,700',
            '--disable-extensions',
            '--disable-dev-shm-usage',
            '--remote-debugging-port=9222',
            '--no-sandbox'
        ]);
        $capabilities = DesiredCapabilities::chrome()
            ->setCapability(ChromeOptions::CAPABILITY, $options)
            ->setPlatform('Window');
        $driver = retry(5, function () use ($capabilities) {
            return RemoteWebDriver::create('http://localhost:9515', $capabilities, 60000, 60000);
        }, 50);

        $browser = new Browser($driver, new ElementResolver($driver, ''));
        try {
            $browser->visit('http://go.masoffer.net/v2/1EAZw0P2R_hDBvsl6HD1f54CBwEqvyjK_J2Qr_sCZkg?lp=tamovn')
                ->pause(1000)
                ->click('.calculator__button button')
                ->pause(3000)
                ->type('#__layout > div > div.sf-bg-page-bg.layout__inner > div > div.content__inner > div.left > form > fieldset:nth-child(1) > div > label > input[type=text]', $data['identity'])
                ->type('#__layout > div > div.sf-bg-page-bg.layout__inner > div > div.content__inner > div.left > form > fieldset:nth-child(2) > div:nth-child(2) > label > input[type=tel]', $data['phone'])
                ->click('#__layout > div > div.sf-bg-page-bg.layout__inner > div > div.content__inner > div.left > form > fieldset:nth-child(2) > button')
                ->type('#__layout > div > div.sf-bg-page-bg.layout__inner > div > div.content__inner > div.left > form > fieldset:nth-child(2) > div:nth-child(5) > label > input[type=text]', $data['otp'])
                ->type('input[type="email"]', $data['email'])
                ->type('input[type="password"]', $data['password'])
                ->click('#__layout > div > div.sf-bg-page-bg.layout__inner > div > div.content__inner > div.left > form > fieldset:nth-child(3) > button')
                ->pause(3000);

            $browser->driver->takeScreenshot(base_path('tests/Browser/screenshots/logged.png'));
            $browser->quit();
            $process->stop();
            $pdl->status = PDL_STATUS_DONE;
            $pdl->save();
            return response()->json([
                'code' => SUCCESS_CODE
            ]);
        } catch (Exception $exception) {
            $browser->quit();
            $process->stop();
            $pdl->status = PDL_STATUS_ERROR;
            $pdl->save();
            return response()->json([
                'code' => ERROR_CODE
            ]);
            dd($exception);
        }


    }
}
