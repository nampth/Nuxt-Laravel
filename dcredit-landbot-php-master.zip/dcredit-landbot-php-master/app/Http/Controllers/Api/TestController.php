<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 8/9/2019
 * Time: 3:52 PM
 */

namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TestController extends Controller
{
    public function test(Request $request)
    {
        print_r($request->header());
        print_r($request->all());
        return '';
    }
}
