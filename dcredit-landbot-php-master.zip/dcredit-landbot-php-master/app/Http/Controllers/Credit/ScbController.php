<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 8/7/2019
 * Time: 3:28 PM
 */

namespace App\Http\Controllers\Credit;


use App\Http\Controllers\Controller;
use App\Repositories\Common\ProvinceRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class ScbController extends Controller
{
    protected $provinceRepo;

    public function __construct(ProvinceRepository $provinceRepo)
    {
        $this->provinceRepo = $provinceRepo;
    }

    public function index(Request $request)
    {
        $keyword = str_replace("+", " ", $request->k);
        $paramProvince = str_replace("+", " ", $request->p);
        $ip = $request->ip();
        $ua = $request->header('User-Agent');
        $headers = $request->header();
        $sessionId = Session::getId();
        $uri = $_SERVER['REQUEST_URI'];
        $ref = $request->ref;
        $sourceIp = $request->hasHeader('x-forwarded-for') ? $request->header('x-forwarded-for') : '';

        $provinces = $this->provinceRepo->listingAllProvince();
        $districts = $this->provinceRepo->listingAllDistrict();

        $index = rand(0, 9);
        $new = false;
        if (Session::exists('number')) {
            $index = Session::get('number');
        } else {
            $new = true;
            Session::put('number', $index);
            Session::put('ref', $ref);
        }
        if (!Session::exists('ref')) {
            Session::put('ref', $ref);
        }
        if ($new) {
            save_traffic_log($ip, $ua, 'credit_scb', $keyword, json_encode($headers), $sessionId, $sourceIp, $uri);
        }

        return view('credit.scb.index')->with([
            'keyword' => $keyword,
            'provinces' => $provinces,
            'districts' => $districts,
            'p' => $paramProvince
        ]);

        return view('credit.scb.index');
    }

    public function register(Request $request)
    {
        $name = $request->exists('name') ? $request->input('name') : '';
        $phone = $request->exists('phone') ? $request->input('phone') : '';
        $email = $request->exists('email') ? $request->input('email') : '';
        $address = $request->exists('address') ? $request->input('address') : '';
        $income = $request->exists('income') ? $request->input('income') : '';
        $card = $request->exists('card') ? $request->input('card') : '';
        $paper = $request->exists('paper') ? $request->input('paper') : 'data';
        $type = $request->exists('type') ? $request->input('type') : 'data';
        $ref = $request->exists('ref') ? $request->input('ref') : '';

        $postData = [
            'name' => $name,
            'email' => $email,
//            'social_id'=> $email,
            'address' => $address,
            'income' => $income,
            'card' => $card,
            'paper' => $paper,
            'adv' => "NULL",
            'ref' => Session::exists('ref') ? Session::get('ref') : $ref,
            'form_type' => 'credit_scb',
            'session_id' => Session::getId()
        ];

        if ($request->exists('code') && $type == 'data') {
            $app_id = '404291800431097';
            $secret = 'b7431fff93e4047cec5e135095b5a469';
            $version = 'v1.1'; // 'v1.1' for example

            // Exchange authorization code for access token
            $token_exchange_url = 'https://graph.accountkit.com/' . $version . '/access_token?' .
                'grant_type=authorization_code' .
                '&code=' . $request->input('code') . "&access_token=AA|$app_id|$secret";
            $data = do_curl($token_exchange_url);

            $user_id = $data['id'];
            $user_access_token = $data['access_token'];
            $refresh_interval = $data['token_refresh_interval_sec'];

            // Get Account Kit information
            $me_endpoint_url = 'https://graph.accountkit.com/' . $version . '/me?' .
                'access_token=' . $user_access_token;
            $data = do_curl($me_endpoint_url);

            $phone = isset($data['phone']) ? $data['phone']['number'] : '';
            $email = isset($data['email']) ? $data['email']['address'] : '';

            if ($phone) {
                $postData['phone'] = $phone;
                $postData['verified'] = true;

                $result = curl_form('POST', KAL_CREDIT_API, $postData, [], Session::getId());
                return response()->json([
                    'code' => SUCCESS_CODE,
//                    'data' => $result
                ]);
            }
            return response()->json([
                'code' => ERROR_CODE
            ]);
        } else {
            $postData['type'] = $type;
            $postData['phone'] = $phone;
            $postData['verified'] = false;

            $result = curl_form('POST', ($type == 'log' ? KAL_CREDIT_API_LOG : KAL_CREDIT_API), $postData, [], Session::getId());
            return response()->json([
                'code' => SUCCESS_CODE,
                'data' => $result
            ]);
        }


    }
}
