<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 1/17/2020
 * Time: 2:05 PM
 */

namespace App\Http\Requests;


use Illuminate\Foundation\Http\FormRequest;

class FeedbackFormRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'sid' => 'required|string|max:256',
            'feedback_rate' => 'required|numeric|integer',
            'feedback_comment' => 'required',
            'page' => 'required|max:100',
            'note' => 'max:1000',
        ];
    }

    public function attributes()
    {
        return [
            'sid' => 'Session ID',
            'feedback_rate' => 'Feedback rate',
            'feedback_comment' => 'Feedback comment',
            'page' => 'Page',
            'note' => 'note',
        ];
    }
}