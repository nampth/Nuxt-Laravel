<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 3/17/2020
 * Time: 11:35 AM
 */

namespace App\Http\Requests;


use Dotenv\Exception\ValidationException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;

class UpdateInstantRequest extends FormRequest
{
    public function rules()
    {
        return [
            'phone' => 'required|string|max:20',
            'form_level' => 'required|numeric',
            'key' => 'required|string|max:100',
            'value' => 'required|string',
        ];
    }

    public function attributes()
    {
        return [
            'phone' => 'Số điện thoại',
            'form_level' => 'Form Level',
            'key' => 'Tên trường',
            'value' => 'Giá trị',

        ];
    }
}