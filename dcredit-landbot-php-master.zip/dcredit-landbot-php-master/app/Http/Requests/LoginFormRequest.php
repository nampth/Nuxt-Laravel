<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LoginFormRequest extends FormRequest
{

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email_address' => 'required|string|email',
            'otp' => 'required|numeric|digits:6',
        ];
    }

    public function attributes()
    {
        return [
            'email_address' => 'Email',
            'otp' => 'OTP'
        ];
    }
}
