<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RegisterFormRequest extends FormRequest
{

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'phone' => 'required|string|max:20',
            'name' => 'required|string|max:100',
            'identity' => 'required|string|max:20',
            'province' => 'required|string|max:30',
            'amount' => 'required',
            'duration' => 'required',
        ];
    }

    public function attributes()
    {
        return [
            'phone' => 'Số điện thoại',
            'name'=>'Họ và tên',
            'identity'=> 'CMND/CCCD',
            'province'=> 'Thành phố',
            'amount'=> 'Khoản vay',
            'duration'=>'Thời gian vay'
        ];
    }
}
