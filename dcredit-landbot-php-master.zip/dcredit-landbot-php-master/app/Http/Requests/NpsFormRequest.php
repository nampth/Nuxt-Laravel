<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 1/17/2020
 * Time: 2:05 PM
 */

namespace App\Http\Requests;


use Illuminate\Foundation\Http\FormRequest;

class NpsFormRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'sid' => 'required|string|max:256',
            'type' => 'required|string|max:100',
            'feedback_rate' => 'required|numeric|integer',
            'note' => 'max:1000',
        ];
    }

    public function attributes()
    {
        return [
            'sid' => 'Session ID',
            'type' => 'Type',
            'feedback_rate' => 'Feedback rate',
            'note'=> 'Note'
        ];
    }
}