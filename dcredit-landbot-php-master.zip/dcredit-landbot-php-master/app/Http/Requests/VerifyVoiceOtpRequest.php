<?php
/**
 * Created by PhpStorm.
 * User: Nampth
 * Date: 2/27/2020
 * Time: 9:13 AM
 */

namespace App\Http\Requests;


use Illuminate\Foundation\Http\FormRequest;

class VerifyVoiceOtpRequest extends FormRequest
{
    public function rules()
    {
        return [
            'phone' => 'required|string|max:20',
            'code' => 'required|string|max:4|min:4',
        ];
    }

    public function attributes()
    {
        return [
            'phone' => 'Số điện thoại',
            'code' => 'Mã xác thực',
        ];
    }
}