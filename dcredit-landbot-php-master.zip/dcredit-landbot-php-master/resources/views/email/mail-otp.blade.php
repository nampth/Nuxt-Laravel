<!DOCTYPE html>
<html lang="en">
<body data-spy="scroll" data-target="#pb-navbar" data-offset="200" style="background: #dcdcdc">
<table height="36" align="center" valign="middle" border="0" cellpadding="0" cellspacing="0" style="padding: 5em;"
       class="tablet-button" st-button="edit">
    <tbody>
    <tr style="background: #211f22;">
        <td><h1 style=" padding-left:10px; color: white;">
                VNCredit.com.vn</h1></td>
    </tr>
    <tr>
        <td style="padding: 10px; background: white;">Chào bạn</td>
    </tr>
    <tr>
        <td style="padding: 10px; background: white;">Cảm ơn bạn đã tin tưởng và sử dụng dịch vụ của chúng tôi</td>
    </tr>
    <tr>
        <td style="padding: 10px; background: white;">Hãy truy cập vào đường dẫn dưới đây để có thể đăng nhập vào hệ
            thống.
        </td>
    </tr>
    <tr>
        <td width="auto" align="center" valign="middle" height="50" style="background: white">
	       <span style="padding: 10px 20px; margin: 10px;border:1px solid #004cad; background: #ffffff; border-top-left-radius:4px; border-bottom-left-radius:4px;border-top-right-radius:4px; border-bottom-right-radius:4px; background-clip: padding-box;font-size:17px; font-family:Helvetica, arial, sans-serif; text-align:center;  color:#ffffff; font-weight: 300; color: #ffffff; font-weight: 300;">
                <a href="{{ $link }}" target="_blank">Đăng nhập vào VNCredit</a>
	       </span>
        </td>
    </tr>
    <tr>
        <td style="padding: 10px; background: white;">Link truy cập có hiệu lực trong vòng 5 phút. Vui lòng không chia
            sẻ đường dẫn này với bất kỳ ai
        </td>
    </tr>
    <tr>
        <td style="background: #211f22;
    padding: 10px;
    color: white;
    text-align: center;">
            <h3 style="text-transform: uppercase; font-weight: 500; font-size: 17px;">VNCredit.com.vn</h3>
            <p>Địa chỉ: Tòa nhà Ecolife Capitol 58 Tố Hữu, Trung Văn, Từ Liêm, Hà Nội</p>
            <p class="pb_font-14">&copy; 2019 <a href="{{ url('/') }}" style="color: white">VNCredit.vn</a> All Rights
                Reserved.</p>
        </td>
    </tr>
    </tbody>
</table>
</body>
</html>
