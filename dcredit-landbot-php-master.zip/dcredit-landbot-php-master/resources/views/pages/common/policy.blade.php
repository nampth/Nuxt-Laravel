@extends('pages.templates.index')

@section('assets_header')
@endsection

@section('main')
    <div>
        <div class="padding-top-20 padding-bottom-30">
            <div class="container">
                <h2 class="margin-bottom-20 text-center text-white">Điều khoản thu thập và Sử dụng thông tin cá
                    nhân</h2>

                <div class="policy-content bg-white" style="padding: 15px 30px">
                    <p><b>VNCREDIT</b> là một dịch vụ trực tuyến, miễn phí của <b>Công Ty Cổ Phần Kalapa </b>(sau
                        đây
                        gọi tắt là “Công
                        Ty”) cung cấp dịch vụ hỗ trợ người dùng tiếp cận dễ dàng với các dịch vụ tài chính cá nhân của
                        ngân
                        hàng cũng như các nhà cung cấp dịch vụ tài chính khác. Để làm được điều đó, Công Ty cần thu thập
                        và
                        xử lý một số Thông Tin Cá Nhân của bạn. Bằng việc sử dụng <b>VNCREDIT</b> miễn phí, bạn nghiễm
                        nhiên đã
                        đồng ý với các điều khoản về thu thập và sử dụng Thông Tin Cá Nhân dưới đây.</p>
                    <ul class="list-unstyled">
                        <b-media tag="li" class="my-1">
                            <h5 class="mt-0 mb-1">ĐIỀU 1. THU THẬP THÔNG TIN CÁ NHÂN</h5>
                            <div class="mb-0">
                                Công Ty sẽ thu thập địa chỉ IP và các thông tin khác của bạn như: loại trình duyệt, các
                                trang bạn truy cập trong quá trình sử dụng dịch vụ, thông tin về máy tính và thiết bị
                                mạng, ... nhằm mục đích nâng cao trải nghiệm của bạn với dịch vụ. Bên cạnh đó, cùng với
                                việc đăng ký tài khoản miễn phí với <b>VNCREDIT</b>, bạn đồng ý cung cấp và để Công Ty
                                sử dụng
                                các Thông Tin Cá Nhân sau:
                                <ul>
                                    <li>Họ và tên.</li>
                                    <li>Số điện thoại di động.</li>
                                    <li>Số Chứng Minh Nhân Dân/Căn Cước Công Dân.</li>
                                    <li>Các thông tin bắt buộc hoặc không bắt buộc khác trong quá trình đăng ký cũng
                                        như
                                        sử
                                        dụng <b>VNCREDIT</b>.
                                    </li>
                                </ul>
                            </div>
                        </b-media>

                        <b-media tag="li" class="my-1">
                            <h5 class="mt-0 mb-1">ĐIỀU 2. ĐẶT COOKIES</h5>
                            <div class="mb-0">
                                Khi bạn truy cập <b>VNCREDIT</b>, Công Ty (hoặc Bên Thứ Ba được thuê để theo dõi và
                                thống kê
                                hoạt động của website <b>vncredit.com.vn</b>) sẽ đặt một số file dữ liệu nhỏ gọi là
                                cookies lên
                                đĩa cứng hoặc bộ nhớ máy tính của bạn. Một trong số những cookies này có thể tồn tại lâu
                                để thuận tiện cho bạn trong quá trình sử dụng. Công Ty sẽ mã hóa các cookies để đảm bảo
                                tính bảo mật. Bạn có thể cấm cookies trên trình duyệt của mình nhưng điều này có thể sẽ
                                ảnh hưởng đến quá trình sử dụng <b>VNCREDIT</b>.
                            </div>
                        </b-media>

                        <b-media tag="li" class="my-1">

                            <h5 class="mt-0 mb-1">ĐIỀU 3. LƯU TRỮ VÀ BẢO VỆ THÔNG TIN CÁ NHÂN</h5>
                            <div class="mb-0">
                                Công Ty áp dụng các biện pháp vật lý và công nghệ nhằm đảm bảo sự an toàn cho Thông Tin
                                Cá Nhân của bạn, cụ thể:
                                <ul>
                                    <li><b>Biện pháp vật lý</b>: Công Ty lưu trữ và xử lý Thông Tin Cá Nhân của bạn tại
                                        các
                                        máy chủ được bảo vệ nghiêm ngặt theo đúng quy trình của các trung tâm lưu trữ dữ
                                        liệu (data center), bao gồm việc kiểm soát ra vào, camera theo dõi 24/7, hệ
                                        thống cảnh báo xâm nhập.
                                    </li>
                                    <li><b>Biện pháp công nghệ</b>: Hệ thống máy chủ lưu trữ và xử lý của Công Ty được
                                        áp
                                        dụng đầy đủ các biện pháp công nghệ tường lửa, cơ chế chống tấn công từ chối
                                        dịch vụ (DDOS) nhằm ngăn chặn các biện pháp tấn công thông tin từ kẻ xấu. Ngoài
                                        ra, Công Ty cũng áp dụng tiêu chuẩn an toàn SSL (Secure Sockets Layer) khi
                                        truyền tải thông tin giữa trình duyệt của bạn và máy chủ của Công Ty nhằm đảm
                                        bảo các thông tin này không bị truy xuất trái phép trong quá trình trao đổi dữ
                                        liệu giữa thiết bị đầu cuối của bạn tới máy chủ lưu trữ <b>VNCREDIT</b>.
                                    </li>
                                </ul>
                            </div>
                        </b-media>
                        <b-media tag="li" class="my-1">

                            <h5 class="mt-0 mb-1">ĐIỀU 4. SỬ DỤNG THÔNG TIN CÁ NHÂN</h5>
                            <div class="mb-0">
                                Công Ty chỉ sử dụng Thông Tin Cá Nhân của bạn cho các mục đích sau:
                                <ul>
                                    <li>Xác thực danh tính của bạn.
                                    <li>Ký kết và thực hiện thỏa thuận cung cấp dịch vụ.</li>
                                    <li>Giao tiếp với cá nhân về việc ký kết và thực hiện thỏa thuận;</li>
                                    <li>Đánh giá khả năng thanh toán của bạn, xác định điểm tín dụng và đánh giá,
                                        phòng ngừa, quản lý rủi ro.
                                    </li>
                                    <li>Phát hiện và phòng ngừa các trường hợp gian lận, rửa tiền và tài trợ khủng bố;
                                        phòng ngừa việc sử dụng sai mục đích dịch vụ của Công Ty;
                                    </li>
                                    <li>Đưa ra, duy trì, thực hiện một hành động; thu hồi nợ (bao gồm, thu hồi nợ
                                        ngoài phạm vi tòa án) và thực hiện các hành động thu hồi nợ, yêu cầu bồi thường.
                                    </li>
                                    <li>Xử lý các khiếu nại của bạn và tạo ra sổ đăng ký khiếu nại.</li>
                                    <li>Mục đích tiếp thị trực tiếp (ví dụ: liên hệ với bạn qua điện thoại và/hoặc gửi
                                        qua thư điện tử (e-mail) giới thiệu việc giảm giá/thông tin quan trọng khác về
                                        hàng hóa/dịch vụ; chuẩn bị các ưu đãi được gửi trực tiếp đến bạn; tổ chức các sự
                                        kiện tri ân khách hàng; sử dụng cookies; đánh giá và nghiên cứu các nhóm khách
                                        hàng; …).
                                    </li>
                                    <li>Đảm bảo an ninh, bảo vệ tài sản, phòng ngừa và phát hiện hành vi phạm tội hình
                                        sự;
                                    </li>
                                    <li>Nghiên cứu và thống kê; nâng cao chất lượng/hiệu quả cho việc cung cấp dịch vụ
                                        của Công Ty;
                                    </li>
                                    <li>Kiểm soát chất lượng nội dung cuộc gọi, kiểm soát chất lượng dịch vụ và lưu
                                        trữ bằng chứng (về tính chính xác của thông tin được cung cấp; năng lực của nhân
                                        viên; …).
                                    </li>
                                    <li>Tuân thủ nghĩa vụ theo pháp luật hiện hành; cung cấp phản hồi cho các yêu cầu
                                        của các cơ quan nhà nước có thẩm quyền;
                                    </li>
                                    <li>Tạo và duy trì cơ sở dữ liệu Khách Hàng/Khách Hàng tiềm năng.</li>
                                    <li>Xác nhận khả năng được vay của bạn bằng cách gửi các Thông Tin Cá Nhân mà bạn
                                        đã cung cấp cho Công Ty tới các đối tác cung cấp dịch vụ tài chính của <b>VNCREDIT</b>.
                                    </li>
                                </ul>
                                Công Ty cam kết sẽ không bán, trao đổi hoặc tiết lộ Thông Tin Cá Nhân của bạn cho bất kỳ
                                một Bên Thứ Ba nào không liên quan tới các mục đích kể trên.
                            </div>
                        </b-media>
                        <b-media tag="li" class="my-1">

                            <h5 class="mt-0 mb-1">ĐIỀU 5. NGƯỜI NHẬN THÔNG TIN CÁ NHÂN</h5>
                            <div class="mb-0">
                                Trong từng trường hợp cụ thể, Thông Tin Cá Nhân của bạn có thể được tiết lộ cho những
                                người nhận sau đây:
                                <ul>
                                    <li>Nhân viên và cán bộ Công Ty thuộc diện "cần-phải-biết" các thông tin ấy.</li>
                                    <li>Các nhà cung cấp dịch vụ mà cung cấp một số dịch vụ cụ thể cho Công Ty (ví dụ:
                                        dịch vụ CNTT; lưu trữ Dữ Liệu Cá Nhân trên máy chủ; dịch vụ thu nợ; dịch vụ tiếp
                                        thị; dịch vụ phòng chống gian lận, dịch vụ phòng chống rửa tiền và phòng chống
                                        tài trợ khủng bố; dịch vụ kế toán, …).
                                    </li>
                                    <li>Các cơ quan/cán bộ, công chức nhà nước có thẩm quyền (ví dụ: cảnh sát, tòa án,
                                        nhân viên chấp hành (ở tòa án), cơ quan thực hiện quyền công tố (viện kiểm sát),
                                        …).
                                    </li>
                                    <li>Người nhận, mà hoạt động trong lĩnh vực thông tin tín dụng và/hoặc thu nợ (ví
                                        dụ: nhà cung cấp dịch vụ thu hồi nợ, tổ chức tín dụng, …).
                                    </li>
                                    <li>Các công ty liên quan đến cùng một nhóm công ty (sau đây gọi tắt là “Nhóm Công
                                        Ty”) như Công Ty.
                                    </li>
                                    <li>Người nhận khác, nếu phù hợp với mục sử dụng Thông Tin Cá Nhân.</li>
                                </ul>
                                Ngoài ra, xử lý Thông Tin Cá Nhân chủ yếu được thực hiện trên lãnh thổ Việt Nam. Tuy
                                nhiên, khi tiến hành một số hoạt động xử lý, Thông Tin Cá Nhân có thể được truyền tải ra
                                bên ngoài Việt Nam (ví dụ: khi sử dụng các nhà cung cấp dịch vụ ở bên ngoài Việt Nam,
                                hoặc khi truyền tải Thông Tin Cá Nhân cho Nhóm Công Ty, …). Khi truyền tải Thông Tin Cá
                                Nhân ra bên ngoài Việt Nam, Công Ty sẽ đảm bảo tuân thủ luật pháp hiện hành.
                            </div>
                        </b-media>
                        <b-media tag="li" class="my-1">

                            <h5 class="mt-0 mb-1">ĐIỀU 6. THAY ĐỔI THÔNG TIN CÁ NHÂN VÀ KHÓA TÀI KHOẢN</h5>
                            <div class="mb-0">
                                Bạn có thể thay đổi Thông Tin Cá Nhân của mình bất cứ lúc nào bằng cách sử dụng chức
                                năng tương ứng. Bên cạnh đó, <b>VNCREDIT</b> cũng cho phép bạn khoá tài khoản khi không
                                có nhu
                                cầu sử dụng nữa.
                                Một khi tài khoản đã được khoá, Công Ty sẽ ngừng cung cấp Thông Tin Cá Nhân của bạn cho
                                các tổ chức tài chính, cũng như ngừng mọi liên hệ với bạn để thông báo tình trạng khoản
                                vay hay giới thiệu các mời vay mới. Tuy vậy, tất cả các dữ liệu đã được cung cấp cùng
                                với lịch sử hoạt động của bạn vẫn được lưu trữ và bảo mật trên hệ thống <b>VNCREDIT</b>
                                để có
                                thể tiến hành đối soát khi cần thiết.
                                Nếu sau khi đã khoá tài khoản mà bạn lại có nhu cầu tiếp tục sử dụng <b>VNCREDIT</b>,
                                chỉ cần
                                đăng nhập với email và mật khẩu đang sử dụng, thì tài khoản của bạn sẽ ngay lập tức được
                                kích hoạt trở lại với toàn bộ dữ liệu được giữ nguyên vẹn.
                            </div>
                        </b-media>
                        <b-media tag="li" class="my-1">
                            <h5 class="mt-0 mb-1">ĐIỀU 7. KHÔNG ĐẢM BẢO VÀ MIỄN TRÁCH NHIỆM</h5>
                            <div class="mb-0">
                                Mặc dù Công Ty cam kết dùng hết các biện pháp và chuẩn mực an ninh trong khả năng có thể
                                để đảm bảo cho sự an toàn Thông Tin Cá Nhân của bạn nhưng Công Ty không chịu bất kỳ
                                trách nhiệm pháp lý nào với việc rò rỉ các thông tin này.
                            </div>
                        </b-media>
                        <b-media tag="li" class="my-1">
                            <h5 class="mt-0 mb-1">ĐIỀU 8. QUYỀN TỪ CHỐI CUNG CẤP DỊCH VỤ</h5>
                            <div class="mb-0">
                                Trong mọi trường hợp, Công Ty có quyền đơn phương từ chối cung cấp dịch vụ tạm thời hoặc
                                vĩnh viễn với các Khách Hàng thực hiện hoặc bị nghi vấn có thực hiện một trong các hành
                                vi sau:
                                <ul>
                                    <li>Đăng ký và làm hồ sơ vay với thông tin đăng ký của hai người khác nhau.</li>
                                    <li>Sử dụng thông tin giả mạo để đăng ký và làm hồ sơ vay.</li>
                                    <li>Có dấu hiệu thu phí của người làm hồ sơ vay mà chưa được sự đồng ý cho phép của
                                        Công
                                        Ty
                                    </li>
                                </ul>
                            </div>
                        </b-media>
                        <b-media tag="li" class="my-1">

                            <h5 class="mt-0 mb-1">ĐIỀU 9. GIẢI QUYẾT TRANH CHẤP VÀ NỘP ĐƠN KHIẾU NẠI</h5>
                            <div class="mb-0">
                                Công Ty mong muốn giải quyết mọi tranh chấp trên tinh thần thiện chí và hy vọng rằng bạn
                                sẽ liên hệ với Công Ty trước tiên nếu bạn cho rằng việc thu thập và sử dụng Thông Tin Cá
                                Nhân không tuân thủ pháp luật hiện hành về bảo vệ Dữ Liệu Cá Nhân.
                            </div>
                        </b-media>
                        <b-media tag="li" class="my-1">
                            <h5 class="mt-0 mb-1">ĐIỀU 10. ĐỒNG Ý VÀ CHO PHÉP</h5>
                            <div class="mb-0">
                                Bằng cách đăng ký sử dụng dịch vụ và/hoặc sử dụng <b>VNCREDIT</b>, bạn thừa nhận và đồng
                                ý
                                rằng:
                                <ul>
                                    <li>Bạn đã đọc và hiểu rõ toàn bộ Điều Khoản Thu Thập Và Sử Dụng Thông Tin Cá Nhân
                                        này.
                                    </li>
                                    <li>Thông Tin Cá Nhân của bạn sẽ được thu thập, sử dụng hoặc bằng cách khác xử lý
                                        theo cách thức được mô tả như trên.
                                    </li>
                                    <li>Bằng cách đăng ký và/hoặc sử dụng dịch vụ, bạn cho phép Công Ty thu thập tất cả
                                        các Thông Tin Cá Nhân cần thiết từ bạn và bất kỳ Bên Thứ Ba nào thay mặt bạn.
                                    </li>
                                    <li>Nếu bạn vẫn chưa hiểu toàn bộ hoặc một phần của Điều Khoản Thu Thập Và Sử Dụng
                                        Thông Tin Cá Nhân này và/hoặc không đồng ý với cách thức thu thập, sử dụng Thông
                                        Tin Cá Nhân được mô tả tại đây, bạn có thể không đăng ký và/hoặc sử dụng dịch
                                        vụ.
                                    </li>
                                </ul>
                            </div>
                        </b-media>
                        <b-media tag="li" class="my-1">
                            <h5 class="mt-0 mb-1">ĐIỀU 11. CÁC ĐIỀU KHOẢN VÀ ĐIỀU KIỆN KHÁC</h5>
                            <div class="mb-0">
                                <ul>
                                    <li>Công Ty có thể đơn phương sửa đổi Điều Khoản Thu Thập Và Sử Dụng Thông Tin Cá
                                        Nhân vào bất cứ lúc nào. Công Ty khuyên bạn nên xem kỹ Điều Khoản Thu Thập Và Sử
                                        Dụng Thông Tin Cá Nhân này định kỳ để có thông tin mới nhất. Thay đổi đối với
                                        Điều Khoản Thu Thập Và Sử Dụng Thông Tin Cá Nhân này có hiệu lực kể từ ngày được
                                        tải lên các website/ứng dụng của Công Ty. Việc sửa đổi có hiệu lực khi áp dụng
                                        trừ khi Công Ty xác định một ngày có hiệu lực sau đó.
                                    </li>
                                    <li>Nếu Công Ty có thay đổi quan trọng đối với Điều Khoản Thu Thập Và Sử Dụng Thông
                                        Tin Cá Nhân này, Công Ty sẽ đăng tải các thay đổi này lên website/ứng dụng Công
                                        Ty và sẽ nỗ lực hết sức để thông báo cho bạn bất kỳ thay đổi quan trọng nào.
                                        Bằng việc tiếp tục sử dụng dịch vụ của Công Ty, bạn chấp thuận và đồng ý các
                                        điều khoản được cập nhật của Điều Khoản Thu Thập Và Sử Dụng Thông Tin Cá Nhân
                                        này.
                                    </li>
                                    <li>Nếu bạn có bất kỳ thắc mắc nào khác về việc thu thập, sử dụng Thông Tin Cá Nhân
                                        được thực hiện bởi Công Ty, bạn có thể gửi các thắc mắc này cho Công Ty.
                                    </li>
                                </ul>
                            </div>
                        </b-media>
                    </ul>

                </div>
            </div>
        </div>
    </div>
@endsection

@section('assets_footer')
    <script src="{{asset('js/policy.js')}}"></script>
@endsection