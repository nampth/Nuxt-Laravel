@extends('pages.templates.index')

@section('assets_header')
    <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <script type="text/javascript" src="{{asset('js/bootstrap.min.js')}}"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css"/>
@endsection

@section('main')
    <div class="toast text-white" :class="toastStatus == 'success' ? 'bg-success' : 'bg-danger'" data-delay="3000">
        <div class="toast-header text-white" :class="toastStatus == 'success' ? 'bg-success' : 'bg-danger'">
            @{{ toastHeader }}
        </div>
        <div class="toast-body">
            @{{ toastMsg }}
        </div>
    </div>
    <div class="row row-item margin-top-30"><!---->
        <div class="col-sm-12 col-md-12 form-wrapper">
            <div class="register-form bg-white">
                <div></div>
                <div class="form-inner">
                    <h2 class="margin-10 text-center text-uppercase">Tiến độ duyệt vay</h2>
                    <p class="margin-bottom-10 text-center"> Cảm ơn bạn đã đăng ký vay tại hệ thống <b
                                class="text-success text-uppercase font-weight-bold">Vncredit</b></p>

                </div>
            </div>
        </div>
    </div>
@endsection

@section('assets_footer')
    <script src="{{asset('js/loan-process.js')}}"></script>
@endsection