@extends('pages.templates.index')

@section('assets_header')
@endsection

@section('main')
    <div class="row row-item"><!---->
        <div class="col-sm-12 col-md-12 form-wrapper">
            <div class="register-form bg-white">
                <div></div>
                <div class="form-inner">
                    <h2 class="text-center">Thông tin cá nhân </h2>
                    <template v-show="userinfo && userinfo.metric_data">
                        <div class="row padding-top-10 padding-bottom-10" v-for="data in userinfo.metric_data"
                             v-if="allowArray.indexOf(data.info.key) >= 0 ">
                            <div class="col text-left">
                                <label class="label-bold label-sm" style="text-transform: none">
                                    @{{ data.info.label }}
                                </label>
                            </div>
                            <div class="col text-right">
                                @{{ data.value }}
                            </div>
                        </div>
                    </template>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('assets_footer')
    <script src="{{asset('js/userinfo.js')}}"></script>
@endsection