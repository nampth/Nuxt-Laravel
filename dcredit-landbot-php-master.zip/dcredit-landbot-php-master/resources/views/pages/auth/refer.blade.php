@extends('pages.templates.index')

@section('assets_header')
    <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <script type="text/javascript" src="{{asset('js/bootstrap.min.js')}}"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css"/>
@endsection

@section('main')
    <div class="toast text-white" :class="toastStatus == 'success' ? 'bg-success' : 'bg-danger'" data-delay="3000">
        <div class="toast-header text-white" :class="toastStatus == 'success' ? 'bg-success' : 'bg-danger'">
            @{{ toastHeader }}
        </div>
        <div class="toast-body">
            @{{ toastMsg }}
        </div>
    </div>
    <div class="row row-item margin-top-30"><!---->
        <div class="col-sm-12 col-md-12 form-wrapper">
            <div class="register-form bg-white">
                <div></div>
                <div class="form-inner">
                    <h2 class="margin-10 text-center text-uppercase">Bổ sung thông tin</h2>
                    <p class="margin-bottom-10 text-center"> Cảm ơn bạn đã đăng ký vay tại hệ thống <b
                                class="text-success text-uppercase font-weight-bold">Vncredit</b></p>
                    <p class="text-center">Bạn vui lòng bổ sung thông tin để tăng khả năng được duyệt
                        vay</p>
                    <div>
                        <form class="register-form" @submit.stop.prevent="onSubmit"
                              ref="form">

                            <div class="row">
                                <div class="col text-center">
                                    <h5 class="label-bold">Khoản phải trả hàng tháng dự kiến</h5>
                                    <p class="dti-value">@{{ dtiComputing() }}đ</p>
                                    <p class="small-text text-center notes-text">
                                        <strong><u>*Thông tin bạn cần lưu ý:</u>
                                            <br>
                                        </strong><br>
                                        <small>Kết quả tính toán này chỉ mang tính chất tham khảo và có
                                            thể sai lệch nhỏ so với kết
                                            quả tính toán thực tế dựa theo hồ sơ tín dụng cá nhân của
                                            riêng bạn.
                                        </small>
                                    </p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-md-6 col-lg-6 padding-top-15">
                                    <div class="form-group">
                                        <label class="label-bold" for="Current Address">Địa chỉ chi tiết</label>
                                        <input type="text" class="form-control" v-model="form.current_detail"
                                               aria-describedby="emailHelp">
                                        <p class="text-danger error-msg"
                                           v-show="form.current_detail.length == 0 && isSubmiting ">
                                            <small>
                                                Vui lòng nhập địa chỉ
                                            </small>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6 col-lg-6 padding-top-15">
                                    <label class="label-bold" for="Gender">Giới tính</label>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="exampleRadios"
                                               v-model="form.sex"
                                               id="exampleRadios1" value="Nam" checked>
                                        <label class="form-check-label" for="exampleRadios1">
                                            Nam
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="exampleRadios"
                                               v-model="form.sex"
                                               id="exampleRadios2" value="Nữ">
                                        <label class="form-check-label" for="exampleRadios2">
                                            Nữ
                                        </label>
                                    </div>
                                    <p class="text-danger error-msg"
                                       v-show="form.sex.length == 0 && isSubmiting">
                                        <small>
                                            Vui lòng nhập giới tính
                                        </small>
                                    </p>
                                </div>
                            </div>

                            <div class="row padding-top-15">
                                <div class="col-sm-12 col-md-6 col-lg-6 padding-top-15">
                                    <label class="label-bold" for="Date of birth">Ngày/Tháng/Năm sinh:</label>
                                    <input class="form-control dob-datepicker" ref="dobPicker"
                                           v-model="form.full_date_of_birth">
                                    <p class="text-danger error-msg"
                                       v-if="form.full_date_of_birth.length == 0 && isSubmiting">
                                        <small>Vui lòng chọn sinh của bạn.</small>
                                    </p>
                                </div>
                                <div class="col-sm-12 col-md-6 col-lg-6 padding-top-15">
                                    <label class="label-bold" for="Date of birth">Ngày cấp CMND/CCCD:</label>
                                    <input class="form-control identity-datepicker" ref="identityPicker"
                                           v-model="form.full_identity_date">
                                    <p class="text-danger error-msg" v-if="!form.full_identity_date && isSubmiting">
                                        <small>Vui lòng chọn ngày cấp CMND/CCCD</small>
                                    </p>
                                </div>
                            </div>
                            <div class="row padding-top-15">
                                <div class="col-sm-12 col-md-6 col-lg-6">
                                    <label class="label-bold" for="Date of birth">Nơi cấp CMND/CCCD:</label>
                                    <select v-model="form.identity_location" class="form-control">
                                        <option value="">--Chọn nơi cấp--</option>
                                        <option value="Cục CSĐKQLCT&DLQGVDC">Cục CSĐKQLCT&DLQGVDC</option>
                                        <option value="Cục CSQLHC về TTXH">Cục CSQLHC về TTXH</option>
                                        <option value="Hà Nội">Hà Nội
                                        </option>
                                        <option value="Hồ Chí Minh">Hồ Chí Minh
                                        </option>
                                        <option value="Đồng Nai">Đồng Nai
                                        </option>
                                        <option value="An Giang">An Giang
                                        </option>
                                        <option value="Bà Rịa - Vũng Tàu">Bà Rịa - Vũng Tàu
                                        </option>
                                        <option value="Bạc Liêu">Bạc Liêu
                                        </option>
                                        <option value="Bắc Giang">Bắc Giang
                                        </option>
                                        <option value="Bắc Kạn">Bắc Kạn
                                        </option>
                                        <option value="Bắc Ninh">Bắc Ninh
                                        </option>
                                        <option value="Bến Tre">Bến Tre
                                        </option>
                                        <option value="Bình Dương">Bình Dương
                                        </option>
                                        <option value="Bình Định">Bình Định
                                        </option>
                                        <option value="Bình Phước">Bình Phước
                                        </option>
                                        <option value="Bình Thuận">Bình Thuận
                                        </option>
                                        <option value="Cà Mau">Cà Mau
                                        </option>
                                        <option value="Cao Bằng">Cao Bằng
                                        </option>
                                        <option value="Cần Thơ">Cần Thơ
                                        </option>
                                        <option value="Đà Nẵng">Đà Nẵng
                                        </option>
                                        <option value="Đắk Lắk">Đắk Lắk
                                        </option>
                                        <option value="Đắk Nông">Đắk Nông
                                        </option>
                                        <option value="Điện Biên">Điện Biên
                                        </option>
                                        <option value="Đồng Tháp">Đồng Tháp
                                        </option>
                                        <option value="Gia Lai">Gia Lai
                                        </option>
                                        <option value="Hà Giang">Hà Giang
                                        </option>
                                        <option value="Hà Nam">Hà Nam
                                        </option>
                                        <option value="Hà Tĩnh">Hà Tĩnh
                                        </option>
                                        <option value="Hải Dương">Hải Dương
                                        </option>
                                        <option value="Hải Phòng">Hải Phòng
                                        </option>
                                        <option value="Hậu Giang">Hậu Giang
                                        </option>
                                        <option value="Hoà Bình">Hoà Bình
                                        </option>
                                        <option value="Hưng Yên">Hưng Yên
                                        </option>
                                        <option value="Khánh Hòa">Khánh Hòa
                                        </option>
                                        <option value="Kiên Giang">Kiên Giang
                                        </option>
                                        <option value="Kon Tum">Kon Tum
                                        </option>
                                        <option value="Lai Châu">Lai Châu
                                        </option>
                                        <option value="Lạng Sơn">Lạng Sơn
                                        </option>
                                        <option value="Lào Cai">Lào Cai
                                        </option>
                                        <option value="Lâm Đồng">Lâm Đồng
                                        </option>
                                        <option value="Long An">Long An
                                        </option>
                                        <option value="Nam Định">Nam Định
                                        </option>
                                        <option value="Nghệ An">Nghệ An
                                        </option>
                                        <option value="Ninh Bình">Ninh Bình
                                        </option>
                                        <option value="Ninh Thuận">Ninh Thuận
                                        </option>
                                        <option value="Phú Thọ">Phú Thọ
                                        </option>
                                        <option value="Phú Yên">Phú Yên
                                        </option>
                                        <option value="Quảng Bình">Quảng Bình
                                        </option>
                                        <option value="Quảng Nam">Quảng Nam
                                        </option>
                                        <option value="Quảng Ngãi">Quảng Ngãi
                                        </option>
                                        <option value="Quảng Ninh">Quảng Ninh
                                        </option>
                                        <option value="Quảng Trị">Quảng Trị
                                        </option>
                                        <option value="Sóc Trăng">Sóc Trăng
                                        </option>
                                        <option value="Sơn La">Sơn La
                                        </option>
                                        <option value="Tây Ninh">Tây Ninh
                                        </option>
                                        <option value="Thái Bình">Thái Bình
                                        </option>
                                        <option value="Thái Nguyên">Thái Nguyên
                                        </option>
                                        <option value="Thanh Hóa">Thanh Hóa
                                        </option>
                                        <option value="Thừa Thiên Huế">Thừa Thiên Huế
                                        </option>
                                        <option value="Tiền Giang">Tiền Giang
                                        </option>
                                        <option value="Trà Vinh">Trà Vinh
                                        </option>
                                        <option value="Tuyên Quang">Tuyên Quang
                                        </option>
                                        <option value="Vĩnh Long">Vĩnh Long
                                        </option>
                                        <option value="Vĩnh Phúc">Vĩnh Phúc
                                        </option>
                                        <option value="Yên Bái">Yên Bái
                                        </option>
                                    </select>
                                    <p class="text-danger error-msg" v-if="!form.identity_location && isSubmiting">
                                        <small>Vui lòng chọn nơi cấp CMND/CCCD</small>
                                    </p>
                                </div>
                            </div>
                            <div class="row padding-top-15" v-if="!form.state">
                                <div class="col-sm-12 text-center">
                                    <button type="submit" size="lg" class="btn btn-base btn-radius"
                                            style="min-width: 200px" type="submit"
                                            :disabled="isLoading">
                                        <div class="spinner-border spinner-border-sm" role="status" v-show="isLoading">
                                            <span class="sr-only">Loading...</span>
                                        </div>
                                        Cập nhật
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('assets_footer')
    <script src="{{asset('js/refer.js')}}"></script>
@endsection