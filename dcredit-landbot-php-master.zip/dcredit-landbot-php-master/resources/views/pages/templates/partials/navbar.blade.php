<div class="nav-bar-wrapper">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light top-nav">
            <a class="navbar-brand padding-left-10"
               href="{{ !$token ?  route('frontend.home') : route('frontend.auth.home') }}">VNCredit</a>
            <a class="text-white" href="tel: 02471012468" style="font-size: 1.1em;">0247 101 2468</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02"
                    aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                <ul class="navbar-nav ml-auto">
                    @if(!$token)
                        <li class="nav-item"><a href="{{ route('frontend.home') }}"
                                                class="nav-link nuxt-link-exact-active nuxt-link-active">Trang
                                chủ</a></li>
                    @else
                        <li class="nav-item"><a href="{{ route('frontend.auth.home') }}"
                                                class="nav-link nuxt-link-exact-active nuxt-link-active">Trang
                                chủ</a></li>
                    @endif
                    <li class="nav-item"><a href="http://bit.ly/vncredit_app" rel="noreferrer" target="_blank"
                                            class="nav-link">Tải
                            ứng
                            dụng</a></li>
                    <li class="nav-item"><a href="https://vncredit.com.vn/tai-chinh" rel="noreferrer" target="_blank"
                                            class="nav-link">Thông tin tài chính</a></li>
                    <li class="nav-item"><a href="https://vncredit.com.vn/hoi-dap" rel="noreferrer" target="_blank"
                                            class="nav-link">Hỏi
                            đáp</a></li>
                    <li class="nav-item"><a href="https://vncredit.com.vn/faq" rel="noreferrer" target="_blank"
                                            class="nav-link">FAQ</a></li>
                    <li class="nav-item"><a href="/policy" class="nav-link">
                            Điều khoản
                        </a></li>
                    @if( ! $token)
                        <li class="nav-item">
                            <button type="button" class="btn btn btn-login btn-radius btn-secondary btn-lg">
                                Đăng nhập
                            </button>
                        </li>
                    @else
                        <li class="nav-item">
                            <a href="{{ route('frontend.auth.logout') }}"
                               class="btn btn-primary btn-sm btn-radius btn-secondary btn-lg">
                                Đăng xuất
                            </a>
                        </li>
                    @endif
                </ul>

            </div>
        </nav>
    </div>
</div>