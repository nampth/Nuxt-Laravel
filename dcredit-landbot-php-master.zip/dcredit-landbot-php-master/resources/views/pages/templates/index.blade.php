<!doctype html>
<html data-n-head-ssr data-n-head="" lang="vi">
<head data-n-head="">
    <title data-n-head="true">VNCREDIT - Vay tín chấp toàn quốc</title>
    <meta data-n-head="true" charset="utf-8">
    <meta data-n-head="true" name="viewport" content="width=device-width, initial-scale=1">
    <meta data-n-head="true" data-hid="description" name="description" content="Duyệt vay siêu tốc">
    <meta id="site_meta" data-url="{{ env('APP_URL') }}">
    <meta id="api_meta" data-url="{{ env('APP_URL') }}/api/">
    <link data-n-head="true" rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <script rel="preload" src="{{asset('js/jquery-3.4.1.min.js')}}"></script>
    <script rel="preload" src="{{asset('js/popper.min.js')}}"></script>
    <script rel="preload" src="{{asset('js/bootstrap.min.js')}}"></script>
    <script rel="preload" src="{{asset('js/vue.js')}}"></script>
    @yield('assets_header')
</head>
<body data-n-head="">
<div id="app" color="#000000"><!----><!---->
    @include('pages.templates.partials.third-party')
    @include('pages.templates.partials.navbar')
    <div class="top-intro">
        <div class="container">
            @yield('main')
        </div>
    </div>
    @include('pages.templates.partials.footer-section')
</div>
@yield('assets_footer')
</body>
</html>