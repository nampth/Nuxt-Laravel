<div class="modal fade" id="otp-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Xác nhận đăng ký khoản vay</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Bạn vui lòng nhập 4 chữ số đã nhận trong cuộc gọi để xác thực đăng ký khoản vay.</p>
                <div class="form-group">
                    <label for="otp">OTP</label>
                    <input type="number" class="form-control" v-model="form.code" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy bỏ</button>
                <button type="button" class="btn btn-primary" @click="submitForm"
                        v-html="isLoading ? 'Đang xác nhận' : 'Xác nhận'">
                </button>
            </div>
        </div>
    </div>
</div>