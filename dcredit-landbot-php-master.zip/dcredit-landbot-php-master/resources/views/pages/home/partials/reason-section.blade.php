<div class="reason-section">
    <div class="container"><h2 class="text-center text-uppercase margin-bottom-30">Tại sao chọn
            <span
                    class="text-success">VNCredit</span></h2>
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-3">
                <div class="intro-wrapper reason-wrapper">
                    <div class="img-wrapper"><img src="{{ asset('images/reason1.svg')}}" alt="card">
                    </div>
                    <div class="content-wrapper text-center padding-left-10"><h5>Cơ hội giải ngân
                            cao</h5>
                        <p class="text-center"> Chỉ với vài thông tin cơ bản, VNCREDIT
                            sẽ
                            giúp bạn tìm
                            được gói vay với khả năng giải ngân cao</p></div>
                </div>
            </div>
            <div class="col-sm-12 col-md-6 col-lg-3">
                <div class="intro-wrapper reason-wrapper">
                    <div class="img-wrapper"><img src="{{ asset('images/reason2.svg')}}" alt="card">
                    </div>
                    <div class="content-wrapper text-center padding-left-10"><h5>Tư vấn miến phí</h5>
                        <p class="text-center"> VNCREDIT cam kết hỗ trợ bạn miễn phí đến khi tìm được khoản vay phù
                            hợp! </p></div>
                </div>
            </div>
            <div class="col-sm-12 col-md-6 col-lg-3">
                <div class="intro-wrapper reason-wrapper">
                    <div class="img-wrapper"><img src="{{ asset('images/reason3.svg')}}" alt="card">
                    </div>
                    <div class="content-wrapper text-center padding-left-10"><h5>Xét duyệt nhanh
                            chóng</h5>
                        <p class="text-center"> Bạn sẽ nhận được thông báo tình trạng hồ sơ chỉ trong vòng 3 phút.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-6 col-lg-3">
                <div class="intro-wrapper reason-wrapper">
                    <div class="img-wrapper"><img src="{{ asset('images/reason4.svg')}}" alt="card">
                    </div>
                    <div class="content-wrapper text-center padding-left-10"><h5>Đa dạng gói vay</h5>
                        <p class="text-center"> VNCREDIT liên kết cùng các đối tác tin cậy, hỗ trợ gói vay lên tới 80
                            triệu
                            đồng tuỳ vào
                            hồ sơ của khách hàng.</p></div>
                </div>
            </div>
        </div>
        <div class="row text-center margin-top-20">
            <div class="col">
                <button type="button" class="btn btn-cta btn-primary">Đăng ký vay</button>
            </div>
        </div>
    </div>
</div>