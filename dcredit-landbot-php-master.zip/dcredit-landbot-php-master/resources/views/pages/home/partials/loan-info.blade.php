<div class="loan-info">
    <div class="container">
        <div class="row margin-bottom-30">
            <div class="col">
                <h2 class="margin-top-70 text-center">Thông tin khoản vay</h2>
                <p class="text-center">Thông tin một số khoản vay <span class="text-success"><b>VNCredit</b></span> đang
                    cung cấp.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-3 margin-bottom-15">
                <div class="pb_pricing_v1 padding-15 border-gray loan-info-item">
                    <h5 class="text-center padding-top-10 padding-bottom-10">
                        Vay theo hợp đồng dịch vụ (điện, nước...)</h5>
                    <div class="pb_font-15">
                        <ul class="loan-info">
                            <li>10 - 50 triệu</li>
                            <li>Thời gian vay 6 - 60 tháng</li>
                            <li>Lãi suất chỉ từ 2.0% và tối đa 3.5% / tháng</li>
                            <li>APR chỉ từ 24% và tối đa 42% / năm</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3 margin-bottom-15">
                <div class="pb_pricing_v1 padding-15 border-gray loan-info-item">
                    <h5 class="text-center padding-top-10 padding-bottom-10">Vay theo lương</h5>
                    <div class="pb_font-15">
                        <ul class="loan-info">
                            <li>10 - 90 triệu</li>
                            <li>Thời gian vay 6 - 60 tháng</li>
                            <li>Lãi suất chỉ từ 1.5% và tối đa 3.0% / tháng</li>
                            <li>APR chỉ từ 18% và tối đa 36% / năm</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3 margin-bottom-15">
                <div class="pb_pricing_v1 padding-15 border-gray loan-info-item"><h5
                            class="text-center padding-top-10 padding-bottom-10">
                        Vay theo sao kê tài khoản ngân hàng</h5>
                    <div class="pb_font-15">
                        <ul class="loan-info">
                            <li>10 - 50 triệu</li>
                            <li>Thời gian vay 6 - 60 tháng</li>
                            <li>Lãi suất chỉ từ 2.0% và tối đa 3.5% / tháng</li>
                            <li>APR chỉ từ 24% và tối đa 42% / năm</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3 margin-bottom-15">
                <div class="pb_pricing_v1 padding-15 border-gray loan-info-item">
                    <h5 class="text-center padding-top-10 padding-bottom-10">Vay theo HĐ vay cũ</h5>
                    <div class="pb_font-15">
                        <ul class="loan-info">
                            <li>10 - 50 triệu</li>
                            <li>Thời gian vay 6 - 36 tháng</li>
                            <li>Lãi suất chỉ từ 3.0% và tối đa 4.5% / tháng</li>
                            <li>APR chỉ từ 36% và tối đa 54% / năm</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>