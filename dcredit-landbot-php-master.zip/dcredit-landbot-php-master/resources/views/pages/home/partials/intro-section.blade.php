<div class="intro-section bg-gradient">
    <div class="bg-white">
        <div class="container">
            <h2 class="text-center text-uppercase">Điều kiện duyệt vay</h2>
            <p class="text-center">Chỉ với 2 điều kiện cực đơn giản</p>
            <div class="row margin-top-30">
                <div class="col-md-6 col-sm-12 col-xs-12 text-center margin-top-90">
                    <div class="intro-wrapper">
                        <div class="img-wrapper">
                            <img src="{{ asset('images/card-min.png') }}"
                                 alt="card">
                        </div>
                        <div class="content-wrapper text-left padding-left-10"><h5>Lương chuyển
                                khoản</h5>
                            <p> Khách hàng có lương chuyển khoản ngân hàng.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 col-xs-12 margin-top-90 ">
                    <div class="intro-wrapper padding-bottom-10">
                        <div class="img-wrapper"><img src="{{ asset('images/20-min.png')}}"
                                                      alt="age">
                        </div>
                        <div class="content-wrapper text-left padding-left-10"><h5>Độ tuổi</h5>
                            <p>Khách hàng là công dân Việt Nam, trong độ tuổi từ 20 đến 60 tuổi.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>