<div class="loan-condition margin-top-70">
    <div class="container"><h2 class="text-center text-uppercase margin-bottom-30">Hồ sơ &amp; thủ tục</h2>
        <div class="row">
            <div class="col-md-6 col-sm-12"><img src="{{ asset('images/success.jpg')}}" alt="success"></div>
            <div class="col-md-6 col-sm-12 col">
                <ol class="loan-condition-list">
                    <li><i class="fa fa-check text-success"></i>Sổ hộ khẩu và chứng minh nhân dân
                        hoặc
                        thẻ căn cước
                        ( bản photo).
                    </li>
                    <li><i class="fa fa-check text-success"></i>Xác nhận tạm trú hoặc kt3.</li>
                    <li><i class="fa fa-check text-success"></i>Sao kê 03 tháng ngân hàng gần nhất.
                    </li>
                    <li><i class="fa fa-check text-success"></i>Hợp đồng lao động hoặc giấy xác nhận
                        đang công tác
                        tại công ty.
                    </li>
                    <li><i class="fa fa-check text-success"></i>01 hóa đơn điện hoặc nước tại nơi
                        sinh
                        sống.
                    </li>
                </ol>
            </div>
        </div>
        <div class="row text-center margin-top-20">
            <div class="col">
                <button type="button" class="btn btn-cta btn-primary">Đăng ký vay</button>
            </div>
        </div>
    </div>
</div>