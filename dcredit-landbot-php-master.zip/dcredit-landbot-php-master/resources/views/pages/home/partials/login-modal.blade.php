<div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Đăng nhập</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Bạn vui lòng nhập số điện thoại để đăng nhập</p>
                <div class="form-group">
                    <label for="phone">Số điện thoại</label>
                    <input type="number" class="form-control" v-model="loginForm.phone" aria-describedby="loginPhone">
                </div>
                <div class="form-group" v-if="showOtp">
                    <label for="code">Mã xác thực</label>
                    <input type="number" class="form-control" v-model="loginForm.code" aria-describedby="loginCode">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy bỏ</button>
                <button type="button" class="btn btn-primary" @click="submitLoginForm">
                    <div class="spinner-border spinner-border-sm" role="status" v-show="isLoading">
                        <span class="sr-only">Loading...</span>
                    </div>
                    <span v-if="isLoading && showOtp">Đang đăng nhập</span>
                    <span v-if="!isLoading && showOtp">Đăng nhập</span>
                    <span v-if="!isLoading && !showOtp">Gửi mã OTP</span>
                    <span v-if="isLoading && !showOtp">Đang gửi mã OTP</span>
                </button>
            </div>
        </div>
    </div>
</div>