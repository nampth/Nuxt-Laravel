<!--# login with facebook sdk-->
<script>
    window.fbAsyncInit = function () {
        FB.init({
            appId: "499109704245455",
            xfbml: true,
            version: 'v5.0'
        });
        FB.AppEvents.logPageView();
    };

    (function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) {
            return;
        }
        js = d.createElement(s);
        js.id = id;
        js.src = "https://connect.facebook.net/vi_VN/sdk.js";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
</script>

<script src="https://sdk.accountkit.com/vi_VN/sdk.js" target="_top"></script>
<!-- Facebook Pixel Code -->
<script>
    !function (f, b, e, v, n, t, s) {
        if (f.fbq) return;
        n = f.fbq = function () {
            n.callMethod ?
                n.callMethod.apply(n, arguments) : n.queue.push(arguments)
        };
        if (!f._fbq) f._fbq = n;
        n.push = n;
        n.loaded = !0;
        n.version = '2.0';
        n.queue = [];
        t = b.createElement(e);
        t.async = !0;
        t.src = v;
        s = b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t, s)
    }(window, document, 'script',
        'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '732357430609559');
    fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
               src="https://www.facebook.com/tr?id=732357430609559&ev=PageView&noscript=1"
    /></noscript>
<!-- End Facebook Pixel Code -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-729060130"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }

    gtag('js', new Date());

    gtag('config', 'AW-729060130', {'groups': 'adwords'})
</script>
<script>
    function gtag_report_conversion(url) {
        var callback = function () {
            if (typeof(url) != 'undefined') {
                window.location = url;
            }
        };
        gtag('event', 'conversion', {
            'send_to': 'AW-729060130/wBRkCMmTtqYBEKKm0tsC',
            'event_callback': callback
        });
        return false;
    }
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-148874171-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }

    gtag('js', new Date());
    // gtag('config', 'UA-148874171-1', {
    //     'groups': 'default',
    // });
    gtag('config', 'UA-148874171-1', {
        'groups': 'default',
        'custom_map': {
            'dimension1': 'theme',
            'dimension2': 'page',
            'metric1': 'conversion',
            'metric2': 'session',
            'metric3': 'session15',
            'metric4': 'session30'
        }
    })

    if (window.location.hostname === 'vncredit.online') {
        gtag('config', 'UA-148874171-3', {
            'groups': 'vncredit.online'
        })
    }

    if (window.location.hostname === 'vncredit.com.vn') {
        gtag('config', 'UA-148874171-4', {
            'groups': 'vncredit.com.vn'
        })
    }
</script>
