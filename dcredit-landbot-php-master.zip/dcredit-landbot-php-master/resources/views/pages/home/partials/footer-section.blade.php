<div class="footer-info">

    <div class="container">
        <div class="row">
            <div class="col"><h5 class="text-center">Hỗ trợ khách hàng:</h5></div>
        </div>
        <div class="row">
            <div class="text-right col">
                <a href="https://www.facebook.com/vncredit.com.vn/">
                    <span class="hidden">Facebook</span>
                    <img class="social-logo" src="{{ asset('/images/facebook.png') }}" alt="facebook">
                </a>
            </div>
            <div class="text-center col">
                <a href="https://twitter.com/vncredit/">
                    <span class="hidden">Twitter</span>
                    <img class="social-logo" src="{{ asset('/images/twitter.png') }}" alt="twitter">
                </a>
            </div>
            <div class="text-left col">
                <a href="https://www.youtube.com/channel/UCsj4Aza69_NVLKQct_2oUdw/">
                    <span class="hidden">Youtube</span>
                    <img class="social-logo" src="{{ asset('/images/youtube.png') }}" alt="youtube">
                </a>
            </div>
        </div>
        <div class="row info">
            <div class="col text-center copy-right"><p class="pb_font-14">© 2020 VNCREDIT. All
                    Rights
                    Reserved. <br> <a href="/">VNCREDIT</a> - Duyệt vay toàn quốc</p>
                <p class="pb_font-14">Địa chỉ: Tòa nhà Ecolife Capital Lê Văn Lương 58 Tố Hữu,
                    Trung
                    Văn, Từ
                    Liêm, Hà
                    Nội.
                </p></div>
        </div>
    </div>
</div>