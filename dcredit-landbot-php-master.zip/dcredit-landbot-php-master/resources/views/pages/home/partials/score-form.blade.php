<div class="register-form score-form bg-white">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="form-inner">
                    <h4 class="text-center text-uppercase">
                        Chấm điểm tín dụng <span class="text-success">miễn phí</span></h4>
                    <div class="row">
                        <div class="col-sm-8 col-md-6 col-lg-6 col">
                            <div class="input-icon padding-top-5 padding-bottom-5">
                                <label for="fullname" class="label-bold label-sm">Họ và tên
                                    <input name="fullname" v-model="form.fullname" :readonly="isLoading || showOtp"
                                           :disabled="isLoading || showOtp"
                                           type="text" for="fullname" @change="manualUpdateValidate"
                                           class="form-control">
                                </label>
                                <div id="fullname-feedback" class="text-danger" v-show="invalidFullname">
                                    Họ tên chưa đúng.
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 col-md-6 col-lg-6 col">
                            <div class="input-icon padding-top-5 padding-bottom-5">
                                <label for="phone" class="label-bold label-sm">Số điện thoại
                                    <input name="phone" type="number" for="phone" v-model="form.phone"
                                           :readonly="isLoading || showOtp" :disabled="isLoading || showOtp"
                                           @change="manualUpdateValidate"
                                           class="form-control">
                                </label>
                                <div id="phone-feedback" class="text-danger" v-show="invalidPhone">
                                    Số điện thoại chưa đúng.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-8 col-md-6 col-lg-6 col">
                            <div class="input-icon padding-top-5 padding-bottom-5">
                                <label for="current_address" class="label-bold label-sm">Nơi sống hiện tại
                                    <select name="current_address" v-model="form.current_address"
                                            :readonly="isLoading || showOtp" :disabled="isLoading || showOtp"
                                            @change="manualUpdateValidate"
                                            class="sl-address custom-select">
                                        <option value="" disabled="disabled" selected="selected">Nơi sống hiện tại
                                        </option>
                                        <option value="Hà Nội">Hà Nội
                                        </option>
                                        <option value="Hồ Chí Minh">Hồ Chí Minh
                                        </option>
                                        <option value="Đồng Nai">Đồng Nai
                                        </option>
                                        <option value="An Giang">An Giang
                                        </option>
                                        <option value="Bà Rịa - Vũng Tàu">Bà Rịa - Vũng Tàu
                                        </option>
                                        <option value="Bạc Liêu">Bạc Liêu
                                        </option>
                                        <option value="Bắc Giang">Bắc Giang
                                        </option>
                                        <option value="Bắc Kạn">Bắc Kạn
                                        </option>
                                        <option value="Bắc Ninh">Bắc Ninh
                                        </option>
                                        <option value="Bến Tre">Bến Tre
                                        </option>
                                        <option value="Bình Dương">Bình Dương
                                        </option>
                                        <option value="Bình Định">Bình Định
                                        </option>
                                        <option value="Bình Phước">Bình Phước
                                        </option>
                                        <option value="Bình Thuận">Bình Thuận
                                        </option>
                                        <option value="Cà Mau">Cà Mau
                                        </option>
                                        <option value="Cao Bằng">Cao Bằng
                                        </option>
                                        <option value="Cần Thơ">Cần Thơ
                                        </option>
                                        <option value="Đà Nẵng">Đà Nẵng
                                        </option>
                                        <option value="Đắk Lắk">Đắk Lắk
                                        </option>
                                        <option value="Đắk Nông">Đắk Nông
                                        </option>
                                        <option value="Điện Biên">Điện Biên
                                        </option>
                                        <option value="Đồng Tháp">Đồng Tháp
                                        </option>
                                        <option value="Gia Lai">Gia Lai
                                        </option>
                                        <option value="Hà Giang">Hà Giang
                                        </option>
                                        <option value="Hà Nam">Hà Nam
                                        </option>
                                        <option value="Hà Tĩnh">Hà Tĩnh
                                        </option>
                                        <option value="Hải Dương">Hải Dương
                                        </option>
                                        <option value="Hải Phòng">Hải Phòng
                                        </option>
                                        <option value="Hậu Giang">Hậu Giang
                                        </option>
                                        <option value="Hoà Bình">Hoà Bình
                                        </option>
                                        <option value="Hưng Yên">Hưng Yên
                                        </option>
                                        <option value="Khánh Hòa">Khánh Hòa
                                        </option>
                                        <option value="Kiên Giang">Kiên Giang
                                        </option>
                                        <option value="Kon Tum">Kon Tum
                                        </option>
                                        <option value="Lai Châu">Lai Châu
                                        </option>
                                        <option value="Lạng Sơn">Lạng Sơn
                                        </option>
                                        <option value="Lào Cai">Lào Cai
                                        </option>
                                        <option value="Lâm Đồng">Lâm Đồng
                                        </option>
                                        <option value="Long An">Long An
                                        </option>
                                        <option value="Nam Định">Nam Định
                                        </option>
                                        <option value="Nghệ An">Nghệ An
                                        </option>
                                        <option value="Ninh Bình">Ninh Bình
                                        </option>
                                        <option value="Ninh Thuận">Ninh Thuận
                                        </option>
                                        <option value="Phú Thọ">Phú Thọ
                                        </option>
                                        <option value="Phú Yên">Phú Yên
                                        </option>
                                        <option value="Quảng Bình">Quảng Bình
                                        </option>
                                        <option value="Quảng Nam">Quảng Nam
                                        </option>
                                        <option value="Quảng Ngãi">Quảng Ngãi
                                        </option>
                                        <option value="Quảng Ninh">Quảng Ninh
                                        </option>
                                        <option value="Quảng Trị">Quảng Trị
                                        </option>
                                        <option value="Sóc Trăng">Sóc Trăng
                                        </option>
                                        <option value="Sơn La">Sơn La
                                        </option>
                                        <option value="Tây Ninh">Tây Ninh
                                        </option>
                                        <option value="Thái Bình">Thái Bình
                                        </option>
                                        <option value="Thái Nguyên">Thái Nguyên
                                        </option>
                                        <option value="Thanh Hóa">Thanh Hóa
                                        </option>
                                        <option value="Thừa Thiên Huế">Thừa Thiên Huế
                                        </option>
                                        <option value="Tiền Giang">Tiền Giang
                                        </option>
                                        <option value="Trà Vinh">Trà Vinh
                                        </option>
                                        <option value="Tuyên Quang">Tuyên Quang
                                        </option>
                                        <option value="Vĩnh Long">Vĩnh Long
                                        </option>
                                        <option value="Vĩnh Phúc">Vĩnh Phúc
                                        </option>
                                        <option value="Yên Bái">Yên Bái
                                        </option>
                                    </select>
                                </label>
                                <div id="current_address-feedback" class="text-danger"
                                     v-show="invalidCurrentAddress">
                                    Vui lòng chọn nơi sống
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 col-md-6 col-lg-6 col">
                            <div class="input-icon padding-top-5 padding-bottom-5">
                                <label for="identity_id" class="label-bold label-sm">CMND/CCCD
                                    <input name="identity_id" v-model="form.identity_id"
                                           :readonly="isLoading || showOtp"
                                           :disabled="isLoading || showOtp"
                                           type="number" for="identity_id" @change="manualUpdateValidate"
                                           class="form-control">
                                </label>
                                <div id="identity_id-feedback" class="text-danger" v-show="invalidIdentity">
                                    Số CMND/CCCD chưa đúng.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row padding-top-15">
                        <div class="text-center col">
                            <button type="submit" @click="submitForm('score')" :disabled="isLoading"
                                    class="btn btn btn-success btn-radius w-100 margin-top-10 btn-secondary btn-lg">
                                <div class="spinner-border spinner-border-sm" role="status" v-show="isLoading">
                                    <span class="sr-only">Loading...</span>
                                </div>
                                <span v-if="!isLoading && showOtp">Xác thực OTP</span>
                                <span v-if="isLoading && showOtp">Đang xác thực OTP</span>
                                <span v-if="!isLoading && !showOtp">Chấm điểm tín dụng</span>
                                <span v-if="isLoading && !showOtp">Đang tính toán...</span>
                            </button>
                        </div>
                    </div>
                    <p class="text-center">
                        <small>Có 218 {{ rand(100,999) }} người đã được chấm điểm miễn phí</small>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>