<div class="accordion faq-section" id="faq-section">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="intro-title"><h2 class="text-center">Câu hỏi thường gặp</h2> <!----></div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header" id="headingOne">
                        <h2 class="mb-0">
                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne"
                                    aria-expanded="true" aria-controls="collapseOne">
                                Tôi muốn vay 100 triệu trong 5 năm tới thì cần làm thủ tục gì? Lãi suất và phí khoản vay
                                ra sao?
                            </button>
                        </h2>
                    </div>

                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                         data-parent="#faq-section">
                        <div class="card-body">
                            <p class="card-text">
                                Khách hàng thực hiện khoản vay 100 triệu trong 5 năm với lãi suất
                                0,9%/tháng<br>
                                Số lãi hàng tháng phải trả : 100.000.000Đ x 0,9% = 900.000 VNĐ<br>
                                Số tiền gốc phải trả : 100.000.000Đ / 60 tháng = 1.666.666 VNĐ<br>
                                Tổng số tiền phải trả : 2.566.666 VNĐ ( Tiền lãi + tiền gốc)<br>
                                Phí bảo hiểm khoản vay 0vnđ<br>
                                Phí làm hồ sơ 0vnđ<br>
                                Khách hàng có thể tất toán sớm khi đủ 6 tháng. Phí phạt tính trên 4%
                                dư
                                nợ còn
                                lại
                                của số tiền gốc khách hàng vay tại thời điểm tất toán.<br>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header" id="headingTwo">
                        <h2 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                    data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Tôi
                                muốn vay 100 triệu trong
                                5 năm tới thì cần làm thủ tục gì? Lãi suất và phí khoản vay ra sao?
                            </button>
                        </h2>
                    </div>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#faq-section">
                        <div class="card-body">
                            <p class="card-text">
                                Vay tín chấp bằng sổ hộ khẩu và CMND là hình thức vay tiền không cần
                                phải chứng
                                minh
                                thu nhập hoặc người bảo lãnh mà chỉ cần cung cấp sổ hộ khẩu và chứng
                                minh nhân
                                dân
                                cho công ty tài chính.<br>
                                Thông thường, với hình thức cho vay tín chấp bằng sổ hộ khẩu và
                                CMND,
                                khách hàng
                                sẽ
                                nhận được khoản vay chỉ trong thời gian ngắn.<br>
                                Vay tín chấp bằng sổ hộ khẩu là hình thức vay được nhiều người quan
                                tâm
                                hiện nay,
                                chỉ cần sổ hộ khẩu hoặc CMND là bạn có thể vay được tiền rất nhanh
                                chóng.<br>
                                Vay tín chấp bằng sổ hộ khẩu và CMND là hình thức vay tiền không cần
                                phải chứng
                                minh
                                thu nhập hoặc người bảo lãnh mà chỉ cần cung cấp sổ hộ khẩu và chứng
                                minh nhân
                                dân
                                cho công ty tài chính.<br>
                                Thông thường, với hình thức cho vay tín chấp bằng sổ hộ khẩu và
                                CMND,
                                khách hàng
                                sẽ
                                nhận được khoản vay chỉ trong thời gian ngắn.<br></p>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header" id="headingThree">
                        <h2 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                    data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                Cho vay tín chấp bằng sổ hộ khẩu và CMND là gì? Tôi cần những thủ tục
                                nào để
                                có thể được
                                vay?
                            </button>
                        </h2>
                    </div>
                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                         data-parent="#faq-section">
                        <div class="card-body">
                            <p class="card-text">
                                Người đi vay không cần chứng minh thu nhập và tài sản đảm bảo. Chỉ
                                cần
                                Sổ hộ khẩu
                                hoặc CMND.<br>
                                Bạn có thể lựa chọn mức vay và thời gian chi trả một cách linh hoạt.<br>
                                Được hỗ trợ vay lên đến 100 triệu đồng.<br>
                                Thời gian vay linh động từ 06 tháng đến 60 tháng<br>
                                Hồ sơ vay đơn giản, bạn chỉ cần chờ trong khoảng thời gian từ 1 - 7
                                ngày
                                là đã có
                                thể nhận được tiền vay.<br>
                                Sống tại hộ khẩu hay tạm trú đều được vay dưới hình thức này.<br>
                                Không đến nhà thẩm định.<br></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
