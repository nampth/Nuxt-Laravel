const baseUrl = $('#site_meta').attr('data-url');
const apiPath = $('#api_meta').attr('data-url');
import {getCookie} from "../helpers";

var app = new Vue({
    el: '#app',
    data: {
        form: {
            phone: '',
            state: false,
            current_detail: '',
            sex: '',
            identity_location: '',
            full_date_of_birth: '',
            full_identity_date: '',
            identity_date: '',
            identity_month: '',
            identity_year: '',
            date_of_birth: '',
            month_of_birth: '',
            year_of_birth: '',
            form_level: 42,
        },
        phone: '',
        amount: 30,
        duration: 12,
        isLoading: false,
        isSubmiting: false,
        submitRefer: false,
        toastStatus: '',
        toastMsg: '',
        toastHeader: '',
        showLoan: false
    },
    mounted() {
        let vm = this;
        let token = getCookie('auth._token.local');
        vm.initUserInfo(token);
        vm.initLoanProcess(token);
    },
    methods: {
        initUserInfo(token) {
            let vm = this;
            $(document).ready(function () {
                $.ajax({
                    url: apiPath + 'infoec',
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader("Authorization", token);
                    },
                    type: 'GET',
                    success: function (data) {
                        if (data && data.success) {
                            let metricData = data.data.metric_data;
                            metricData.forEach(function (item) {
                                if (item.info.key == 'amount') {
                                    vm.amount = item.value;
                                }
                                if (item.info.key == 'duration') {
                                    vm.duration = item.value;
                                }
                                if (item.info.key == 'phone') {
                                    vm.form.phone = item.value;
                                }
                            });
                        } else {
                            // window.location.href = baseUrl + '404';
                        }
                    },
                    error: function (err) {
                        // window.location.href = baseUrl + '404';
                    }
                });
            })

        },
        initLoanProcess(token) {
            let vm = this;
            $(document).ready(function () {
                $.ajax({
                    url: 'https://vncredit.com.vn/api/loanstt',
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader("Authorization", token);
                    },
                    type: 'GET',
                    success: function (data) {
                        console.log(data);
                        if (data && data.success) {

                        } else {
                            // window.location.href = baseUrl + '404';
                        }
                    },
                    error: function (err) {
                        // window.location.href = baseUrl + '404';
                    }
                });
            })

        },
    }
})