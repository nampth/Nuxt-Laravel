const baseUrl = $('#site_meta').attr('data-url');
const apiPath = $('#api_meta').attr('data-url');
import {getCookie} from "../helpers";

var app = new Vue({
    el: '#app',
    data: {
        form: {
            phone: '',
            state: false,
            current_detail: '',
            sex: '',
            identity_location: '',
            full_date_of_birth: '',
            full_identity_date: '',
            identity_date: '',
            identity_month: '',
            identity_year: '',
            date_of_birth: '',
            month_of_birth: '',
            year_of_birth: '',
            form_level: 42,
        },
        phone: '',
        amount: 30,
        duration: 12,
        isLoading: false,
        isSubmiting: false,
        submitRefer: false,
        toastStatus: '',
        toastMsg: '',
        toastHeader: '',
        showLoan: false
    },
    mounted() {
        let vm = this;
        let token = getCookie('auth._token.local');
        vm.initUserInfo(token);
        vm.initDatePicker();
    },
    methods: {
        initDatePicker() {
            let vm = this;
            $(vm.$refs.dobPicker).daterangepicker({
                "singleDatePicker": true,
                "startDate": moment().format('DD/MM/YYYY'),
                "endDate": moment().format('DD/MM/YYYY'),
                "maxDate": moment().format('DD/MM/YYYY'),
                "locale": {
                    "format": 'DD/MM/YYYY',
                    "separator": " - ",
                    "applyLabel": "Áp dụng",
                    "cancelLabel": "Hủy",
                    "fromLabel": "Từ",
                    "toLabel": "Đến",
                    "customRangeLabel": "Tùy chỉnh",
                    "weekLabel": "W",
                    "daysOfWeek": [
                        "CN",
                        "T2",
                        "T3",
                        "T4",
                        "T5",
                        "T6",
                        "T7"
                    ],
                    "monthNames": [
                        "Tháng 1",
                        "Tháng 2",
                        "Tháng 3",
                        "Tháng 4",
                        "Tháng 5",
                        "Tháng 6",
                        "Tháng 7",
                        "Tháng 8",
                        "Tháng 9",
                        "Tháng 10",
                        "Tháng 11",
                        "Tháng 12"
                    ],
                    "firstDay": 1
                },
            }, function (start, end, label) {
                vm.form.full_date_of_birth = moment(start).format('DD/MM/YYYY');
            });

            $(vm.$refs.identityPicker).daterangepicker({
                "singleDatePicker": true,
                "startDate": moment().format('DD/MM/YYYY'),
                "endDate": moment().format('DD/MM/YYYY'),
                "maxDate": moment().format('DD/MM/YYYY'),
                "locale": {
                    "format": 'DD/MM/YYYY',
                    "separator": " - ",
                    "applyLabel": "Áp dụng",
                    "cancelLabel": "Hủy",
                    "fromLabel": "Từ",
                    "toLabel": "Đến",
                    "customRangeLabel": "Tùy chỉnh",
                    "weekLabel": "W",
                    "daysOfWeek": [
                        "CN",
                        "T2",
                        "T3",
                        "T4",
                        "T5",
                        "T6",
                        "T7"
                    ],
                    "monthNames": [
                        "Tháng 1",
                        "Tháng 2",
                        "Tháng 3",
                        "Tháng 4",
                        "Tháng 5",
                        "Tháng 6",
                        "Tháng 7",
                        "Tháng 8",
                        "Tháng 9",
                        "Tháng 10",
                        "Tháng 11",
                        "Tháng 12"
                    ],
                    "firstDay": 1
                },
            }, function (start, end, label) {
                vm.form.full_identity_date = moment(start).format('DD/MM/YYYY');
            });
        },
        initUserInfo(token) {
            let vm = this;
            $(document).ready(function () {
                $.ajax({
                    url: apiPath + 'infoec',
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader("Authorization", token);
                    },
                    type: 'GET',
                    success: function (data) {
                        if (data && data.success) {
                            let metricData = data.data.metric_data;
                            metricData.forEach(function (item) {
                                if (item.info.key == 'amount') {
                                    vm.amount = item.value;
                                }
                                if (item.info.key == 'duration') {
                                    vm.duration = item.value;
                                }
                                if (item.info.key == 'phone') {
                                    vm.form.phone = item.value;
                                }
                            });
                        } else {
                            // window.location.href = baseUrl + '404';
                        }
                    },
                    error: function (err) {
                        // window.location.href = baseUrl + '404';
                    }
                });
            })

        },
        showLoan() {

        },
        updateIdentity() {

        },
        updateDateOfBirth() {

        },
        showToast(status, header, content) {
            let vm = this;
            vm.toastStatus = status;
            vm.toastHeader = header;
            vm.toastMsg = content;
            $('.toast').toast('show');
        },
        onSubmit() {
            let vm = this;
            vm.isLoading = true;
            vm.isSubmiting = true;
            let check = true;
            setTimeout(function () {
                $(".error-msg").each(function () {
                    if ($(this).css('display') != 'none') {
                        check = false;
                    }
                });
                if (!check) {
                    vm.showToast('error', 'Lỗi', 'Vui lòng nhập đầy đủ thông tin.');
                    vm.isLoading = false;
                    return;
                }

                vm.form.identity_date = moment(vm.form.full_identity_date, 'DD/MM/YYYY').format('DD');
                vm.form.identity_month = moment(vm.form.full_identity_date, 'DD/MM/YYYY').format('MM');
                vm.form.identity_year = moment(vm.form.full_identity_date, 'DD/MM/YYYY').format('YYYY');

                vm.form.date_of_birth = moment(vm.form.full_date_of_birth, 'DD/MM/YYYY').format('DD');
                vm.form.month_of_birth = moment(vm.form.full_date_of_birth, 'DD/MM/YYYY').format('MM');
                vm.form.year_of_birth = moment(vm.form.full_date_of_birth, 'DD/MM/YYYY').format('YYYY');

                $.ajax({
                    url: apiPath + 'updateec',
                    type: "POST",
                    data: vm.form,
                    success: function (response) {
                        vm.isLoading = false;
                        if (response && response.code == 0) {
                            vm.showToast('success', 'Thành công', 'Cập nhật thông tin thành công. Chúng tôi sẽ tư vấn & trả kết quả cho bạn trong thời gian sớm nhất');
                            window.scrollTo({top: 0, behavior: 'smooth'});
                        }
                        else {
                            vm.showToast('error', 'Lỗi', response.result);
                        }

                    },
                    error: function (err) {
                        vm.showToast('error', 'Lỗi', 'Có lỗi xảy ra. Vui lòng thử lại sau.');
                        vm.isLoading = false;
                        $('#login-modal').modal('hide');
                    }
                });
            }, 300);

        },
        dtiComputing() {
            let vm = this;
            // let value = Math.ceil((amount * (1 + 0.11) / duration).toFixed(2)) * 1e6;
            let value = Math.ceil(1.06 * vm.amount * ((0.12 / 12) * 0.01) / (1 - 1 / (Math.pow(1 + (0.12 / 12) * 0.01, vm.duration))) * 1e6);
            // (1.06*{Muốn Vay Chính xác}* (({Hệ số lãi suất}/12)*0.01)/(1 - 1/(POWER(1+({Hệ số lãi suất}/12)*0.01 ,{THỜI GIAN VAY}))))
            return (value + '').replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
            // return value;
        }
    }
})