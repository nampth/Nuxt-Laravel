import Vue from 'vue'
import BootstrapVue from 'bootstrap-vue'
import {baseUrl, SUCCESS_CODE, ERROR_CODE} from "../app.constants";
import VeeValidate, {Validator} from 'vee-validate';

Vue.use(BootstrapVue);
Vue.use(VeeValidate);
Validator.localize({
    en: {
        custom: {
            name: {
                required: 'Vui lòng nhập họ tên',
                max: 'Tên có độ dài không vượt quá 100 ký tự',
            },
            social_id: {
                required: 'Vui lòng nhập CMND',
                numeric: 'Vui lòng nhập số CMND phù hợp',
                min: 'Vui lòng nhập số CMND phù hợp',
                max: 'Vui lòng nhập số CMND phù hợp',
            },
            mobile: {
                required: 'Vui lòng nhập Số điện thoại',
                numeric: 'Vui lòng nhập Số điện thoại phù hợp',
                min: 'Vui lòng nhập Số điện thoại phù hợp',
                max: 'Vui lòng nhập Số điện thoại phù hợp',
            },
            city: {
                required: 'Vui lòng nhập Tỉnh thành bạn sinh sống'
            },
            company: {
                required: 'Vui lòng nhập Công ty bạn làm việc'
            },
            district: {
                required: 'Vui lòng nhập Quận/Huyện bạn sinh sống'
            },
            address: {
                required: 'Vui lòng nhập địa chỉ bạn sinh sống'
            },
            income_type: {
                required: 'Vui lòng chọn loại thu nhập'
            },
            identity_birth: {
                required: 'Vui lòng nhập năm sinh của bạn'
            },
            email: {
                email: 'Vui lòng nhập Email phù hợp'
            },
        }
    }
})


var app = new Vue({
    el: '#form',
    data: function () {
        return {
            form: {
                amount: 30,
                duration: 12,
                name: '',
                mobile: '',

                income: 0,
                social_id: '',
                city: '',
                address: '',
                district: '',
                company: '',
                income_type: '',
                identity_birth: '',
                identity_location: '',
                email: '',
                checkedProfiles: [],
            }
        }
    },
    mounted() {
        this.initSlider();
    },
    methods: {
        initSlider() {
            let vm = this;
            let amountSlider = $(vm.$refs.amountSlider);

            amountSlider.oninput = function () {
                vm.form.amount = this.value;
            }

            let durationSlider = $(vm.$refs.durationSlider);

            durationSlider.oninput = function () {
                vm.form.duration = this.value;
            }

            let incomeSlider = $(vm.$refs.incomeSlider);

            incomeSlider.oninput = function () {
                vm.form.income = this.value;
            }
        },
        submitForm(scope) {
            let vm = this;
            vm.$validator.validateAll(scope).then(res => {
                if (res) {
                    var url = '';
                    if (scope == 'form-landbot') {
                        url = baseUrl + '/designed/register';

                        AccountKit.init(
                            {
                                appId: "404291800431097",
                                state: "true",
                                version: "v1.0",
                                fbAppEventsEnabled: true,
                                redirect: baseUrl,
                                debug: false,
                                display: 'modal',
                            }
                        );

                        AccountKit.login(
                            'PHONE',
                            {
                                countryCode: '+84',
                                phoneNumber: $('input[name="mobile"]').val()
                            }, // will use default values if not specified
                            function (response) {

                                if (response.status === "PARTIALLY_AUTHENTICATED") {
                                    var dialog = bootbox.dialog({
                                        message: '<p class="text-center mb-0"><i class="fa fa-spin fa-spinner"></i> Đang đăng ký...</p>',
                                        closeButton: false
                                    });
                                    let data = _.cloneDeep(vm.form);
                                    data.code = response.code;
                                    data.type = 'data';
                                    let request = $.ajax({
                                        type: "POST",
                                        url: url,
                                        // // async: false,
                                        // timeout: 500,
                                        data: data,
                                        success: function (response) {
                                            if (response.code == SUCCESS_CODE) {
                                            } else {
                                            }
                                        },
                                        complete() {
                                            setTimeout(function () {
                                                dialog.modal('hide');
                                            }, 1000);
                                            vm.form.income = 50;
                                            $("#district option[data-province!='" + $('#city').val() + "']").remove();
                                            toastr.success('Đã đăng ký. Bạn vui lòng hoàn thành thông tin để chúng tôi có thể phê duyệt khoản vay.');
                                            setTimeout(function () {
                                                vm.toggleFront();
                                                $("html, body").animate({scrollTop: 0}, "slow");
                                            }, 500);

                                        },
                                        error: function (error) {
                                            setTimeout(function () {
                                                dialog.modal('hide');
                                            }, 1000);

                                        }// serializes the form's elements.
                                    });

                                } else {

                                }
                            }
                        );

                    } else {
                        url = baseUrl + '/designed/register';

                        let data = _.cloneDeep(vm.form);
                        data.type = 'data';
                        let request = $.ajax({
                            type: "POST",
                            url: url,
                            // // async: false,
                            // timeout: 500,
                            data: data,
                            success: function (response) {
                                if (response.code == SUCCESS_CODE) {
                                } else {
                                }
                            },
                            complete() {
                                setTimeout(function () {
                                    dialog.modal('hide');
                                }, 1000);

                                bootbox.alert("Đăng ký thành công, chúng tôi sẽ sớm liên lạc với bạn.", function () {
                                    window.open('https://dcredit.vn/hoi-dap/?show=most-answered', '_blank');
                                });

                            },
                            error: function (error) {
                                setTimeout(function () {
                                    dialog.modal('hide');
                                }, 1000);
                            }// serializes the form's elements.
                        });
                    }


                } else {
                    toastr.error("Vui lòng nhập đầy đủ thông tin.");
                }
            })
        },
        toggleFront() {
            $('#form-landbot').fadeOut('slow', function () {
                $('#form-moreinfo').fadeIn('slow');
            })
        },
        submitLog(action, category, label) {
            let vm = this;
            let data = vm.form;
            data.type = 'log';
            vm.gtagLog(action, category, label)
            $.ajax({
                type: "POST",
                url: baseUrl + '/designed/register',
                data: data, // serializes the form's elements.
                success: function (data) {

                },
                error: function (error) {

                }
            });
        },
        gtagLog(action, category, label) {
            gtag('event', action, {
                'event_category': category,
                'event_label': label,
            });
        },
        formatPrice(value) {
            let val = (value / 1).toFixed(0).replace('.', ',')
            return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
        }
    },
});
