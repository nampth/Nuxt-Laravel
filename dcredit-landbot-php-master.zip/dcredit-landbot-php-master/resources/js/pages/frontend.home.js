import {baseUrl, SUCCESS_CODE} from "../app.constants";

var app = new Vue({
    el: '#app',
    data: function () {
        return {
            enableSearch: true,
            imgUrl: null,
            avatarUrl: null,
            identityData: null,
            creditInfo: null,
            imgSocialUrl: [],
            compareResult: [],
            phone: '',
            reqCounter: 0
        }
    },
    mounted() {
        this.submitForm();
    },
    methods: {
        submitForm() {
            var vm = this;

            $(vm.$refs.formFile).on('submit', function (evt) {
                vm.imgUrl = null;
                vm.avatarUrl = null;
                vm.identityData = null;
                vm.creditInfo = null;
                vm.imgSocialUrl = [];
                vm.compareResult = [];
                vm.reqCounter = 0;

                evt.preventDefault();
                var formData = new FormData($(this)[0]);
                vm.enableSearch = false;
                mApp.block("#app", {
                    overlayColor: "#000000",
                    type: "loader",
                    state: "success",
                    message: "Đang xử lý dữ liệu CMND..."
                });

                $.ajax({
                    url: baseUrl + '/upload',
                    type: 'POST',
                    data: formData,
                    async: false,
                    cache: false,
                    contentType: false,
                    enctype: 'multipart/form-data',
                    processData: false,
                    success: function (response) {
                        mApp.unblock("#app");
                        if (response) {
                            vm.imgUrl = response.img;
                            vm.identityData = response.data;
                            vm.getCreditInfo(vm.identityData.id);
                        } else {
                            // toastr.error('Có lỗi xảy ra, vui lòng thử lại.');
                        }

                    },
                    error: function () {
                        // toastr.error('Có lỗi xảy ra, vui lòng thử lại.');
                        mApp.unblock("#app");
                    }
                });
            })
        },
        getCreditInfo(id) {
            var vm = this;
            mApp.block("#app", {
                overlayColor: "#000000",
                type: "loader",
                state: "success",
                message: "Đang tìm dữ liệu tín dụng..."
            });
            $.ajax({
                url: baseUrl + '/credit',
                type: 'POST',
                data: {
                    'id': id
                },
                success: function (response) {
                    mApp.unblock("#app");
                    if (response) {
                        vm.creditInfo = response;
                        if (response.mobile) {
                            vm.getSocialImg(response.mobile)
                        } else {
                            vm.getSocialImg(vm.phone);
                        }
                    } else {
                        // toastr.error('Có lỗi xảy ra, vui lòng thử lại.');
                    }

                },
                error: function () {
                    // toastr.error('Có lỗi xảy ra, vui lòng thử lại.');
                    mApp.unblock("#app");
                }
            });
        },
        getSocialImg(mobile) {
            var vm = this;
            mApp.block("#app", {
                overlayColor: "#000000",
                type: "loader",
                state: "success",
                message: "Đang lấy thông tin Facebook..."
            });
            $.ajax({
                url: baseUrl + '/social_img',
                type: 'POST',
                data: {
                    'mobile': mobile
                },
                success: function (response) {
                    mApp.unblock("#app");
                    if (response && response.url) {
                        _.forEach(response.url, function (value) {
                            vm.imgSocialUrl.push(value);
                            vm.compareImg(vm.imgUrl, value, false);
                        })

                    } else {
                        vm.reqCounter++;
                        if (vm.reqCounter >= 5) {
                            // toastr.error('Lỗi không lấy được ảnh, vui lòng thử lại sau');
                        } else {
                            vm.getSocialImg(mobile);
                        }

                    }
                },
                error: function () {
                    // toastr.error('Có lỗi xảy ra, vui lòng thử lại.');
                    mApp.unblock("#app");
                }
            });
            if (vm.reqCounter < 1) {
                $.ajax({
                    url: baseUrl + '/social',
                    type: 'POST',
                    data: {
                        'mobile': mobile
                    },
                    success: function (response) {
                        if (response && response.id) {
                            vm.getFbAvatar(response.id);
                        }
                    },
                    error: function () {
                        // toastr.error('Có lỗi xảy ra, vui lòng thử lại.');
                        mApp.unblock("#app");
                    }
                });
            }
        },
        getFbAvatar(id) {
            var vm = this;
            $.ajax({
                url: baseUrl + '/avatar',
                type: 'POST',
                data: {
                    'id': id
                },
                success: function (response) {
                    mApp.unblock("#app");
                    if (response && response.url) {
                        vm.avatarUrl = response.url;
                        vm.imgSocialUrl.unshift(response.url);
                        vm.compareImg(vm.imgUrl, response.url, true);
                    } else {
                        // vm.getSocialImg(mobile);
                    }
                },
                error: function () {
                    // toastr.error('Có lỗi xảy ra, vui lòng thử lại.');
                }
            });
        },
        compareImg(socialImg, fbImg, unshift) {
            var vm = this;
            mApp.block("#app", {
                overlayColor: "#000000",
                type: "loader",
                state: "success",
                message: "Đang tiến hành so sánh các ảnh ..."
            });
            $.ajax({
                url: baseUrl + '/compare',
                type: 'POST',
                data: {
                    'img1': socialImg,
                    'img2': fbImg
                },
                success: function (response) {
                    mApp.unblock("#app");
                    if (response) {
                        if (unshift) {
                            vm.compareResult.unshift(response);
                        } else {
                            vm.compareResult.push(response);
                        }

                    } else {
                        if (unshift) {
                            vm.compareResult.unshift({});
                        } else {
                            vm.compareResult.push({});
                        }
                    }
                },
                error: function () {
                    // toastr.error('Có lỗi xảy ra, vui lòng thử lại.');
                    mApp.unblock("#app");
                }
            });
        }

    }
});
