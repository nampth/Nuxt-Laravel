const baseUrl = $('#site_meta').attr('data-url');
const apiPath = $('#api_meta').attr('data-url');
import {getCookie} from "../helpers";

var app = new Vue({
    el: '#app',
    data: {
        form: {
            amount: '',
            duration: '',
            fullname: '',
            phone: '',
            identity_id: '',
            current_address: '',
            form_level: 11,
            theme: 'vncredit_99',
            code: '',
            p: '',
            k: '',
            ref: '',
            traffic_id: '',
            traffic_source: '',
            pub_id: '',
            domain: 'team1.vncredit.com.vn'
        },
        userinfo: null,
        allowArray: ['phone', 'fullname', 'identity_id', 'current_address', 'amount', 'duration'],
        invalidAmount: false,
        invalidDuration: false,
        invalidPhone: false,
        invalidFullname: false,
        invalidCurrentAddress: false,
        invalidIdentity: false,
        loadContent: false,
        isLoading: false,
        toastType: '',
        loadDone: true,
        showOtp: false,
        toastMsg: ''
    },
    mounted() {
        let vm = this;
        let token = getCookie('auth._token.local');
        setTimeout(function () {
            vm.initUserInfo(token);
        }, 100);
    },
    methods: {
        initUserInfo(token) {
            let vm = this;
            $.ajax({
                url: apiPath + 'infoec',
                beforeSend: function (xhr) {
                    xhr.setRequestHeader("Authorization", token);
                },
                type: 'GET',
                success: function (data) {
                    if (data && data.success) {
                        vm.userinfo = data.data;
                    } else {
                        // window.location.href = baseUrl + '404';
                    }
                },
                error: function (err) {
                    // window.location.href = baseUrl + '404';
                }
            })
        },
    }
})