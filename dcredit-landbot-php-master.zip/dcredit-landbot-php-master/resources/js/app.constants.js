export const baseUrl = $('#site_env').attr('data-env') == 'local' ? $('#site_meta').attr('data-url') : window.location.origin;;
export const SUCCESS_CODE = 0;
export const ERROR_CODE = 1;

export const USER_ACTIVE_STATUS = 0;
export const USER_DEACT_STATUS = 1;
