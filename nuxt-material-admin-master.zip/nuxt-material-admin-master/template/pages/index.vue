<template>
    
</template>

<script>
    export default {
        mounted()
        {
          this.$router.push('/dashboard')
        }
    }
</script>

<style scoped>

</style>
