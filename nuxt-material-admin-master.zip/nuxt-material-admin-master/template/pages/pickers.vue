<template>
    <nuxt-child/>
</template>

<script>
    export default {
        layout: "dashboard"
    }
</script>

<style scoped>

</style>
