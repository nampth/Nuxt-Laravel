<template>
  <v-container grid-list-xl fluid>
    <h4>
      <i class="fa fa-smile-o"></i>
      Hi there, this an empty page.</h4>
  </v-container>
</template>

<script>
  export default {
    layout: "dashboard",

  }
</script>

<style scoped>

</style>
